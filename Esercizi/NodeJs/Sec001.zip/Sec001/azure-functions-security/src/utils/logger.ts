import { setLogLevel } from '@azure/logger';
import { LogLevel, LogMetadata } from '../types';

/**
 * Logger centralizzato per l'applicazione
 * Compatibile con Application Insights
 */
class Logger {
  private context: Record<string, unknown> = {};

  constructor() {
    // Configura il livello di log per gli SDK Azure
    const logLevel = process.env.AZURE_LOG_LEVEL || 'info';
    setLogLevel(logLevel as any);
  }

  /**
   * Imposta il contesto globale per tutti i log
   */
  setContext(context: Record<string, unknown>): void {
    this.context = { ...this.context, ...context };
  }

  /**
   * Cancella il contesto
   */
  clearContext(): void {
    this.context = {};
  }

  /**
   * Formatta un messaggio di log con metadata
   */
  private formatMessage(level: LogLevel, message: string, metadata?: LogMetadata): string {
    const timestamp = new Date().toISOString();
    const logData = {
      timestamp,
      level,
      message,
      ...this.context,
      ...metadata,
    };

    return JSON.stringify(logData);
  }

  /**
   * Log di livello DEBUG
   */
  debug(message: string, metadata?: LogMetadata): void {
    if (process.env.NODE_ENV === 'development') {
      console.debug(this.formatMessage(LogLevel.DEBUG, message, metadata));
    }
  }

  /**
   * Log di livello INFO
   */
  info(message: string, metadata?: LogMetadata): void {
    console.log(this.formatMessage(LogLevel.INFO, message, metadata));
  }

  /**
   * Log di livello WARN
   */
  warn(message: string, metadata?: LogMetadata): void {
    console.warn(this.formatMessage(LogLevel.WARN, message, metadata));
  }

  /**
   * Log di livello ERROR
   */
  error(message: string, metadata?: LogMetadata): void {
    console.error(this.formatMessage(LogLevel.ERROR, message, metadata));
  }

  /**
   * Log per operazioni di audit
   */
  audit(operation: string, metadata?: LogMetadata): void {
    this.info(`[AUDIT] ${operation}`, {
      ...metadata,
      auditLog: true,
    });
  }

  /**
   * Log per metriche di performance
   */
  metric(metricName: string, value: number, metadata?: LogMetadata): void {
    this.info(`[METRIC] ${metricName}`, {
      ...metadata,
      metricName,
      metricValue: value,
    });
  }

  /**
   * Log per tracciamento di operazioni
   */
  trace(operationName: string, duration: number, success: boolean, metadata?: LogMetadata): void {
    this.info(`[TRACE] ${operationName}`, {
      ...metadata,
      operationName,
      duration,
      success,
    });
  }
}

// Istanza singleton del logger
export const logger = new Logger();
