import { HttpRequest, HttpResponseInit, InvocationContext } from '@azure/functions';
import { AppError } from '../types';
import { logger } from './logger';

/**
 * Handler centralizzato per la gestione degli errori
 */
export class ErrorHandler {
  /**
   * Gestisce un errore e restituisce una risposta HTTP appropriata
   */
  static handleError(error: unknown, context: InvocationContext): HttpResponseInit {
    // Log dell'errore
    logger.error('Errore nell\'elaborazione della richiesta', {
      functionName: context.functionName,
      invocationId: context.invocationId,
      error: error instanceof Error ? {
        message: error.message,
        stack: error.stack,
        name: error.name,
      } : error,
    });

    // Gestione di errori personalizzati (AppError)
    if (error instanceof AppError) {
      return {
        status: error.statusCode,
        jsonBody: {
          error: {
            message: error.message,
            statusCode: error.statusCode,
            details: process.env.NODE_ENV === 'development' ? error.details : undefined,
          },
        },
      };
    }

    // Gestione di errori standard
    if (error instanceof Error) {
      return {
        status: 500,
        jsonBody: {
          error: {
            message: process.env.NODE_ENV === 'production' 
              ? 'Internal Server Error' 
              : error.message,
            statusCode: 500,
            stack: process.env.NODE_ENV === 'development' ? error.stack : undefined,
          },
        },
      };
    }

    // Errore sconosciuto
    return {
      status: 500,
      jsonBody: {
        error: {
          message: 'An unexpected error occurred',
          statusCode: 500,
        },
      },
    };
  }

  /**
   * Wrapper per eseguire una funzione con gestione degli errori
   */
  static async withErrorHandling<T>(
    fn: () => Promise<T>,
    context: InvocationContext
  ): Promise<T> {
    try {
      return await fn();
    } catch (error) {
      throw error; // Rilancia l'errore per essere gestito dal caller
    }
  }

  /**
   * Valida la richiesta HTTP
   */
  static validateRequest(
    request: HttpRequest,
    requiredFields: string[],
    context: InvocationContext
  ): void {
    const body = request.body as any;

    if (!body) {
      throw new AppError('Request body is required', 400);
    }

    const missingFields = requiredFields.filter(field => !(field in body));

    if (missingFields.length > 0) {
      throw new AppError(
        `Missing required fields: ${missingFields.join(', ')}`,
        400,
        true,
        { missingFields }
      );
    }

    logger.debug('Request validation successful', {
      functionName: context.functionName,
      requiredFields,
    });
  }

  /**
   * Valida i parametri della query string
   */
  static validateQueryParams(
    request: HttpRequest,
    requiredParams: string[],
    context: InvocationContext
  ): void {
    const missingParams = requiredParams.filter(param => !request.query.get(param));

    if (missingParams.length > 0) {
      throw new AppError(
        `Missing required query parameters: ${missingParams.join(', ')}`,
        400,
        true,
        { missingParams }
      );
    }

    logger.debug('Query parameters validation successful', {
      functionName: context.functionName,
      requiredParams,
    });
  }

  /**
   * Crea una risposta di successo standardizzata
   */
  static successResponse<T>(data: T, statusCode: number = 200): HttpResponseInit {
    return {
      status: statusCode,
      jsonBody: {
        success: true,
        data,
        timestamp: new Date().toISOString(),
      },
    };
  }

  /**
   * Crea una risposta di errore standardizzata
   */
  static errorResponse(message: string, statusCode: number = 500, details?: unknown): HttpResponseInit {
    return {
      status: statusCode,
      jsonBody: {
        success: false,
        error: {
          message,
          statusCode,
          details: process.env.NODE_ENV === 'development' ? details : undefined,
        },
        timestamp: new Date().toISOString(),
      },
    };
  }
}

/**
 * Decorator per gestire automaticamente gli errori in una funzione Azure
 */
export function withErrorHandler(
  target: any,
  propertyKey: string,
  descriptor: PropertyDescriptor
): PropertyDescriptor {
  const originalMethod = descriptor.value;

  descriptor.value = async function (...args: any[]) {
    try {
      return await originalMethod.apply(this, args);
    } catch (error) {
      const context = args.find((arg: any) => arg && arg.functionName);
      if (context) {
        return ErrorHandler.handleError(error, context);
      }
      throw error;
    }
  };

  return descriptor;
}
