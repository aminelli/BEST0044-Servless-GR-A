import { app, HttpRequest, HttpResponseInit, InvocationContext } from '@azure/functions';
import { getAuthService } from '../../services/authService';
import { ErrorHandler } from '../../utils/errorHandler';
import { logger } from '../../utils/logger';
import { AppError } from '../../types';

/**
 * Function 2: API Sicura con RBAC
 * 
 * Scenario di Sicurezza:
 * - Implementa autorizzazione basata su ruoli (RBAC)
 * - Valida il token Bearer
 * - Verifica l'identità dell'utente
 * - Validazione input e gestione errori
 * - Rate limiting e protezione
 * 
 * Ruoli supportati:
 * - Admin: Accesso completo (GET, POST, PUT, DELETE)
 * - Editor: Lettura e modifica (GET, POST, PUT)
 * - Reader: Solo lettura (GET)
 * 
 * Endpoint:
 * - GET /api/protected/data - Recupera dati (Reader, Editor, Admin)
 * - POST /api/protected/data - Crea dati (Editor, Admin)
 * - PUT /api/protected/data/{id} - Aggiorna dati (Editor, Admin)
 * - DELETE /api/protected/data/{id} - Elimina dati (Admin)
 */
export async function protectedApi(
  request: HttpRequest,
  context: InvocationContext
): Promise<HttpResponseInit> {
  const startTime = Date.now();

  try {
    logger.setContext({
      functionName: context.functionName,
      invocationId: context.invocationId,
    });

    logger.info('Richiesta ricevuta per API protetta', {
      method: request.method,
      url: request.url,
    });

    const authService = getAuthService();
    const method = request.method.toUpperCase();

    // Step 1: Verifica autenticazione
    const isAuthenticated = await authService.isAuthenticated(request);
    if (!isAuthenticated) {
      logger.warn('Tentativo di accesso non autenticato');
      throw new AppError('Autenticazione richiesta', 401);
    }

    // Step 2: Ottieni l'identità dell'utente
    const identity = await authService.getIdentity(request);
    if (!identity) {
      throw new AppError('Impossibile verificare l\'identità', 401);
    }

    logger.info('Utente autenticato', {
      objectId: identity.objectId,
      roles: identity.roles,
    });

    // Step 3: Verifica autorizzazione basata sul metodo HTTP
    const requiredRoles = getRequiredRolesForMethod(method);
    const hasPermission = await authService.verifyRoles(request, requiredRoles);

    if (!hasPermission) {
      logger.warn('Utente non autorizzato per questa operazione', {
        userRoles: identity.roles,
        requiredRoles,
        method,
      });
      throw new AppError(
        `Permessi insufficienti. Ruoli richiesti: ${requiredRoles.join(', ')}`,
        403
      );
    }

    logger.audit('Authorization successful', {
      userId: identity.objectId,
      method,
      roles: identity.roles,
    });

    // Step 4: Esegui l'operazione richiesta
    let response: HttpResponseInit;

    switch (method) {
      case 'GET':
        response = await handleGetData(request, identity, context);
        break;

      case 'POST':
        response = await handleCreateData(request, identity, context);
        break;

      case 'PUT':
        response = await handleUpdateData(request, identity, context);
        break;

      case 'DELETE':
        response = await handleDeleteData(request, identity, context);
        break;

      default:
        throw new AppError(`Metodo ${method} non supportato`, 405);
    }

    // Log dell'operazione completata
    const duration = Date.now() - startTime;
    logger.audit(`Protected API operation completed: ${method}`, {
      userId: identity.objectId,
      duration,
      statusCode: response.status,
    });

    logger.trace('protectedApi', duration, true);

    return response;

  } catch (error) {
    const duration = Date.now() - startTime;
    logger.trace('protectedApi', duration, false);
    return ErrorHandler.handleError(error, context);
  } finally {
    logger.clearContext();
  }
}

/**
 * Determina i ruoli richiesti in base al metodo HTTP
 */
function getRequiredRolesForMethod(method: string): string[] {
  switch (method) {
    case 'GET':
      return ['Reader', 'Editor', 'Admin'];
    case 'POST':
    case 'PUT':
      return ['Editor', 'Admin'];
    case 'DELETE':
      return ['Admin'];
    default:
      return [];
  }
}

/**
 * Handler per recuperare dati (GET)
 * Accessibile a: Reader, Editor, Admin
 */
async function handleGetData(
  request: HttpRequest,
  identity: any,
  context: InvocationContext
): Promise<HttpResponseInit> {
  logger.info('Recupero dati', { userId: identity.objectId });

  // Simulazione di recupero dati
  const data = [
    {
      id: 1,
      title: 'Documento 1',
      content: 'Contenuto del documento 1',
      owner: identity.objectId,
      createdAt: new Date('2024-01-01'),
    },
    {
      id: 2,
      title: 'Documento 2',
      content: 'Contenuto del documento 2',
      owner: identity.objectId,
      createdAt: new Date('2024-01-15'),
    },
  ];

  logger.audit('Data retrieved', {
    userId: identity.objectId,
    count: data.length,
  });

  return ErrorHandler.successResponse({
    data,
    count: data.length,
    retrievedBy: identity.objectId,
  });
}

/**
 * Handler per creare dati (POST)
 * Accessibile a: Editor, Admin
 */
async function handleCreateData(
  request: HttpRequest,
  identity: any,
  context: InvocationContext
): Promise<HttpResponseInit> {
  // Valida il body della richiesta
  ErrorHandler.validateRequest(request, ['title', 'content'], context);

  const body = await request.json() as any;
  const { title, content } = body;

  logger.info('Creazione nuovo documento', {
    userId: identity.objectId,
    title,
  });

  // Simulazione di creazione dati
  const newData = {
    id: Math.floor(Math.random() * 1000),
    title,
    content,
    owner: identity.objectId,
    createdAt: new Date(),
  };

  logger.audit('Data created', {
    userId: identity.objectId,
    dataId: newData.id,
  });

  return ErrorHandler.successResponse({
    message: 'Documento creato con successo',
    data: newData,
  }, 201);
}

/**
 * Handler per aggiornare dati (PUT)
 * Accessibile a: Editor, Admin
 */
async function handleUpdateData(
  request: HttpRequest,
  identity: any,
  context: InvocationContext
): Promise<HttpResponseInit> {
  const dataId = request.params.id;

  if (!dataId) {
    throw new AppError('ID del documento richiesto', 400);
  }

  ErrorHandler.validateRequest(request, ['title', 'content'], context);

  const body = await request.json() as any;
  const { title, content } = body;

  logger.info('Aggiornamento documento', {
    userId: identity.objectId,
    dataId,
  });

  // Simulazione di aggiornamento dati
  const updatedData = {
    id: dataId,
    title,
    content,
    owner: identity.objectId,
    updatedAt: new Date(),
  };

  logger.audit('Data updated', {
    userId: identity.objectId,
    dataId,
  });

  return ErrorHandler.successResponse({
    message: 'Documento aggiornato con successo',
    data: updatedData,
  });
}

/**
 * Handler per eliminare dati (DELETE)
 * Accessibile solo a: Admin
 */
async function handleDeleteData(
  request: HttpRequest,
  identity: any,
  context: InvocationContext
): Promise<HttpResponseInit> {
  const dataId = request.params.id;

  if (!dataId) {
    throw new AppError('ID del documento richiesto', 400);
  }

  logger.info('Eliminazione documento', {
    userId: identity.objectId,
    dataId,
  });

  // Simulazione di eliminazione dati
  logger.audit('Data deleted', {
    userId: identity.objectId,
    dataId,
  });

  return ErrorHandler.successResponse({
    message: 'Documento eliminato con successo',
    dataId,
    deletedBy: identity.objectId,
    deletedAt: new Date(),
  });
}

// Registra la funzione con Azure Functions
app.http('ProtectedApi', {
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  route: 'protected/data/{id?}',
  authLevel: 'anonymous', // L'autenticazione è gestita da Easy Auth/App Service Authentication
  handler: protectedApi,
});
