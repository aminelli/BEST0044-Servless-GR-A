import { app, HttpRequest, HttpResponseInit, InvocationContext } from '@azure/functions';
import { getKeyVaultService } from '../../services/keyVaultService';
import { ErrorHandler } from '../../utils/errorHandler';
import { logger } from '../../utils/logger';
import { AppError } from '../../types';

/**
 * Function 1: Gestione Secrets da Key Vault
 * 
 * Scenario di Sicurezza:
 * - Utilizza Managed Identity per autenticarsi a Key Vault
 * - Implementa logging e audit trail delle operazioni
 * - Gestione errori robusta
 * - Nessun secret hardcoded nel codice
 * 
 * Endpoint:
 * - GET /api/secrets/{secretName} - Recupera un secret
 * - POST /api/secrets - Crea/aggiorna un secret
 * - GET /api/secrets - Lista tutti i secrets
 * - DELETE /api/secrets/{secretName} - Elimina un secret
 */
export async function getSecretFromVault(
  request: HttpRequest,
  context: InvocationContext
): Promise<HttpResponseInit> {
  const startTime = Date.now();

  try {
    logger.setContext({
      functionName: context.functionName,
      invocationId: context.invocationId,
    });

    logger.info('Richiesta ricevuta per gestione secrets', {
      method: request.method,
      url: request.url,
    });

    const keyVaultService = getKeyVaultService();
    const method = request.method.toUpperCase();
    const secretName = request.params.secretName;

    // Verifica connessione al Key Vault
    const isConnected = await keyVaultService.testConnection();
    if (!isConnected) {
      throw new AppError('Impossibile connettersi a Key Vault', 503);
    }

    let response: HttpResponseInit;

    switch (method) {
      case 'GET':
        if (secretName) {
          // Recupera un singolo secret
          response = await handleGetSecret(secretName, keyVaultService, context);
        } else {
          // Lista tutti i secrets
          response = await handleListSecrets(keyVaultService, context);
        }
        break;

      case 'POST':
        // Crea o aggiorna un secret
        response = await handleCreateSecret(request, keyVaultService, context);
        break;

      case 'DELETE':
        // Elimina un secret
        if (!secretName) {
          throw new AppError('Secret name è richiesto per l\'eliminazione', 400);
        }
        response = await handleDeleteSecret(secretName, keyVaultService, context);
        break;

      default:
        throw new AppError(`Metodo ${method} non supportato`, 405);
    }

    // Log di audit per l'operazione completata
    const duration = Date.now() - startTime;
    logger.audit(`Secret operation completed: ${method}`, {
      secretName,
      duration,
      statusCode: response.status,
    });

    logger.trace('getSecretFromVault', duration, true);

    return response;

  } catch (error) {
    const duration = Date.now() - startTime;
    logger.trace('getSecretFromVault', duration, false);
    return ErrorHandler.handleError(error, context);
  } finally {
    logger.clearContext();
  }
}

/**
 * Handler per recuperare un secret
 */
async function handleGetSecret(
  secretName: string,
  keyVaultService: any,
  context: InvocationContext
): Promise<HttpResponseInit> {
  logger.info(`Recupero secret: ${secretName}`);

  const result = await keyVaultService.getSecret(secretName);

  if (!result.success) {
    throw new AppError(result.error || 'Errore nel recupero del secret', 500);
  }

  logger.audit('Secret retrieved', { secretName });

  return ErrorHandler.successResponse({
    secretName,
    secretValue: result.data,
    retrievedAt: result.timestamp,
  });
}

/**
 * Handler per listare tutti i secrets
 */
async function handleListSecrets(
  keyVaultService: any,
  context: InvocationContext
): Promise<HttpResponseInit> {
  logger.info('Lista di tutti i secrets');

  const result = await keyVaultService.listSecrets();

  if (!result.success) {
    throw new AppError(result.error || 'Errore nella lista dei secrets', 500);
  }

  logger.audit('Secrets listed', { count: result.data?.length });

  return ErrorHandler.successResponse({
    secrets: result.data,
    count: result.data?.length || 0,
  });
}

/**
 * Handler per creare/aggiornare un secret
 */
async function handleCreateSecret(
  request: HttpRequest,
  keyVaultService: any,
  context: InvocationContext
): Promise<HttpResponseInit> {
  // Valida il body della richiesta
  ErrorHandler.validateRequest(request, ['secretName', 'secretValue'], context);

  const body = await request.json() as any;
  const { secretName, secretValue } = body;

  logger.info(`Creazione/Aggiornamento secret: ${secretName}`);

  const result = await keyVaultService.setSecret(secretName, secretValue);

  if (!result.success) {
    throw new AppError(result.error || 'Errore nella creazione del secret', 500);
  }

  logger.audit('Secret created/updated', { secretName });

  return ErrorHandler.successResponse({
    secretName,
    message: 'Secret creato/aggiornato con successo',
    timestamp: result.timestamp,
  }, 201);
}

/**
 * Handler per eliminare un secret
 */
async function handleDeleteSecret(
  secretName: string,
  keyVaultService: any,
  context: InvocationContext
): Promise<HttpResponseInit> {
  logger.info(`Eliminazione secret: ${secretName}`);

  const result = await keyVaultService.deleteSecret(secretName);

  if (!result.success) {
    throw new AppError(result.error || 'Errore nell\'eliminazione del secret', 500);
  }

  logger.audit('Secret deleted', { secretName });

  return ErrorHandler.successResponse({
    secretName,
    message: 'Secret eliminato con successo',
    timestamp: result.timestamp,
  });
}

// Registra la funzione con Azure Functions
app.http('GetSecretFromVault', {
  methods: ['GET', 'POST', 'DELETE'],
  route: 'secrets/{secretName?}',
  authLevel: 'function',
  handler: getSecretFromVault,
});
