import { SecretClient } from '@azure/keyvault-secrets';
import { KeyClient } from '@azure/keyvault-keys';
import { CertificateClient } from '@azure/keyvault-certificates';
import { DefaultAzureCredential, ManagedIdentityCredential } from '@azure/identity';
import { KeyVaultConfig, OperationResult, AppError } from '../types';
import { logger } from '../utils/logger';

/**
 * Servizio per la gestione di Azure Key Vault
 * Utilizza Managed Identity per l'autenticazione
 */
export class KeyVaultService {
  private secretClient: SecretClient;
  private keyClient: KeyClient;
  private certificateClient: CertificateClient;
  private credential: DefaultAzureCredential | ManagedIdentityCredential;

  constructor(private config: KeyVaultConfig) {
    // Utilizza DefaultAzureCredential per supportare diversi metodi di autenticazione
    // In produzione su Azure, utilizzerà automaticamente la Managed Identity
    // In sviluppo locale, può utilizzare Azure CLI, Visual Studio Code, ecc.
    this.credential = new DefaultAzureCredential();

    this.secretClient = new SecretClient(this.config.keyVaultUrl, this.credential);
    this.keyClient = new KeyClient(this.config.keyVaultUrl, this.credential);
    this.certificateClient = new CertificateClient(this.config.keyVaultUrl, this.credential);

    logger.info('KeyVaultService inizializzato', {
      keyVaultUrl: this.config.keyVaultUrl,
    });
  }

  /**
   * Recupera un secret da Key Vault
   * @param secretName Nome del secret da recuperare
   * @returns OperationResult con il valore del secret
   */
  async getSecret(secretName: string): Promise<OperationResult<string>> {
    try {
      logger.info(`Recupero secret: ${secretName}`);

      const secret = await this.secretClient.getSecret(secretName);

      if (!secret.value) {
        throw new AppError(`Secret ${secretName} non ha un valore`, 404);
      }

      logger.info(`Secret ${secretName} recuperato con successo`);

      return {
        success: true,
        data: secret.value,
        timestamp: new Date(),
      };
    } catch (error) {
      logger.error(`Errore nel recupero del secret ${secretName}`, { error });

      return {
        success: false,
        error: error instanceof Error ? error.message : 'Errore sconosciuto',
        timestamp: new Date(),
      };
    }
  }

  /**
   * Imposta un secret in Key Vault
   * @param secretName Nome del secret
   * @param secretValue Valore del secret
   * @returns OperationResult
   */
  async setSecret(secretName: string, secretValue: string): Promise<OperationResult<void>> {
    try {
      logger.info(`Impostazione secret: ${secretName}`);

      await this.secretClient.setSecret(secretName, secretValue);

      logger.info(`Secret ${secretName} impostato con successo`);

      return {
        success: true,
        timestamp: new Date(),
      };
    } catch (error) {
      logger.error(`Errore nell'impostazione del secret ${secretName}`, { error });

      return {
        success: false,
        error: error instanceof Error ? error.message : 'Errore sconosciuto',
        timestamp: new Date(),
      };
    }
  }

  /**
   * Lista tutti i secrets in Key Vault
   * @returns OperationResult con array di nomi dei secrets
   */
  async listSecrets(): Promise<OperationResult<string[]>> {
    try {
      logger.info('Lista di tutti i secrets');

      const secretNames: string[] = [];

      for await (const secretProperties of this.secretClient.listPropertiesOfSecrets()) {
        secretNames.push(secretProperties.name);
      }

      logger.info(`Trovati ${secretNames.length} secrets`);

      return {
        success: true,
        data: secretNames,
        timestamp: new Date(),
      };
    } catch (error) {
      logger.error('Errore nella lista dei secrets', { error });

      return {
        success: false,
        error: error instanceof Error ? error.message : 'Errore sconosciuto',
        timestamp: new Date(),
      };
    }
  }

  /**
   * Elimina un secret da Key Vault
   * @param secretName Nome del secret da eliminare
   * @returns OperationResult
   */
  async deleteSecret(secretName: string): Promise<OperationResult<void>> {
    try {
      logger.info(`Eliminazione secret: ${secretName}`);

      const poller = await this.secretClient.beginDeleteSecret(secretName);
      await poller.pollUntilDone();

      logger.info(`Secret ${secretName} eliminato con successo`);

      return {
        success: true,
        timestamp: new Date(),
      };
    } catch (error) {
      logger.error(`Errore nell'eliminazione del secret ${secretName}`, { error });

      return {
        success: false,
        error: error instanceof Error ? error.message : 'Errore sconosciuto',
        timestamp: new Date(),
      };
    }
  }

  /**
   * Verifica la connessione al Key Vault
   * @returns true se la connessione è valida
   */
  async testConnection(): Promise<boolean> {
    try {
      // Tenta di listare i secrets per verificare la connessione
      const result = await this.listSecrets();
      return result.success;
    } catch (error) {
      logger.error('Errore nel test della connessione a Key Vault', { error });
      return false;
    }
  }
}

// Istanza singleton del servizio
let keyVaultServiceInstance: KeyVaultService | null = null;

/**
 * Factory per ottenere l'istanza del KeyVaultService
 */
export function getKeyVaultService(): KeyVaultService {
  if (!keyVaultServiceInstance) {
    const keyVaultUrl = process.env.AZURE_KEY_VAULT_URL;

    if (!keyVaultUrl) {
      throw new AppError('AZURE_KEY_VAULT_URL non configurato', 500, true);
    }

    keyVaultServiceInstance = new KeyVaultService({ keyVaultUrl });
  }

  return keyVaultServiceInstance;
}
