import { DefaultAzureCredential, ManagedIdentityCredential } from '@azure/identity';
import { HttpRequest } from '@azure/functions';
import { AuthenticatedIdentity, AppError } from '../types';
import { logger } from '../utils/logger';

/**
 * Servizio per la gestione dell'autenticazione e autorizzazione
 */
export class AuthService {
  private credential: DefaultAzureCredential | ManagedIdentityCredential;

  constructor() {
    this.credential = new DefaultAzureCredential();
  }

  /**
   * Verifica i ruoli dell'utente autenticato
   * @param request Richiesta HTTP
   * @param requiredRoles Ruoli richiesti
   * @returns true se l'utente ha i ruoli necessari
   */
  async verifyRoles(request: HttpRequest, requiredRoles: string[]): Promise<boolean> {
    try {
      const identity = await this.getIdentity(request);

      if (!identity || !identity.roles) {
        logger.warn('Nessun ruolo trovato per l\'utente');
        return false;
      }

      // Verifica se l'utente ha almeno uno dei ruoli richiesti
      const hasRequiredRole = requiredRoles.some(role => identity.roles?.includes(role));

      if (!hasRequiredRole) {
        logger.warn('Utente non ha i ruoli richiesti', {
          userRoles: identity.roles,
          requiredRoles,
        });
      }

      return hasRequiredRole;
    } catch (error) {
      logger.error('Errore nella verifica dei ruoli', { error });
      return false;
    }
  }

  /**
   * Estrae l'identità dell'utente dalla richiesta
   * @param request Richiesta HTTP
   * @returns Identità autenticata
   */
  async getIdentity(request: HttpRequest): Promise<AuthenticatedIdentity | null> {
    try {
      // In Azure Functions con Easy Auth/App Service Authentication,
      // le informazioni dell'utente sono disponibili negli headers
      const clientPrincipalHeader = request.headers.get('x-ms-client-principal');

      if (!clientPrincipalHeader) {
        logger.warn('Header x-ms-client-principal non trovato');
        return null;
      }

      // Decodifica il JWT Base64
      const clientPrincipal = JSON.parse(
        Buffer.from(clientPrincipalHeader, 'base64').toString('utf-8')
      );

      const identity: AuthenticatedIdentity = {
        objectId: clientPrincipal.userId || clientPrincipal.objectId,
        tenantId: clientPrincipal.tenantId,
        principalType: clientPrincipal.identityProvider || 'ManagedIdentity',
        roles: clientPrincipal.claims
          ?.filter((claim: any) => claim.typ === 'roles')
          .map((claim: any) => claim.val) || [],
      };

      logger.info('Identità estratta con successo', {
        objectId: identity.objectId,
        roles: identity.roles,
      });

      return identity;
    } catch (error) {
      logger.error('Errore nell\'estrazione dell\'identità', { error });
      return null;
    }
  }

  /**
   * Verifica il token Bearer nella richiesta
   * @param request Richiesta HTTP
   * @returns true se il token è valido
   */
  async verifyBearerToken(request: HttpRequest): Promise<boolean> {
    try {
      const authHeader = request.headers.get('authorization');

      if (!authHeader || !authHeader.startsWith('Bearer ')) {
        logger.warn('Authorization header mancante o non valido');
        return false;
      }

      // In un'applicazione reale, qui si dovrebbe validare il token JWT
      // Utilizzando librerie come jsonwebtoken e verificando la firma con le chiavi pubbliche di Azure AD
      
      logger.info('Token Bearer presente');
      return true;
    } catch (error) {
      logger.error('Errore nella verifica del token Bearer', { error });
      return false;
    }
  }

  /**
   * Verifica se l'utente è autenticato
   * @param request Richiesta HTTP
   * @returns true se l'utente è autenticato
   */
  async isAuthenticated(request: HttpRequest): Promise<boolean> {
    const identity = await this.getIdentity(request);
    return identity !== null;
  }

  /**
   * Ottiene le credenziali per l'accesso alle risorse Azure
   * @returns Credenziali Azure
   */
  getCredential(): DefaultAzureCredential | ManagedIdentityCredential {
    return this.credential;
  }
}

// Istanza singleton del servizio
let authServiceInstance: AuthService | null = null;

/**
 * Factory per ottenere l'istanza del AuthService
 */
export function getAuthService(): AuthService {
  if (!authServiceInstance) {
    authServiceInstance = new AuthService();
  }

  return authServiceInstance;
}
