/**
 * Tipi personalizzati per l'applicazione Azure Functions
 */

/**
 * Configurazione per il servizio Key Vault
 */
export interface KeyVaultConfig {
  keyVaultUrl: string;
}

/**
 * Risultato dell'operazione con esito e messaggio
 */
export interface OperationResult<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
  timestamp: Date;
}

/**
 * Informazioni sull'identità autenticata
 */
export interface AuthenticatedIdentity {
  objectId: string;
  tenantId?: string;
  principalType: 'User' | 'ServicePrincipal' | 'ManagedIdentity';
  roles?: string[];
}

/**
 * Metadata per il logging
 */
export interface LogMetadata {
  operationId?: string;
  userId?: string;
  functionName?: string;
  [key: string]: unknown;
}

/**
 * Livelli di log supportati
 */
export enum LogLevel {
  DEBUG = 'DEBUG',
  INFO = 'INFO',
  WARN = 'WARN',
  ERROR = 'ERROR',
}

/**
 * Errore personalizzato dell'applicazione
 */
export class AppError extends Error {
  constructor(
    message: string,
    public statusCode: number = 500,
    public isOperational: boolean = true,
    public details?: unknown
  ) {
    super(message);
    this.name = this.constructor.name;
    Error.captureStackTrace(this, this.constructor);
  }
}

/**
 * Contesto della richiesta HTTP
 */
export interface RequestContext {
  correlationId: string;
  timestamp: Date;
  userId?: string;
  clientIp?: string;
}
