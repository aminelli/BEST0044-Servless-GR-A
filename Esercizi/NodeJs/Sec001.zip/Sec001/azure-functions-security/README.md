# Azure Functions Security Project

Progetto dimostrativo di Azure Functions con TypeScript che implementa scenari di sicurezza avanzati utilizzando Azure Key Vault, Managed Identity e RBAC.

## 📋 Indice

- [Caratteristiche](#caratteristiche)
- [Architettura](#architettura)
- [Prerequisiti](#prerequisiti)
- [Installazione Rapida](#installazione-rapida)
- [Struttura del Progetto](#struttura-del-progetto)
- [Azure Functions](#azure-functions)
- [Deployment](#deployment)
- [Configurazione](#configurazione)
- [Test](#test)
- [Sicurezza](#sicurezza)
- [Documentazione](#documentazione)

## ✨ Caratteristiche

### Funzionalità Principali

- ✅ **2 Azure Functions** con scenari di sicurezza differenti
- ✅ **Managed Identity** per autenticazione senza password
- ✅ **Azure Key Vault** integration per gestione secrets
- ✅ **RBAC (Role-Based Access Control)** con autorizzazione basata su ruoli
- ✅ **Logging strutturato** compatibile con Application Insights
- ✅ **Infrastructure as Code** con Bicep
- ✅ **TypeScript** strongly typed
- ✅ **SDK ufficiali Microsoft** (@azure/*)

### Tecnologie Utilizzate

- **Runtime**: Node.js 18.x LTS
- **Linguaggio**: TypeScript 5.x
- **Cloud**: Microsoft Azure
- **Functions Runtime**: v4
- **SDK**: Azure SDK for JavaScript/TypeScript

## 🏗️ Architettura

Il progetto implementa due scenari di sicurezza distinti:

### Function 1: GetSecretFromVault
**Scenario**: Accesso sicuro a risorse protette

- Recupera secrets da Azure Key Vault
- Autenticazione tramite Managed Identity
- Audit trail completo delle operazioni
- Endpoints:
  - `GET /api/secrets/{secretName}` - Recupera un secret
  - `POST /api/secrets` - Crea/aggiorna un secret
  - `GET /api/secrets` - Lista tutti i secrets
  - `DELETE /api/secrets/{secretName}` - Elimina un secret

### Function 2: ProtectedApi
**Scenario**: API sicura con autorizzazione RBAC

- Autorizzazione basata su ruoli (Reader, Editor, Admin)
- Validazione identità e token
- Gestione errori robusta
- Endpoints:
  - `GET /api/protected/data` - Lettura (Reader, Editor, Admin)
  - `POST /api/protected/data` - Creazione (Editor, Admin)
  - `PUT /api/protected/data/{id}` - Aggiornamento (Editor, Admin)
  - `DELETE /api/protected/data/{id}` - Eliminazione (Admin)

Per maggiori dettagli, vedere [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

## 📦 Prerequisiti

### Software Richiesto

1. **Node.js** 18.x LTS o superiore
   ```bash
   node --version  # Deve essere >= 18.0.0
   ```

2. **Azure Functions Core Tools** v4
   ```bash
   npm install -g azure-functions-core-tools@4 --unsafe-perm true
   func --version
   ```

3. **Azure CLI**
   ```bash
   # Windows (tramite MSI installer)
   # Download da: https://aka.ms/installazurecliwindows
   
   az --version
   az login
   ```

4. **TypeScript**
   ```bash
   npm install -g typescript
   tsc --version
   ```

### Risorse Azure

- Sottoscrizione Azure attiva
- Permessi per creare risorse (Contributor o superiore)

## 🚀 Installazione Rapida

### 1. Clone del Repository

```bash
git clone <repository-url>
cd azure-functions-security
```

### 2. Installazione Dipendenze

```bash
npm install
```

### 3. Configurazione Locale

```bash
# Copia il file di esempio
cp local.settings.json.example local.settings.json

# Modifica local.settings.json con i tuoi valori
# AZURE_KEY_VAULT_URL=https://<your-keyvault>.vault.azure.net/
```

### 4. Build del Progetto

```bash
npm run build
```

### 5. Esecuzione Locale

```bash
npm start
```

Le functions saranno disponibili su `http://localhost:7071`

## 📁 Struttura del Progetto

```
azure-functions-security/
├── src/
│   ├── functions/          # Azure Functions
│   │   ├── getSecretFromVault/
│   │   └── protectedApi/
│   ├── services/           # Servizi business logic
│   │   ├── keyVaultService.ts
│   │   └── authService.ts
│   ├── utils/              # Utilità
│   │   ├── logger.ts
│   │   └── errorHandler.ts
│   └── types/              # Tipi TypeScript
│       └── index.ts
├── infrastructure/         # Infrastructure as Code
│   └── bicep/
│       ├── main.bicep
│       ├── keyVault.bicep
│       ├── functions.bicep
│       └── rbac.bicep
├── docs/                   # Documentazione
│   ├── SETUP-MANUAL.md
│   ├── ARCHITECTURE.md
│   └── SECURITY-SCENARIOS.md
├── package.json
├── tsconfig.json
├── host.json
└── README.md
```

## 🎯 Azure Functions

### Comandi Generazione (utilizzati per creare il progetto)

```bash
# Inizializzazione progetto
func init azure-functions-security --typescript

# Aggiunta Function 1
func new --name GetSecretFromVault --template "HTTP trigger" --language typescript

# Aggiunta Function 2
func new --name ProtectedApi --template "HTTP trigger" --language typescript
```

### Esecuzione Locale

```bash
# Build + Start
npm start

# Solo build
npm run build

# Watch mode (rebuild automatico)
npm run watch
```

### Test delle Functions

```bash
# Function 1: Lista secrets
curl http://localhost:7071/api/secrets

# Function 1: Recupera un secret
curl http://localhost:7071/api/secrets/mySecret

# Function 2: GET data
curl http://localhost:7071/api/protected/data
```

## 🚢 Deployment

### Deployment con Infrastructure as Code

```bash
# 1. Login ad Azure
az login

# 2. Crea Resource Group
az group create --name rg-funcapp-security-dev --location eastus

# 3. Deploy Infrastructure
az deployment group create \
  --resource-group rg-funcapp-security-dev \
  --template-file infrastructure/bicep/main.bicep \
  --parameters environmentName=dev

# 4. Deploy Codice Function App
npm run build
func azure functionapp publish <function-app-name>
```

Per deployment manuale, vedere [docs/SETUP-MANUAL.md](docs/SETUP-MANUAL.md).

## ⚙️ Configurazione

### Variabili d'Ambiente

| Variabile | Descrizione | Richiesto |
|-----------|-------------|-----------|
| `AZURE_KEY_VAULT_URL` | URL del Key Vault | Sì |
| `APPLICATIONINSIGHTS_CONNECTION_STRING` | Connection string App Insights | No |
| `NODE_ENV` | Ambiente (development/production) | No |
| `AZURE_LOG_LEVEL` | Livello log Azure SDK | No |

### Application Settings (Azure)

Configurate automaticamente dal deployment Bicep:
- `AzureWebJobsStorage`
- `FUNCTIONS_WORKER_RUNTIME`
- `FUNCTIONS_EXTENSION_VERSION`
- `WEBSITE_NODE_DEFAULT_VERSION`

## 🧪 Test

```bash
# Run tests (quando implementati)
npm test

# Lint
npm run lint

# Format
npm run format
```

## 🔒 Sicurezza

### Best Practices Implementate

1. **Nessun Secret Hardcoded**: Tutti i secrets in Key Vault
2. **Managed Identity**: Autenticazione senza password
3. **RBAC**: Principle of Least Privilege
4. **HTTPS Only**: Comunicazioni cifrate
5. **Logging Completo**: Audit trail di tutte le operazioni
6. **Validation Input**: Sanitizzazione di tutti gli input
7. **Error Handling**: Nessuna informazione sensibile negli errori

### Ruoli RBAC Assegnati

- **Key Vault Secrets User**: Lettura secrets
- **Key Vault Secrets Officer**: Scrittura secrets

Vedere [docs/SECURITY-SCENARIOS.md](docs/SECURITY-SCENARIOS.md) per dettagli.

## 📚 Documentazione

- **[SETUP-MANUAL.md](docs/SETUP-MANUAL.md)** - Guida configurazione manuale passo-passo
- **[ARCHITECTURE.md](docs/ARCHITECTURE.md)** - Architettura dettagliata del sistema
- **[SECURITY-SCENARIOS.md](docs/SECURITY-SCENARIOS.md)** - Scenari di sicurezza implementati
- **[Infrastructure README](infrastructure/README.md)** - Documentazione IaC Bicep

## 📄 License

MIT

## 🤝 Contributi

Contributi, issues e feature requests sono benvenuti!

## 👥 Autori

- Progetto generato con Azure Functions Core Tools
- Template basato su best practices Microsoft Azure
