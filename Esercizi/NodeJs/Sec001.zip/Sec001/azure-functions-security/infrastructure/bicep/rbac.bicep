@description('Principal ID della Function App (Managed Identity)')
param functionAppPrincipalId string

@description('Nome del Key Vault')
param keyVaultName string

// Definizione dei ruoli built-in di Azure
// Key Vault Secrets User
var keyVaultSecretsUserRoleId = '4633458b-17de-408a-b874-0445c86b69e6'

// Key Vault Secrets Officer (per operazioni di scrittura)
var keyVaultSecretsOfficerRoleId = 'b86a8fe4-44ce-4948-aee5-eccb2c155cd7'

// Riferimento al Key Vault esistente
resource keyVault 'Microsoft.KeyVault/vaults@2023-07-01' existing = {
  name: keyVaultName
}

// Assegnazione ruolo: Key Vault Secrets User
// Permette alla Function App di leggere i secrets
resource keyVaultSecretsUserRoleAssignment 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(keyVault.id, functionAppPrincipalId, keyVaultSecretsUserRoleId)
  scope: keyVault
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', keyVaultSecretsUserRoleId)
    principalId: functionAppPrincipalId
    principalType: 'ServicePrincipal'
  }
}

// Assegnazione ruolo: Key Vault Secrets Officer
// Permette alla Function App di creare, aggiornare e eliminare secrets
resource keyVaultSecretsOfficerRoleAssignment 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(keyVault.id, functionAppPrincipalId, keyVaultSecretsOfficerRoleId)
  scope: keyVault
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', keyVaultSecretsOfficerRoleId)
    principalId: functionAppPrincipalId
    principalType: 'ServicePrincipal'
  }
}

// Output
output keyVaultSecretsUserRoleAssignmentId string = keyVaultSecretsUserRoleAssignment.id
output keyVaultSecretsOfficerRoleAssignmentId string = keyVaultSecretsOfficerRoleAssignment.id
