// Parametri principali
@description('Nome dell\'ambiente (dev, staging, prod)')
param environmentName string = 'dev'

@description('Location per le risorse Azure')
param location string = resourceGroup().location

@description('Nome dell\'applicazione')
param applicationName string = 'funcapp-security'

@description('Tag per le risorse')
param tags object = {
  Environment: environmentName
  Application: applicationName
  ManagedBy: 'Bicep'
}

// Variabili
var functionAppName = '${applicationName}-${environmentName}-${uniqueString(resourceGroup().id)}'
var keyVaultName = 'kv-${applicationName}-${environmentName}-${uniqueString(resourceGroup().id)}'
var storageAccountName = 'st${replace(applicationName, '-', '')}${environmentName}${uniqueString(resourceGroup().id)}'
var appInsightsName = 'appi-${applicationName}-${environmentName}'
var appServicePlanName = 'asp-${applicationName}-${environmentName}'

// Modulo Key Vault
module keyVault 'keyVault.bicep' = {
  name: 'keyVaultDeployment'
  params: {
    keyVaultName: take(keyVaultName, 24) // Key Vault name max 24 chars
    location: location
    tags: tags
  }
}

// Modulo Azure Functions
module functionApp 'functions.bicep' = {
  name: 'functionAppDeployment'
  params: {
    functionAppName: functionAppName
    location: location
    tags: tags
    storageAccountName: storageAccountName
    appServicePlanName: appServicePlanName
    appInsightsName: appInsightsName
    keyVaultName: keyVault.outputs.keyVaultName
  }
}

// Modulo RBAC
module rbac 'rbac.bicep' = {
  name: 'rbacDeployment'
  params: {
    functionAppPrincipalId: functionApp.outputs.functionAppPrincipalId
    keyVaultName: keyVault.outputs.keyVaultName
  }
  dependsOn: [
    keyVault
    functionApp
  ]
}

// Output
output functionAppName string = functionApp.outputs.functionAppName
output functionAppUrl string = functionApp.outputs.functionAppUrl
output keyVaultName string = keyVault.outputs.keyVaultName
output keyVaultUri string = keyVault.outputs.keyVaultUri
output appInsightsInstrumentationKey string = functionApp.outputs.appInsightsInstrumentationKey
