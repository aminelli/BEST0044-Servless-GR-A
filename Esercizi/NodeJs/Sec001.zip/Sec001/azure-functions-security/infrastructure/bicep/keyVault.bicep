@description('Nome del Key Vault')
param keyVaultName string

@description('Location per il Key Vault')
param location string

@description('Tag per il Key Vault')
param tags object = {}

@description('SKU del Key Vault')
@allowed([
  'standard'
  'premium'
])
param skuName string = 'standard'

@description('Abilita soft delete')
param enableSoftDelete bool = true

@description('Giorni di retention per soft delete')
@minValue(7)
@maxValue(90)
param softDeleteRetentionInDays int = 90

@description('Abilita purge protection')
param enablePurgeProtection bool = true

@description('Abilita RBAC per autorizzazione')
param enableRbacAuthorization bool = true

// Risorsa Key Vault
resource keyVault 'Microsoft.KeyVault/vaults@2023-07-01' = {
  name: keyVaultName
  location: location
  tags: tags
  properties: {
    sku: {
      family: 'A'
      name: skuName
    }
    tenantId: subscription().tenantId
    enableSoftDelete: enableSoftDelete
    softDeleteRetentionInDays: softDeleteRetentionInDays
    enablePurgeProtection: enablePurgeProtection
    enableRbacAuthorization: enableRbacAuthorization
    
    // Network ACL - Consente accesso da tutti i network (per sviluppo)
    // In produzione, configurare con regole più restrittive
    networkAcls: {
      bypass: 'AzureServices'
      defaultAction: 'Allow'
      ipRules: []
      virtualNetworkRules: []
    }
    
    // Impostazioni di accesso
    publicNetworkAccess: 'Enabled'
    
    // Diagnostic settings saranno configurati separatamente se necessario
  }
}

// Secrets di esempio (possono essere aggiunti tramite script post-deployment)
// Nota: In produzione, i secrets dovrebbero essere aggiunti tramite pipeline CI/CD o manualmente

// Output
output keyVaultName string = keyVault.name
output keyVaultUri string = keyVault.properties.vaultUri
output keyVaultResourceId string = keyVault.id
