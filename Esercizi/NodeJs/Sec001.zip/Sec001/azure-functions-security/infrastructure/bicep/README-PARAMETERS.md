# File di Parametri Bicep

Questa cartella contiene i file di parametri per il deployment dell'infrastruttura Azure.

## File Disponibili

| File | Ambiente | Descrizione |
|------|----------|-------------|
| `parameters.json` | Development | Parametri per ambiente di sviluppo |
| `parameters.staging.json` | Staging | Parametri per ambiente di staging/test |
| `parameters.prod.json` | Production | Parametri per ambiente di produzione |
| `parameters.example.json` | Template | Template di esempio per creare parametri custom |

## Utilizzo

### Deploy con parametri Development

```bash
az deployment group create \
  --resource-group rg-funcapp-security-dev \
  --template-file main.bicep \
  --parameters @parameters.json
```

### Deploy con parametri Staging

```bash
az deployment group create \
  --resource-group rg-funcapp-security-staging \
  --template-file main.bicep \
  --parameters @parameters.staging.json
```

### Deploy con parametri Production

```bash
az deployment group create \
  --resource-group rg-funcapp-security-prod \
  --template-file main.bicep \
  --parameters @parameters.prod.json
```

## Personalizzazione

Per creare parametri personalizzati:

1. Copia il file `parameters.example.json` con un nuovo nome
2. Modifica i valori secondo le tue esigenze
3. Usa il nuovo file nel comando di deployment

```bash
# Copia il template
cp parameters.example.json parameters.custom.json

# Modifica il file (usa il tuo editor preferito)
code parameters.custom.json

# Deploy con i parametri custom
az deployment group create \
  --resource-group rg-custom \
  --template-file main.bicep \
  --parameters @parameters.custom.json
```

## Parametri Disponibili

### environmentName
- **Tipo**: `string`
- **Default**: `dev`
- **Valori**: `dev`, `staging`, `prod`
- **Descrizione**: Nome dell'ambiente per naming convention e tagging

### location
- **Tipo**: `string`
- **Default**: Location del Resource Group
- **Esempi**: `eastus`, `westeurope`, `northeurope`
- **Descrizione**: Region Azure dove deployare le risorse

### applicationName
- **Tipo**: `string`
- **Default**: `funcapp-security`
- **Descrizione**: Nome base dell'applicazione usato per naming delle risorse

### tags
- **Tipo**: `object`
- **Descrizione**: Tag da applicare a tutte le risorse
- **Campi consigliati**:
  - `Environment`: Ambiente (dev/staging/prod)
  - `Application`: Nome applicazione
  - `ManagedBy`: Strumento di gestione (Bicep)
  - `Project`: Nome progetto
  - `CostCenter`: Centro di costo
  - `Owner`: Email del proprietario

## Naming Convention

Le risorse verranno create con i seguenti nomi (usando `uniqueString` per garantire unicità):

- **Function App**: `{applicationName}-{environmentName}-{uniqueString}`
- **Key Vault**: `kv-{applicationName}-{environmentName}-{uniqueString}` (max 24 caratteri)
- **Storage Account**: `st{applicationName}{environmentName}{uniqueString}`
- **App Service Plan**: `asp-{applicationName}-{environmentName}`
- **Application Insights**: `appi-{applicationName}-{environmentName}`

Esempio con `applicationName=funcapp-security` e `environmentName=dev`:
- Function App: `funcapp-security-dev-abc123def`
- Key Vault: `kv-funcapp-security-dev-abc` (troncato a 24 caratteri)
- Storage: `stfuncappsecuritydevabc123`

## Best Practices

### Security
- ✅ Non committare file di parametri con valori sensibili in Git
- ✅ Usa Azure Key Vault per secrets
- ✅ Separa i parametri per ambiente
- ✅ Usa pipeline CI/CD per gestire i parametri in produzione

### Naming
- ✅ Usa nomi descrittivi ma concisi
- ✅ Segui le Azure naming conventions
- ✅ Includi l'ambiente nel nome
- ✅ Usa tag per metadata aggiuntivi

### Cost Management
- ✅ Usa tag `CostCenter` per tracking dei costi
- ✅ Usa tag `Environment` per filtrare i costi per ambiente
- ✅ Rivedi regolarmente le risorse tramite tag `Owner`

## Troubleshooting

### Errore: "Key Vault name too long"
Il nome del Key Vault viene automaticamente troncato a 24 caratteri. Se riscontri problemi, usa un `applicationName` più breve.

### Errore: "Storage account name invalid"
Il nome dello storage account deve essere univoco globalmente e contenere solo caratteri alfanumerici minuscoli. Viene generato automaticamente rimuovendo i trattini.

### Errore: "Location not available"
Verifica che la location specificata supporti tutte le risorse necessarie (Functions, Key Vault, Storage). Usa `az account list-locations` per vedere le location disponibili.

---

**Suggerimento**: Per un deployment più robusto, considera l'uso di Azure DevOps o GitHub Actions con i file di parametri gestiti come segreti nella pipeline.
