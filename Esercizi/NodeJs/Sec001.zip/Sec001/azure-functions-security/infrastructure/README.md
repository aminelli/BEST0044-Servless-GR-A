# Infrastructure as Code - Bicep

Questa cartella contiene i file Bicep per il deployment dell'infrastruttura Azure.

## Struttura File

- **main.bicep**: File principale che orchestra il deployment di tutte le risorse
- **keyVault.bicep**: Modulo per Azure Key Vault
- **functions.bicep**: Modulo per Azure Functions e risorse correlate
- **rbac.bicep**: Modulo per le assegnazioni RBAC

## Deployment

### Prerequisiti

1. Azure CLI installato
2. Autenticazione ad Azure: `az login`
3. Sottoscrizione Azure selezionata: `az account set --subscription <subscription-id>`

### Comandi di Deployment

#### Deployment in un nuovo Resource Group

```bash
# Creare un resource group
az group create --name rg-funcapp-security-dev --location eastus

# Deploy dell'infrastruttura
az deployment group create \
  --resource-group rg-funcapp-security-dev \
  --template-file main.bicep \
  --parameters environmentName=dev \
  --parameters applicationName=funcapp-security
```

#### Deployment con file di parametri

Sono disponibili file di parametri pre-configurati per ogni ambiente:
- **parameters.json** - Ambiente Development
- **parameters.staging.json** - Ambiente Staging
- **parameters.prod.json** - Ambiente Production

**Development:**

```bash
az deployment group create \
  --resource-group rg-funcapp-security-dev \
  --template-file bicep/main.bicep \
  --parameters @bicep/parameters.json
```

**Staging:**

```bash
az deployment group create \
  --resource-group rg-funcapp-security-staging \
  --template-file bicep/main.bicep \
  --parameters @bicep/parameters.staging.json
```

**Production:**

```bash
az deployment group create \
  --resource-group rg-funcapp-security-prod \
  --template-file bicep/main.bicep \
  --parameters @bicep/parameters.prod.json
```

### Personalizzazione dei Parametri

#### Parametri Disponibili

| Parametro | Tipo | Default | Descrizione |
|-----------|------|---------|-------------|
| `environmentName` | string | `dev` | Nome dell'ambiente (dev, staging, prod) |
| `location` | string | Resource Group location | Region Azure per le risorse |
| `applicationName` | string | `funcapp-security` | Nome base dell'applicazione |
| `tags` | object | Vedi sotto | Tag da applicare alle risorse |

#### Esempio di Personalizzazione

```json
{
  "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentParameters.json#",
  "contentVersion": "1.0.0.0",
  "parameters": {
    "environmentName": {
      "value": "dev"
    },
    "location": {
      "value": "westeurope"
    },
    "applicationName": {
      "value": "my-custom-app"
    },
    "tags": {
      "value": {
        "Environment": "dev",
        "Application": "my-custom-app",
        "ManagedBy": "Bicep",
        "Project": "My Project Name",
        "CostCenter": "IT-Development",
        "Owner": "team@company.com"
      }
    }
  }
}
```

#### Validazione del template

```bash
az deployment group validate \
  --resource-group rg-funcapp-security-dev \
  --template-file main.bicep \
  --parameters environmentName=dev
```

#### What-if deployment

```bash
az deployment group what-if \
  --resource-group rg-funcapp-security-dev \
  --template-file main.bicep \
  --parameters environmentName=dev
```

### Deployment End-to-End

Script completo per deployment in ambiente Development:

```powershell
# 1. Imposta variabili
$RESOURCE_GROUP = "rg-funcapp-security-dev"
$LOCATION = "eastus"
$SUBSCRIPTION_ID = "<your-subscription-id>"

# 2. Login e selezione subscription
az login
az account set --subscription $SUBSCRIPTION_ID

# 3. Crea Resource Group
az group create `
  --name $RESOURCE_GROUP `
  --location $LOCATION

# 4. Valida il template
az deployment group validate `
  --resource-group $RESOURCE_GROUP `
  --template-file bicep/main.bicep `
  --parameters @bicep/parameters.json

# 5. Preview delle modifiche (What-If)
az deployment group what-if `
  --resource-group $RESOURCE_GROUP `
  --template-file bicep/main.bicep `
  --parameters @bicep/parameters.json

# 6. Deploy dell'infrastruttura
az deployment group create `
  --resource-group $RESOURCE_GROUP `
  --template-file bicep/main.bicep `
  --parameters @bicep/parameters.json `
  --name "funcapp-security-$(Get-Date -Format 'yyyyMMdd-HHmmss')"

# 7. Ottieni gli output del deployment
$FUNCTION_APP_NAME = az deployment group show `
  --resource-group $RESOURCE_GROUP `
  --name "funcapp-security-latest" `
  --query "properties.outputs.functionAppName.value" `
  --output tsv

$KEY_VAULT_NAME = az deployment group show `
  --resource-group $RESOURCE_GROUP `
  --name "funcapp-security-latest" `
  --query "properties.outputs.keyVaultName.value" `
  --output tsv

Write-Host "Function App: $FUNCTION_APP_NAME"
Write-Host "Key Vault: $KEY_VAULT_NAME"

# 8. Aggiungi secrets al Key Vault
az keyvault secret set `
  --vault-name $KEY_VAULT_NAME `
  --name "DatabaseConnectionString" `
  --value "Server=myserver;Database=mydb;User=myuser;Password=mypassword"

# 9. Deploy del codice (dalla cartella root del progetto)
cd ..
npm install
npm run build
func azure functionapp publish $FUNCTION_APP_NAME
```

## Risorse Create

1. **Azure Key Vault**
   - Soft delete abilitato
   - Purge protection abilitato
   - RBAC authorization abilitato

2. **Azure Function App**
   - Runtime: Node.js 18
   - Plan: Consumption (Y1)
   - System-assigned Managed Identity abilitata
   - HTTPS only

3. **Storage Account**
   - SKU: Standard_LRS
   - TLS 1.2 minimo
   - Blob public access disabilitato

4. **Application Insights**
   - Retention: 90 giorni
   - Tipo: Web

5. **RBAC Assignments**
   - Key Vault Secrets User (lettura)
   - Key Vault Secrets Officer (scrittura)

## Output

Dopo il deployment, verranno forniti i seguenti output:

- `functionAppName`: Nome della Function App
- `functionAppUrl`: URL della Function App
- `keyVaultName`: Nome del Key Vault
- `keyVaultUri`: URI del Key Vault
- `appInsightsInstrumentationKey`: Chiave di Application Insights

## Post-Deployment

Dopo il deployment dell'infrastruttura:

1. Configurare l'App Registration per Azure AD
2. Aggiornare le impostazioni di autenticazione
3. Aggiungere secrets al Key Vault
4. Deploy del codice della Function App

## Cleanup

Per eliminare tutte le risorse:

```bash
az group delete --name rg-funcapp-security-dev --yes --no-wait
```
