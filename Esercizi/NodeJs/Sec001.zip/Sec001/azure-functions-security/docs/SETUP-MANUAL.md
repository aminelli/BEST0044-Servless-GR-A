# Guida alla Configurazione Manuale

Questa guida fornisce istruzioni dettagliate passo-passo per configurare manualmente tutti i servizi Azure necessari per il progetto.

## 📋 Indice

1. [Prerequisiti e Installazione Tool](#1-prerequisiti-e-installazione-tool)
2. [Azure Key Vault](#2-azure-key-vault)
3. [Managed Identity](#3-managed-identity)
4. [RBAC (Role-Based Access Control)](#4-rbac-role-based-access-control)
5. [Azure Functions](#5-azure-functions)
6. [Application Insights](#6-application-insights)
7. [Network Security](#7-network-security-opzionale)
8. [Verifica e Testing](#8-verifica-e-testing)
9. [Troubleshooting](#9-troubleshooting)

---

## 1. Prerequisiti e Installazione Tool

### 1.1 Installazione Azure Functions Core Tools

#### Windows (PowerShell come Administrator)

```powershell
# Metodo 1: Tramite npm
npm install -g azure-functions-core-tools@4 --unsafe-perm true

# Metodo 2: Tramite Windows Package Manager
winget install Microsoft.Azure.FunctionsCoreTools

# Metodo 3: Tramite Chocolatey
choco install azure-functions-core-tools
```

#### Verifica Installazione

```bash
func --version
# Output atteso: 4.x.xxxx
```

### 1.2 Installazione Azure CLI

#### Windows

1. Scarica l'installer MSI da: https://aka.ms/installazurecliwindows
2. Esegui il file scaricato
3. Segui la procedura guidata

#### Verifica Installazione

```bash
az --version
# Output: Mostra la versione di Azure CLI

# Login ad Azure
az login
# Si aprirà il browser per l'autenticazione

# Verifica sottoscrizioni disponibili
az account list --output table

# Imposta la sottoscrizione da usare
az account set --subscription "<subscription-name-or-id>"
```

### 1.3 Installazione Node.js e TypeScript

```bash
# Verifica Node.js (deve essere >= 18.0.0)
node --version

# Installa TypeScript globalmente
npm install -g typescript

# Verifica TypeScript
tsc --version
```

### 1.4 Variabili d'Ambiente per gli Script

```bash
# Imposta variabili comuni
$RESOURCE_GROUP = "rg-funcapp-security-dev"
$LOCATION = "eastus"
$FUNCTION_APP_NAME = "funcapp-security-dev-$(Get-Random -Maximum 9999)"
$KEY_VAULT_NAME = "kv-security-$(Get-Random -Maximum 9999)"
$STORAGE_ACCOUNT_NAME = "stfuncsec$(Get-Random -Maximum 9999)"
$APP_INSIGHTS_NAME = "appi-funcapp-security-dev"
$APP_SERVICE_PLAN = "asp-funcapp-security-dev"
```

---

## 2. Azure Key Vault

### 2.1 Creazione via Azure CLI

```bash
# Crea il Resource Group (se non esiste)
az group create `
  --name $RESOURCE_GROUP `
  --location $LOCATION

# Crea il Key Vault
az keyvault create `
  --name $KEY_VAULT_NAME `
  --resource-group $RESOURCE_GROUP `
  --location $LOCATION `
  --enable-rbac-authorization true `
  --enable-soft-delete true `
  --soft-delete-retention-days 90 `
  --enable-purge-protection true
```

**Spiegazione parametri**:
- `--enable-rbac-authorization`: Usa RBAC invece delle Access Policies legacy
- `--enable-soft-delete`: Abilita il recupero dei secrets eliminati
- `--soft-delete-retention-days`: Giorni prima della cancellazione definitiva
- `--enable-purge-protection`: Previene eliminazioni permanenti accidentali

### 2.2 Creazione via Azure Portal

1. Vai al **Azure Portal** (https://portal.azure.com)
2. Cerca "Key vaults" nella barra di ricerca
3. Click su **+ Create**
4. Compila il form:
   - **Subscription**: Seleziona la tua sottoscrizione
   - **Resource group**: Seleziona o crea `rg-funcapp-security-dev`
   - **Key vault name**: `kv-security-<unique-id>`
   - **Region**: East US (o la tua regione)
   - **Pricing tier**: Standard
5. Tab **Access configuration**:
   - **Permission model**: Seleziona "Azure role-based access control (RBAC)"
6. Tab **Networking**:
   - **Network access**: Allow public access from all networks (per sviluppo)
7. Click **Review + create** > **Create**

### 2.3 Aggiunta di Secrets

#### Via Azure CLI

```bash
# Aggiungi secrets di esempio
az keyvault secret set `
  --vault-name $KEY_VAULT_NAME `
  --name "DatabaseConnectionString" `
  --value "Server=myserver;Database=mydb;User=myuser;Password=mypassword"

az keyvault secret set `
  --vault-name $KEY_VAULT_NAME `
  --name "ApiKey" `
  --value "my-super-secret-api-key"

# Lista tutti i secrets
az keyvault secret list `
  --vault-name $KEY_VAULT_NAME `
  --output table
```

#### Via Azure Portal

1. Apri il Key Vault creato
2. Nel menu laterale, click su **Secrets**
3. Click **+ Generate/Import**
4. Compila:
   - **Upload options**: Manual
   - **Name**: DatabaseConnectionString
   - **Value**: Il valore del secret
5. Click **Create**

### 2.4 Configurazione Network e Firewall

```bash
# Configurazione firewall (esempio: consenti solo IP specifici)
az keyvault network-rule add `
  --name $KEY_VAULT_NAME `
  --resource-group $RESOURCE_GROUP `
  --ip-address "203.0.113.0/24"

# Abilita bypass per servizi Azure
az keyvault update `
  --name $KEY_VAULT_NAME `
  --resource-group $RESOURCE_GROUP `
  --bypass AzureServices
```

### 2.5 Verifica della Configurazione

```bash
# Mostra dettagli del Key Vault
az keyvault show `
  --name $KEY_VAULT_NAME `
  --resource-group $RESOURCE_GROUP `
  --output json

# Ottieni l'URL del Key Vault (necessario per la Function App)
$KEY_VAULT_URL = az keyvault show `
  --name $KEY_VAULT_NAME `
  --query "properties.vaultUri" `
  --output tsv

Write-Host "Key Vault URL: $KEY_VAULT_URL"
```

---

## 3. Managed Identity

### 3.1 System-Assigned vs User-Assigned

**System-Assigned Managed Identity**:
- Ciclo di vita legato alla risorsa
- Una identity per risorsa
- Più semplice da configurare
- **Consigliato per questo progetto**

**User-Assigned Managed Identity**:
- Risorsa indipendente
- Può essere condivisa tra risorse
- Maggiore flessibilità

### 3.2 Creazione System-Assigned Identity per Function App

La Managed Identity verrà creata automaticamente quando creiamo la Function App con il flag `--assign-identity`.

### 3.3 Creazione User-Assigned Identity (Opzionale)

```bash
# Crea una User-Assigned Managed Identity
az identity create `
  --name "id-funcapp-security" `
  --resource-group $RESOURCE_GROUP `
  --location $LOCATION

# Ottieni l'ID della identity
$IDENTITY_ID = az identity show `
  --name "id-funcapp-security" `
  --resource-group $RESOURCE_GROUP `
  --query "id" `
  --output tsv
```

### 3.4 Verifica dell'Identity Creata

Dopo aver creato la Function App, verifica:

```bash
# Ottieni il Principal ID della System-Assigned Identity
$PRINCIPAL_ID = az functionapp identity show `
  --name $FUNCTION_APP_NAME `
  --resource-group $RESOURCE_GROUP `
  --query "principalId" `
  --output tsv

Write-Host "Managed Identity Principal ID: $PRINCIPAL_ID"
```

---

## 4. RBAC (Role-Based Access Control)

### 4.1 Ruoli Built-in di Azure per Key Vault

| Ruolo | Permessi | Quando Usarlo |
|-------|----------|---------------|
| **Key Vault Secrets User** | Lettura secrets | Per applicazioni che leggono secrets |
| **Key Vault Secrets Officer** | Gestione completa secrets | Per applicazioni che creano/modificano secrets |
| **Key Vault Administrator** | Gestione completa | Per amministratori |

### 4.2 Assegnazione Ruoli alla Managed Identity

#### Via Azure CLI

```bash
# Ottieni l'ID del Key Vault
$KEY_VAULT_ID = az keyvault show `
  --name $KEY_VAULT_NAME `
  --resource-group $RESOURCE_GROUP `
  --query "id" `
  --output tsv

# Assegna il ruolo "Key Vault Secrets User" (lettura)
az role assignment create `
  --role "Key Vault Secrets User" `
  --assignee $PRINCIPAL_ID `
  --scope $KEY_VAULT_ID

# Assegna il ruolo "Key Vault Secrets Officer" (scrittura)
az role assignment create `
  --role "Key Vault Secrets Officer" `
  --assignee $PRINCIPAL_ID `
  --scope $KEY_VAULT_ID
```

#### Via Azure Portal

1. Apri il **Key Vault** nel portale
2. Nel menu laterale, click **Access control (IAM)**
3. Click **+ Add** > **Add role assignment**
4. Tab **Role**:
   - Cerca e seleziona "Key Vault Secrets User"
   - Click **Next**
5. Tab **Members**:
   - **Assign access to**: Managed identity
   - Click **+ Select members**
   - Filtra per tipo: Function App
   - Seleziona la tua Function App
   - Click **Select**
6. Click **Review + assign**
7. Ripeti per il ruolo "Key Vault Secrets Officer"

### 4.3 Creazione di Ruoli Custom (se necessario)

```bash
# Crea un file JSON per la definizione del ruolo custom
$roleDefinition = @"
{
  "Name": "Key Vault Secret Reader Custom",
  "Description": "Can read secrets from Key Vault",
  "Actions": [],
  "DataActions": [
    "Microsoft.KeyVault/vaults/secrets/getSecret/action",
    "Microsoft.KeyVault/vaults/secrets/readMetadata/action"
  ],
  "NotDataActions": [],
  "AssignableScopes": [
    "/subscriptions/<subscription-id>/resourceGroups/$RESOURCE_GROUP"
  ]
}
"@

# Salva in un file
$roleDefinition | Out-File -FilePath "custom-role.json"

# Crea il ruolo custom
az role definition create --role-definition custom-role.json
```

### 4.4 Verifica delle Assegnazioni

```bash
# Lista tutte le assegnazioni di ruolo per la Function App
az role assignment list `
  --assignee $PRINCIPAL_ID `
  --output table

# Verifica permessi specifici sul Key Vault
az role assignment list `
  --scope $KEY_VAULT_ID `
  --output table
```

---

## 5. Azure Functions

### 5.1 Creazione Storage Account

```bash
# Crea lo Storage Account (richiesto da Azure Functions)
az storage account create `
  --name $STORAGE_ACCOUNT_NAME `
  --resource-group $RESOURCE_GROUP `
  --location $LOCATION `
  --sku Standard_LRS `
  --kind StorageV2 `
  --https-only true `
  --min-tls-version TLS1_2 `
  --allow-blob-public-access false
```

### 5.2 Creazione App Service Plan

```bash
# Crea un Consumption Plan (serverless)
az functionapp plan create `
  --name $APP_SERVICE_PLAN `
  --resource-group $RESOURCE_GROUP `
  --location $LOCATION `
  --sku Y1 `
  --is-linux false
```

**Tipi di piano**:
- **Y1 (Consumption)**: Pay-per-execution, scaling automatico
- **EP1 (Elastic Premium)**: Istanze pre-warmed, VNET integration
- **P1v2 (App Service Plan)**: Istanze dedicate

### 5.3 Creazione Function App

#### Via Azure CLI

```bash
# Crea la Function App con System-Assigned Managed Identity
az functionapp create `
  --name $FUNCTION_APP_NAME `
  --resource-group $RESOURCE_GROUP `
  --storage-account $STORAGE_ACCOUNT_NAME `
  --plan $APP_SERVICE_PLAN `
  --runtime node `
  --runtime-version 18 `
  --functions-version 4 `
  --assign-identity "[system]" `
  --https-only true

# Ottieni il Principal ID della Managed Identity
$PRINCIPAL_ID = az functionapp identity show `
  --name $FUNCTION_APP_NAME `
  --resource-group $RESOURCE_GROUP `
  --query "principalId" `
  --output tsv

Write-Host "Function App created with Principal ID: $PRINCIPAL_ID"
```

#### Via Azure Portal

1. Cerca "Function App" nel portale
2. Click **+ Create**
3. Tab **Basics**:
   - **Resource Group**: rg-funcapp-security-dev
   - **Function App name**: funcapp-security-dev-<unique>
   - **Runtime stack**: Node.js
   - **Version**: 18 LTS
   - **Region**: East US
   - **Operating System**: Windows o Linux
   - **Plan type**: Consumption (Serverless)
4. Tab **Storage**:
   - Crea nuovo o seleziona storage account esistente
5. Tab **Networking**:
   - **Enable public access**: On (per sviluppo)
6. Click **Review + create** > **Create**

### 5.4 Abilitazione Managed Identity (se non abilitata)

```bash
# Abilita System-Assigned Identity
az functionapp identity assign `
  --name $FUNCTION_APP_NAME `
  --resource-group $RESOURCE_GROUP
```

Via Portal:
1. Apri la Function App
2. **Settings** > **Identity**
3. Tab **System assigned**: Imposta **Status** su **On**
4. Click **Save**

### 5.5 Configurazione Application Settings

```bash
# Aggiungi impostazioni dell'applicazione
az functionapp config appsettings set `
  --name $FUNCTION_APP_NAME `
  --resource-group $RESOURCE_GROUP `
  --settings `
    AZURE_KEY_VAULT_URL=$KEY_VAULT_URL `
    NODE_ENV=production `
    WEBSITE_NODE_DEFAULT_VERSION=~18

# Verifica le impostazioni
az functionapp config appsettings list `
  --name $FUNCTION_APP_NAME `
  --resource-group $RESOURCE_GROUP `
  --output table
```

### 5.6 Configurazione Key Vault References

Le Key Vault References permettono di referenziare secrets direttamente nelle app settings:

```bash
# Sintassi: @Microsoft.KeyVault(SecretUri=<secret-uri>)
$SECRET_URI = "https://$KEY_VAULT_NAME.vault.azure.net/secrets/DatabaseConnectionString"

az functionapp config appsettings set `
  --name $FUNCTION_APP_NAME `
  --resource-group $RESOURCE_GROUP `
  --settings `
    DatabaseConnection="@Microsoft.KeyVault(SecretUri=$SECRET_URI)"
```

### 5.7 Configurazione Runtime e Piano

```bash
# Imposta la versione di Node.js
az functionapp config set `
  --name $FUNCTION_APP_NAME `
  --resource-group $RESOURCE_GROUP `
  --linux-fx-version "NODE|18"

# Configura Always On (solo per piani non-consumption)
# az functionapp config set `
#   --name $FUNCTION_APP_NAME `
#   --resource-group $RESOURCE_GROUP `
#   --always-on true
```

---

## 6. Application Insights

### 6.1 Creazione e Configurazione

```bash
# Crea Application Insights
az monitor app-insights component create `
  --app $APP_INSIGHTS_NAME `
  --location $LOCATION `
  --resource-group $RESOURCE_GROUP `
  --application-type web `
  --retention-time 90

# Ottieni la Connection String
$APP_INSIGHTS_CONNECTION_STRING = az monitor app-insights component show `
  --app $APP_INSIGHTS_NAME `
  --resource-group $RESOURCE_GROUP `
  --query "connectionString" `
  --output tsv
```

### 6.2 Collegamento alle Azure Functions

```bash
# Configura Application Insights nella Function App
az functionapp config appsettings set `
  --name $FUNCTION_APP_NAME `
  --resource-group $RESOURCE_GROUP `
  --settings `
    APPLICATIONINSIGHTS_CONNECTION_STRING=$APP_INSIGHTS_CONNECTION_STRING
```

### 6.3 Configurazione Alerting Base

```bash
# Crea un alert per errori (esempio)
az monitor metrics alert create `
  --name "High Error Rate" `
  --resource-group $RESOURCE_GROUP `
  --scopes "/subscriptions/<subscription-id>/resourceGroups/$RESOURCE_GROUP/providers/Microsoft.Web/sites/$FUNCTION_APP_NAME" `
  --condition "count exceptions/count > 10" `
  --window-size 5m `
  --evaluation-frequency 1m `
  --description "Alert quando il tasso di errori supera 10 in 5 minuti"
```

---

## 7. Network Security (Opzionale)

### 7.1 VNET Integration

Richiesto per: Elastic Premium o App Service Plan (non disponibile in Consumption)

```bash
# Crea una VNET
az network vnet create `
  --name vnet-funcapp `
  --resource-group $RESOURCE_GROUP `
  --location $LOCATION `
  --address-prefix 10.0.0.0/16

# Crea una subnet per l'integrazione
az network vnet subnet create `
  --name subnet-funcapp-integration `
  --vnet-name vnet-funcapp `
  --resource-group $RESOURCE_GROUP `
  --address-prefix 10.0.1.0/24 `
  --delegations Microsoft.Web/serverFarms

# Integra la Function App con la VNET
az functionapp vnet-integration add `
  --name $FUNCTION_APP_NAME `
  --resource-group $RESOURCE_GROUP `
  --vnet vnet-funcapp `
  --subnet subnet-funcapp-integration
```

### 7.2 Private Endpoints

```bash
# Crea Private Endpoint per Key Vault
az network private-endpoint create `
  --name pe-keyvault `
  --resource-group $RESOURCE_GROUP `
  --vnet-name vnet-funcapp `
  --subnet subnet-funcapp-integration `
  --private-connection-resource-id $KEY_VAULT_ID `
  --group-id vault `
  --connection-name keyvault-connection

# Crea Private DNS Zone
az network private-dns zone create `
  --name "privatelink.vaultcore.azure.net" `
  --resource-group $RESOURCE_GROUP

# Collega la DNS zone alla VNET
az network private-dns link vnet create `
  --name dns-link `
  --resource-group $RESOURCE_GROUP `
  --zone-name "privatelink.vaultcore.azure.net" `
  --virtual-network vnet-funcapp `
  --registration-enabled false
```

### 7.3 Service Endpoints

```bash
# Abilita Service Endpoint per Key Vault sulla subnet
az network vnet subnet update `
  --name subnet-funcapp-integration `
  --vnet-name vnet-funcapp `
  --resource-group $RESOURCE_GROUP `
  --service-endpoints Microsoft.KeyVault

# Configura il Key Vault per accettare solo dalla subnet
az keyvault network-rule add `
  --name $KEY_VAULT_NAME `
  --resource-group $RESOURCE_GROUP `
  --subnet subnet-funcapp-integration `
  --vnet-name vnet-funcapp
```

---

## 8. Verifica e Testing

### 8.1 Verifica Connessione Key Vault

```bash
# Test accesso al Key Vault tramite Azure CLI
az keyvault secret show `
  --vault-name $KEY_VAULT_NAME `
  --name "ApiKey"

# Output: Mostra i dettagli del secret
```

### 8.2 Test Managed Identity

```powershell
# Script PowerShell per testare l'autenticazione
$token = (az account get-access-token --resource https://vault.azure.net --query accessToken --output tsv)
$headers = @{
  "Authorization" = "Bearer $token"
}

$secretUrl = "https://$KEY_VAULT_NAME.vault.azure.net/secrets/ApiKey?api-version=7.4"
$response = Invoke-RestMethod -Uri $secretUrl -Headers $headers -Method Get

Write-Host "Secret Value: $($response.value)"
```

### 8.3 Test delle Functions Localmente

```bash
# Naviga nella directory del progetto
cd azure-functions-security

# Installa dipendenze
npm install

# Build
npm run build

# Configura local.settings.json con il Key Vault URL

# Avvia le functions localmente
npm start
```

Test endpoints:

```bash
# Function 1: Lista secrets
curl http://localhost:7071/api/secrets

# Function 1: Recupera un secret
curl http://localhost:7071/api/secrets/ApiKey

# Function 2: GET data
curl http://localhost:7071/api/protected/data
```

### 8.4 Deploy e Test in Azure

```bash
# Deploy del codice
npm run build
func azure functionapp publish $FUNCTION_APP_NAME

# Test in Azure
$FUNCTION_URL = az functionapp show `
  --name $FUNCTION_APP_NAME `
  --resource-group $RESOURCE_GROUP `
  --query "defaultHostName" `
  --output tsv

curl "https://$FUNCTION_URL/api/secrets"
```

---

## 9. Troubleshooting

### 9.1 Problemi Comuni

#### Errore: "Unauthorized" quando si accede al Key Vault

**Causa**: La Managed Identity non ha i permessi corretti.

**Soluzione**:
```bash
# Verifica le assegnazioni di ruolo
az role assignment list --assignee $PRINCIPAL_ID --output table

# Ri-assegna i ruoli se necessario
az role assignment create `
  --role "Key Vault Secrets User" `
  --assignee $PRINCIPAL_ID `
  --scope $KEY_VAULT_ID
```

#### Errore: "Key Vault not found"

**Causa**: URL del Key Vault non configurato correttamente.

**Soluzione**:
```bash
# Verifica l'URL
az keyvault show --name $KEY_VAULT_NAME --query "properties.vaultUri"

# Aggiorna la configurazione
az functionapp config appsettings set `
  --name $FUNCTION_APP_NAME `
  --resource-group $RESOURCE_GROUP `
  --settings AZURE_KEY_VAULT_URL="<correct-url>"
```

#### Errore: "Managed Identity not enabled"

**Soluzione**:
```bash
# Abilita la Managed Identity
az functionapp identity assign `
  --name $FUNCTION_APP_NAME `
  --resource-group $RESOURCE_GROUP
```

### 9.2 Logging e Diagnostica

```bash
# Visualizza i log della Function App in streaming
az webapp log tail `
  --name $FUNCTION_APP_NAME `
  --resource-group $RESOURCE_GROUP

# Visualizza i log in Application Insights
az monitor app-insights query `
  --app $APP_INSIGHTS_NAME `
  --analytics-query "traces | where timestamp > ago(1h) | order by timestamp desc"
```

### 9.3 Verifica Configurazione

```bash
# Controlla tutte le impostazioni della Function App
az functionapp config appsettings list `
  --name $FUNCTION_APP_NAME `
  --resource-group $RESOURCE_GROUP

# Verifica lo stato della Function App
az functionapp show `
  --name $FUNCTION_APP_NAME `
  --resource-group $RESOURCE_GROUP `
  --query "{name:name, state:state, hostNames:hostNames}" `
  --output table
```

### 9.4 Reset e Riavvio

```bash
# Riavvia la Function App
az functionapp restart `
  --name $FUNCTION_APP_NAME `
  --resource-group $RESOURCE_GROUP

# Sync dei trigger (utile dopo modifiche)
az functionapp deployment source sync `
  --name $FUNCTION_APP_NAME `
  --resource-group $RESOURCE_GROUP
```

---

## 📚 Risorse Utili

- [Documentazione Azure Functions](https://docs.microsoft.com/azure/azure-functions/)
- [Azure Key Vault Best Practices](https://docs.microsoft.com/azure/key-vault/general/best-practices)
- [Managed Identities](https://docs.microsoft.com/azure/active-directory/managed-identities-azure-resources/)
- [Azure RBAC](https://docs.microsoft.com/azure/role-based-access-control/)

---

## ✅ Checklist Finale

- [ ] Azure Functions Core Tools installato
- [ ] Azure CLI installato e autenticato
- [ ] Resource Group creato
- [ ] Key Vault creato e configurato
- [ ] Secrets aggiunti al Key Vault
- [ ] Storage Account creato
- [ ] Function App creata
- [ ] System-Assigned Managed Identity abilitata
- [ ] RBAC configurato per Key Vault
- [ ] Application Insights creato e collegato
- [ ] Application Settings configurate
- [ ] Codice deployato
- [ ] Functions testate e funzionanti
- [ ] Logging verificato in Application Insights

---

**Fine della Guida alla Configurazione Manuale**
