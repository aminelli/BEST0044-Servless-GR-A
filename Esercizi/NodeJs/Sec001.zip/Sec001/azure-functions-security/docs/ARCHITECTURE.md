# Architettura del Sistema

Questo documento descrive l'architettura tecnica del progetto Azure Functions Security.

## 📋 Indice

1. [Panoramica](#panoramica)
2. [Diagramma Architetturale](#diagramma-architetturale)
3. [Componenti](#componenti)
4. [Flussi di Dati](#flussi-di-dati)
5. [Modello di Sicurezza](#modello-di-sicurezza)
6. [Design Patterns](#design-patterns)
7. [Scalabilità](#scalabilità)

---

## Panoramica

Il sistema è progettato come un'architettura serverless basata su Azure Functions, implementando pattern di sicurezza avanzati per gestione secrets e autorizzazione.

### Caratteristiche Architetturali

- **Serverless**: Scaling automatico, pay-per-execution
- **Security-First**: Managed Identity, RBAC, Key Vault integration
- **Observable**: Logging strutturato, Application Insights, audit trail
- **Resilient**: Error handling robusto, retry logic
- **Infrastructure as Code**: Deployment automatizzato con Bicep

---

## Diagramma Architetturale

```
┌─────────────────────────────────────────────────────────────────┐
│                         Internet / Client                        │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             │ HTTPS
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Azure Function App                          │
│  ┌──────────────────┐              ┌──────────────────┐         │
│  │   Function 1:    │              │   Function 2:    │         │
│  │ GetSecretFromVault│            │   ProtectedApi   │         │
│  │                  │              │                  │         │
│  │  - HTTP Trigger  │              │  - HTTP Trigger  │         │
│  │  - Key Vault Ops │              │  - RBAC Auth     │         │
│  └────────┬─────────┘              └────────┬─────────┘         │
│           │                                  │                   │
│  ┌────────┴──────────────────────────────────┴────────┐         │
│  │          System-Assigned Managed Identity           │         │
│  └────────┬──────────────────────────────────┬────────┘         │
└───────────┼──────────────────────────────────┼──────────────────┘
            │                                   │
            │ (1) Authenticate                  │ (2) Authenticate
            │     with MI                       │     with Azure AD
            ▼                                   ▼
┌──────────────────────┐            ┌──────────────────────┐
│  Azure Key Vault     │            │   Azure AD           │
│                      │            │                      │
│  - Secrets          │            │  - User Identity    │
│  - Keys             │            │  - Roles            │
│  - Certificates     │            │  - Permissions      │
│                      │            │                      │
│  RBAC:              │            └──────────────────────┘
│  - Secrets User     │
│  - Secrets Officer  │            ┌──────────────────────┐
└──────────────────────┘            │ Application Insights │
            │                       │                      │
            │ (3) Audit Trail       │  - Logging           │
            └───────────────────────┤  - Metrics           │
                                    │  - Tracing           │
                                    │  - Alerts            │
                                    └──────────────────────┘
```

---

## Componenti

### 1. Azure Functions

#### Function 1: GetSecretFromVault
**Responsabilità**: Gestione sicura dei secrets da Azure Key Vault

**Endpoints**:
- `GET /api/secrets` - Lista tutti i secrets
- `GET /api/secrets/{secretName}` - Recupera un secret specifico
- `POST /api/secrets` - Crea/aggiorna un secret
- `DELETE /api/secrets/{secretName}` - Elimina un secret

**Dipendenze**:
- KeyVaultService
- Logger
- ErrorHandler

**Caratteristiche di Sicurezza**:
- Autenticazione tramite Managed Identity
- Audit trail completo
- Nessun secret in chiaro nei log
- Validation degli input

#### Function 2: ProtectedApi
**Responsabilità**: API con autorizzazione basata su ruoli

**Endpoints**:
- `GET /api/protected/data` - Lettura (Reader, Editor, Admin)
- `POST /api/protected/data` - Creazione (Editor, Admin)
- `PUT /api/protected/data/{id}` - Modifica (Editor, Admin)
- `DELETE /api/protected/data/{id}` - Eliminazione (Admin only)

**Dipendenze**:
- AuthService
- Logger
- ErrorHandler

**Caratteristiche di Sicurezza**:
- Verifica identità utente
- Controllo autorizzazione RBAC
- Validazione token Bearer
- Rate limiting (se configurato)

### 2. Services Layer

#### KeyVaultService
**File**: `src/services/keyVaultService.ts`

**Responsabilità**:
- Interfaccia unificata per operazioni Key Vault
- Gestione autenticazione con DefaultAzureCredential
- Error handling e retry logic
- Caching (se implementato)

**Metodi**:
```typescript
getSecret(secretName: string): Promise<OperationResult<string>>
setSecret(secretName: string, value: string): Promise<OperationResult<void>>
listSecrets(): Promise<OperationResult<string[]>>
deleteSecret(secretName: string): Promise<OperationResult<void>>
testConnection(): Promise<boolean>
```

**SDK Utilizzati**:
- `@azure/keyvault-secrets` - Operazioni sui secrets
- `@azure/keyvault-keys` - Operazioni sulle chiavi
- `@azure/keyvault-certificates` - Operazioni sui certificati
- `@azure/identity` - Autenticazione

#### AuthService
**File**: `src/services/authService.ts`

**Responsabilità**:
- Verifica identità utente
- Controllo ruoli RBAC
- Validazione token Bearer
- Estrazione claims dal JWT

**Metodi**:
```typescript
verifyRoles(request: HttpRequest, roles: string[]): Promise<boolean>
getIdentity(request: HttpRequest): Promise<AuthenticatedIdentity>
verifyBearerToken(request: HttpRequest): Promise<boolean>
isAuthenticated(request: HttpRequest): Promise<boolean>
```

### 3. Utilities Layer

#### Logger
**File**: `src/utils/logger.ts`

**Responsabilità**:
- Logging strutturato JSON
- Livelli di log (DEBUG, INFO, WARN, ERROR)
- Integrazione con Application Insights
- Audit trail

**Caratteristiche**:
- Context management
- Correlation IDs
- Performance metrics
- Custom properties

#### ErrorHandler
**File**: `src/utils/errorHandler.ts`

**Responsabilità**:
- Gestione centralizzata errori
- Risposta HTTP standardizzata
- Sanitizzazione errori in produzione
- Logging errori

**Metodi**:
```typescript
handleError(error: unknown, context: InvocationContext): HttpResponseInit
validateRequest(request: HttpRequest, fields: string[]): void
successResponse<T>(data: T, statusCode?: number): HttpResponseInit
errorResponse(message: string, statusCode?: number): HttpResponseInit
```

### 4. Infrastructure Components

#### Azure Key Vault
**Configurazione**:
- RBAC authorization mode
- Soft delete enabled (90 giorni)
- Purge protection enabled
- Public network access (development)

**Secrets Gestiti**:
- Database connection strings
- API keys
- Certificates
- Encryption keys

#### Managed Identity
**Tipo**: System-Assigned

**Vantaggi**:
- Nessuna gestione credenziali
- Rotazione automatica token
- Integrazione nativa Azure
- Audit trail completo

**Ruoli Assegnati**:
- Key Vault Secrets User (lettura)
- Key Vault Secrets Officer (scrittura)

#### Application Insights
**Metriche Raccolte**:
- Request rate
- Response time
- Failure rate
- Custom metrics

**Logs**:
- Traces strutturati
- Exception tracking
- Dependency tracking
- Performance counters

---

## Flussi di Dati

### Flusso 1: Recupero Secret da Key Vault

```
1. Client → Function App
   GET /api/secrets/DatabaseConnectionString
   
2. Function App → GetSecretFromVault handler
   - Logging richiesta
   - Inizializzazione KeyVaultService
   
3. KeyVaultService → Azure Key Vault
   - Autenticazione con Managed Identity
   - Request secret "DatabaseConnectionString"
   
4. Azure Key Vault → KeyVaultService
   - Verifica RBAC (Key Vault Secrets User)
   - Return secret value
   
5. KeyVaultService → Function App
   - Return OperationResult<string>
   - Logging audit trail
   
6. Function App → Client
   - Return HTTP 200 + secret value
   - Logging operazione completata
```

### Flusso 2: API Protetta con RBAC

```
1. Client → Function App
   GET /api/protected/data
   Headers: Authorization: Bearer <token>
   
2. Function App → ProtectedApi handler
   - Logging richiesta
   - Extract identity da headers
   
3. AuthService → Azure AD
   - Validate Bearer token
   - Extract claims (objectId, roles)
   
4. AuthService → ProtectedApi
   - Return AuthenticatedIdentity
   - Roles: ["Reader", "Editor"]
   
5. ProtectedApi → Authorization check
   - Required roles: ["Reader", "Editor", "Admin"]
   - User roles: ["Reader", "Editor"]
   - Authorization: GRANTED
   
6. ProtectedApi → Business Logic
   - Execute data retrieval
   - Apply row-level security (se necessario)
   
7. Function App → Client
   - Return HTTP 200 + data
   - Logging audit trail
```

### Flusso 3: Creazione Secret con Audit

```
1. Client → Function App
   POST /api/secrets
   Body: { secretName: "ApiKey", secretValue: "xxx" }
   
2. Function App → GetSecretFromVault handler
   - Validate request body
   - Logging richiesta
   
3. KeyVaultService → Azure Key Vault
   - Autenticazione con Managed Identity
   - Set secret "ApiKey" = "xxx"
   
4. Azure Key Vault → Verify RBAC
   - Check: Key Vault Secrets Officer
   - Authorization: GRANTED
   - Create/Update secret
   
5. Azure Key Vault → Audit Log
   - Log: Secret "ApiKey" created
   - User: Managed Identity (ObjectId)
   - Timestamp: 2024-XX-XX
   
6. KeyVaultService → Function App
   - Return success
   
7. Function App → Application Insights
   - Log audit event
   - Metric: secret_created
   
8. Function App → Client
   - Return HTTP 201
```

---

## Modello di Sicurezza

### Defense in Depth

```
Layer 1: Network Security
├── HTTPS Only
├── CORS Policies
└── IP Restrictions (optional)

Layer 2: Identity & Access
├── Azure AD Authentication
├── Managed Identity
└── RBAC

Layer 3: Application Security
├── Input Validation
├── Output Sanitization
└── Error Handling

Layer 4: Data Security
├── Secrets in Key Vault
├── Encryption at Rest
└── Encryption in Transit

Layer 5: Monitoring & Audit
├── Application Insights
├── Audit Logging
└── Alerting
```

### Zero Trust Model

1. **Verify Explicitly**: Ogni richiesta è autenticata e autorizzata
2. **Least Privilege**: Permessi minimi necessari (RBAC)
3. **Assume Breach**: Logging completo, monitoring attivo

---

## Design Patterns

### 1. Singleton Pattern
**Utilizzo**: KeyVaultService, AuthService

```typescript
let keyVaultServiceInstance: KeyVaultService | null = null;

export function getKeyVaultService(): KeyVaultService {
  if (!keyVaultServiceInstance) {
    keyVaultServiceInstance = new KeyVaultService(config);
  }
  return keyVaultServiceInstance;
}
```

### 2. Factory Pattern
**Utilizzo**: Service initialization

### 3. Decorator Pattern
**Utilizzo**: Error handling decorator

```typescript
@withErrorHandler
async function myFunction(request, context) {
  // Logic
}
```

### 4. Strategy Pattern
**Utilizzo**: Authentication strategies (Managed Identity, Service Principal)

---

## Scalabilità

### Horizontal Scaling
- Azure Functions Consumption Plan: Auto-scaling basato su carico
- Max 200 istanze per Function App
- Cold start mitigation: Premium Plan o Always On

### Performance Optimization
- Connection pooling per Key Vault client
- Caching secrets (con TTL)
- Async/await per operazioni I/O
- Minimal dependencies

### Limits
| Risorsa | Limit Consumption Plan |
|---------|------------------------|
| Max execution time | 5 minuti (default) |
| Max concurrent requests | 200 per istanza |
| Max memory | 1.5 GB |
| Max request size | 100 MB |

---

## Monitoring e Observability

### Metriche Chiave
- **Availability**: Uptime della Function App
- **Latency**: P50, P95, P99 response time
- **Error Rate**: % di richieste fallite
- **Throughput**: Richieste per secondo

### Logging Levels
- **DEBUG**: Dettagli tecnici (solo development)
- **INFO**: Eventi normali, operazioni completate
- **WARN**: Situazioni anomale ma gestibili
- **ERROR**: Errori che richiedono attenzione

### Tracing
- Correlation ID per tracciare richieste end-to-end
- Distributed tracing con Application Insights
- Dependency tracking (Key Vault, Azure AD)

---

## Disaster Recovery

### Backup
- Key Vault: Soft delete + Purge protection
- Function App: Source control deployment
- Configuration: Infrastructure as Code (Bicep)

### Recovery Time Objective (RTO)
- Infrastructure: < 1 ora (redeploy da IaC)
- Secrets: Immediato (soft delete recovery)
- Code: < 15 minuti (redeploy da CI/CD)

### Recovery Point Objective (RPO)
- Configuration: 0 (versionato in Git)
- Secrets: < 90 giorni (soft delete retention)

---

## Considerazioni per Produzione

### ✅ Checklist Pre-Produzione

- [ ] VNET Integration configurato
- [ ] Private Endpoints per Key Vault
- [ ] Azure AD App Registration configurato
- [ ] RBAC policies validate
- [ ] Application Insights alerts configurati
- [ ] Disaster recovery plan testato
- [ ] Load testing completato
- [ ] Security review completato
- [ ] Documentazione aggiornata
- [ ] Runbook operativi creati

---

**Fine Documento Architettura**
