# Scenari di Sicurezza

Questo documento descrive in dettaglio gli scenari di sicurezza implementati nel progetto, le minacce mitigate e le best practices applicate.

## 📋 Indice

1. [Panoramica](#panoramica)
2. [Scenario 1: Gestione Sicura Secrets](#scenario-1-gestione-sicura-secrets)
3. [Scenario 2: Autorizzazione Basata su Ruoli](#scenario-2-autorizzazione-basata-su-ruoli)
4. [Threat Model](#threat-model)
5. [Security Controls](#security-controls)
6. [Compliance](#compliance)
7. [Best Practices](#best-practices)

---

## Panoramica

Il progetto implementa due scenari di sicurezza complementari che coprono le principali sfide nella gestione di applicazioni serverless:

1. **Gestione Sicura Secrets**: Accesso a risorse protette senza credenziali hardcoded
2. **Autorizzazione Basata su Ruoli**: Controllo granulare degli accessi alle risorse

---

## Scenario 1: Gestione Sicura Secrets

### Obiettivo
Gestire secrets, chiavi e certificati in modo sicuro senza mai esporli nel codice sorgente o nei log.

### Componenti

```
┌─────────────────────────────────────────────────────────┐
│            Function: GetSecretFromVault                 │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ┌──────────────────────────────────────────────┐     │
│  │  1. Client Request                           │     │
│  │     GET /api/secrets/DatabaseConnection      │     │
│  └──────────────┬───────────────────────────────┘     │
│                 │                                       │
│                 ▼                                       │
│  ┌──────────────────────────────────────────────┐     │
│  │  2. Managed Identity Authentication          │     │
│  │     - No credentials in code                 │     │
│  │     - Automatic token rotation               │     │
│  │     - DefaultAzureCredential chain           │     │
│  └──────────────┬───────────────────────────────┘     │
│                 │                                       │
│                 ▼                                       │
│  ┌──────────────────────────────────────────────┐     │
│  │  3. Azure Key Vault Access                   │     │
│  │     - RBAC verification                      │     │
│  │     - Audit log entry                        │     │
│  │     - Secret retrieval                       │     │
│  └──────────────┬───────────────────────────────┘     │
│                 │                                       │
│                 ▼                                       │
│  ┌──────────────────────────────────────────────┐     │
│  │  4. Response to Client                       │     │
│  │     - Secret value (over HTTPS)              │     │
│  │     - No logging of secret value             │     │
│  │     - Audit trail of access                  │     │
│  └──────────────────────────────────────────────┘     │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### Minacce Mitigate

| Minaccia | Mitigazione | Implementazione |
|----------|-------------|-----------------|
| **Secrets Hardcoded** | Nessun secret nel codice | Key Vault + Config |
| **Credential Theft** | Managed Identity | System-Assigned MI |
| **Unauthorized Access** | RBAC su Key Vault | Secrets User/Officer roles |
| **Audit Gap** | Logging completo | Application Insights + Azure Monitor |
| **Secret Exposure in Logs** | Log sanitization | Custom logger con filtering |
| **Man-in-the-Middle** | HTTPS only | TLS 1.2+ enforcement |

### Implementazione Dettagliata

#### 1. Nessun Secret Hardcoded

❌ **Anti-Pattern (NON FARE)**:
```typescript
// SBAGLIATO: Secret hardcoded
const connectionString = "Server=myserver;Password=mypassword123";
const apiKey = "sk_live_abc123xyz";
```

✅ **Pattern Corretto**:
```typescript
// CORRETTO: Secret da Key Vault
const keyVaultService = getKeyVaultService();
const result = await keyVaultService.getSecret('DatabaseConnectionString');
const connectionString = result.data;
```

#### 2. Managed Identity Authentication

```typescript
// Credential chain automatica
const credential = new DefaultAzureCredential();

// Ordine di autenticazione:
// 1. Environment variables (development locale)
// 2. Managed Identity (in Azure)
// 3. Visual Studio Code (development)
// 4. Azure CLI (development)
// 5. Azure PowerShell (development)

const secretClient = new SecretClient(keyVaultUrl, credential);
```

**Vantaggi**:
- 🔒 Zero credenziali nel codice
- 🔄 Token rotation automatica ogni 24h
- 🎯 Supporto multi-ambiente
- 📊 Audit trail nativo

#### 3. RBAC Granulare

**Ruoli Assegnati**:

| Ruolo | Operazioni Permesse | Caso d'Uso |
|-------|---------------------|------------|
| **Key Vault Secrets User** | `getSecret`, `listSecrets` | Function che legge secrets |
| **Key Vault Secrets Officer** | Tutte le operazioni | Function che gestisce secrets |
| **Key Vault Administrator** | Gestione completa + RBAC | Solo admin umani |

**Implementazione Bicep**:
```bicep
resource roleAssignment 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(keyVault.id, principalId, roleId)
  scope: keyVault
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', roleId)
    principalId: principalId
    principalType: 'ServicePrincipal'
  }
}
```

#### 4. Audit Trail Completo

**Log Events**:
```typescript
// Prima dell'operazione
logger.audit('Secret access attempt', {
  secretName: 'DatabaseConnection',
  userId: identity.objectId,
  timestamp: new Date()
});

// Dopo l'operazione
logger.audit('Secret accessed successfully', {
  secretName: 'DatabaseConnection',
  userId: identity.objectId,
  duration: 150,
  success: true
});
```

**Monitoraggio**:
- Application Insights: Tracking operazioni
- Azure Monitor: Alerts su accessi anomali
- Key Vault Logs: Audit nativo Azure

### Security Controls

| Control | Tipo | Implementazione |
|---------|------|-----------------|
| **SC-1** | Preventive | RBAC su Key Vault |
| **SC-2** | Detective | Logging tutte le operazioni |
| **SC-3** | Corrective | Soft delete + Purge protection |
| **SC-4** | Preventive | HTTPS only |
| **SC-5** | Detective | Application Insights monitoring |

---

## Scenario 2: Autorizzazione Basata su Ruoli

### Obiettivo
Implementare controllo accessi granulare basato sui ruoli dell'utente (Reader, Editor, Admin).

### Componenti

```
┌─────────────────────────────────────────────────────────┐
│              Function: ProtectedApi                     │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ┌──────────────────────────────────────────────┐     │
│  │  1. Client Request                           │     │
│  │     POST /api/protected/data                 │     │
│  │     Headers:                                 │     │
│  │       Authorization: Bearer <JWT>            │     │
│  └──────────────┬───────────────────────────────┘     │
│                 │                                       │
│                 ▼                                       │
│  ┌──────────────────────────────────────────────┐     │
│  │  2. Authentication                           │     │
│  │     - Extract JWT from header                │     │
│  │     - Verify x-ms-client-principal           │     │
│  │     - Extract user identity                  │     │
│  └──────────────┬───────────────────────────────┘     │
│                 │                                       │
│                 ▼                                       │
│  ┌──────────────────────────────────────────────┐     │
│  │  3. Authorization                            │     │
│  │     - Extract user roles                     │     │
│  │     - Check required roles for operation     │     │
│  │     - Allow/Deny decision                    │     │
│  └──────────────┬───────────────────────────────┘     │
│                 │                                       │
│                 ▼                                       │
│  ┌──────────────────────────────────────────────┐     │
│  │  4. Business Logic                           │     │
│  │     - Execute operation if authorized        │     │
│  │     - Apply row-level security               │     │
│  │     - Return filtered data                   │     │
│  └──────────────┬───────────────────────────────┘     │
│                 │                                       │
│                 ▼                                       │
│  ┌──────────────────────────────────────────────┐     │
│  │  5. Audit & Response                         │     │
│  │     - Log access attempt                     │     │
│  │     - Return result or error                 │     │
│  └──────────────────────────────────────────────┘     │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### Matrice RBAC

| Operazione | Endpoint | Reader | Editor | Admin |
|-----------|----------|--------|--------|-------|
| **List Data** | GET /api/protected/data | ✅ | ✅ | ✅ |
| **View Data** | GET /api/protected/data/{id} | ✅ | ✅ | ✅ |
| **Create Data** | POST /api/protected/data | ❌ | ✅ | ✅ |
| **Update Data** | PUT /api/protected/data/{id} | ❌ | ✅ | ✅ |
| **Delete Data** | DELETE /api/protected/data/{id} | ❌ | ❌ | ✅ |

### Minacce Mitigate

| Minaccia | Mitigazione | Implementazione |
|----------|-------------|-----------------|
| **Privilege Escalation** | RBAC enforcement | Role verification per ogni request |
| **Horizontal Privilege Escalation** | Row-level security | Owner validation |
| **Replay Attacks** | Token expiration | JWT validation |
| **Session Hijacking** | HTTPS + secure cookies | TLS enforcement |
| **Insufficient Authorization** | Explicit role checks | Required roles per endpoint |

### Implementazione Dettagliata

#### 1. Estrazione Identità

```typescript
async function getIdentity(request: HttpRequest): Promise<AuthenticatedIdentity | null> {
  // Azure App Service Authentication (Easy Auth)
  const clientPrincipalHeader = request.headers.get('x-ms-client-principal');
  
  if (!clientPrincipalHeader) {
    return null;
  }
  
  // Decode Base64 JWT
  const clientPrincipal = JSON.parse(
    Buffer.from(clientPrincipalHeader, 'base64').toString('utf-8')
  );
  
  return {
    objectId: clientPrincipal.userId,
    tenantId: clientPrincipal.tenantId,
    principalType: clientPrincipal.identityProvider,
    roles: extractRoles(clientPrincipal.claims)
  };
}
```

#### 2. Verifica Autorizzazione

```typescript
async function verifyRoles(
  request: HttpRequest, 
  requiredRoles: string[]
): Promise<boolean> {
  const identity = await getIdentity(request);
  
  if (!identity || !identity.roles) {
    return false;
  }
  
  // Utente deve avere ALMENO UNO dei ruoli richiesti
  const hasRequiredRole = requiredRoles.some(
    role => identity.roles?.includes(role)
  );
  
  // Audit log
  logger.audit('Authorization check', {
    userId: identity.objectId,
    userRoles: identity.roles,
    requiredRoles,
    result: hasRequiredRole ? 'GRANTED' : 'DENIED'
  });
  
  return hasRequiredRole;
}
```

#### 3. Mapping Ruoli → Operazioni

```typescript
function getRequiredRolesForMethod(method: string): string[] {
  switch (method) {
    case 'GET':
      return ['Reader', 'Editor', 'Admin'];
    case 'POST':
    case 'PUT':
      return ['Editor', 'Admin'];
    case 'DELETE':
      return ['Admin'];
    default:
      return [];
  }
}
```

#### 4. Row-Level Security (Esempio)

```typescript
async function handleGetData(
  request: HttpRequest,
  identity: AuthenticatedIdentity
): Promise<HttpResponseInit> {
  const allData = await dataService.getAll();
  
  // Filtra per owner (se non Admin)
  let filteredData = allData;
  
  if (!identity.roles?.includes('Admin')) {
    filteredData = allData.filter(
      item => item.owner === identity.objectId
    );
  }
  
  return ErrorHandler.successResponse({
    data: filteredData,
    count: filteredData.length
  });
}
```

### Security Controls

| Control | Tipo | Implementazione |
|---------|------|-----------------|
| **AC-1** | Preventive | RBAC role checks |
| **AC-2** | Preventive | Row-level filtering |
| **AC-3** | Detective | Authorization logging |
| **AU-1** | Detective | Audit all access attempts |
| **AU-2** | Detective | Failed login monitoring |

---

## Threat Model

### STRIDE Analysis

#### Spoofing Identity
**Minaccia**: Attaccante si spaccia per utente legittimo

**Mitigazioni**:
- ✅ Azure AD authentication
- ✅ JWT token validation
- ✅ Managed Identity per service-to-service

#### Tampering with Data
**Minaccia**: Modifica non autorizzata di dati

**Mitigazioni**:
- ✅ RBAC per operazioni di scrittura
- ✅ Input validation
- ✅ Audit trail

#### Repudiation
**Minaccia**: Utente nega di aver compiuto un'azione

**Mitigazioni**:
- ✅ Logging completo con timestamp
- ✅ User ID in ogni log
- ✅ Application Insights retention

#### Information Disclosure
**Minaccia**: Esposizione di informazioni sensibili

**Mitigazioni**:
- ✅ Secrets in Key Vault
- ✅ HTTPS only
- ✅ Log sanitization
- ✅ Error message filtering (production)

#### Denial of Service
**Minaccia**: Sovraccarico del sistema

**Mitigazioni**:
- ✅ Azure Functions throttling
- ✅ Rate limiting (se configurato)
- ✅ Circuit breaker pattern

#### Elevation of Privilege
**Minaccia**: Ottenere privilegi non autorizzati

**Mitigazioni**:
- ✅ Least privilege RBAC
- ✅ Explicit role checks
- ✅ No default admin access

---

## Security Controls

### Preventive Controls

| ID | Control | Status |
|----|---------|--------|
| PC-1 | HTTPS Only | ✅ Implemented |
| PC-2 | RBAC on Key Vault | ✅ Implemented |
| PC-3 | Input Validation | ✅ Implemented |
| PC-4 | Managed Identity | ✅ Implemented |
| PC-5 | Least Privilege | ✅ Implemented |

### Detective Controls

| ID | Control | Status |
|----|---------|--------|
| DC-1 | Application Insights | ✅ Implemented |
| DC-2 | Audit Logging | ✅ Implemented |
| DC-3 | Failed Auth Monitoring | ✅ Implemented |
| DC-4 | Key Vault Logging | ✅ Implemented |

### Corrective Controls

| ID | Control | Status |
|----|---------|--------|
| CC-1 | Soft Delete (Key Vault) | ✅ Implemented |
| CC-2 | Purge Protection | ✅ Implemented |
| CC-3 | Error Recovery | ✅ Implemented |
| CC-4 | Incident Response | 📝 Documented |

---

## Compliance

### OWASP Top 10 (2021)

| Risk | Mitigazione | Status |
|------|-------------|--------|
| **A01 Broken Access Control** | RBAC implementation | ✅ |
| **A02 Cryptographic Failures** | Key Vault, HTTPS only | ✅ |
| **A03 Injection** | Input validation, parameterized queries | ✅ |
| **A04 Insecure Design** | Threat modeling, secure architecture | ✅ |
| **A05 Security Misconfiguration** | IaC, automated deployment | ✅ |
| **A07 Authentication Failures** | Azure AD, Managed Identity | ✅ |
| **A09 Logging Failures** | Comprehensive logging | ✅ |

### CIS Azure Foundations Benchmark

| Control | Requirement | Implementation |
|---------|-------------|----------------|
| 8.1 | Key vault logging | ✅ Enabled |
| 8.3 | Key expiration | ⚠️ Manual process |
| 9.1 | App Service HTTPS | ✅ Enforced |
| 9.2 | Managed Identity | ✅ System-assigned |
| 9.10 | FTP disabled | ✅ Disabled |

---

## Best Practices

### 1. Secrets Management

✅ **DO**:
- Store ALL secrets in Key Vault
- Use Managed Identity for authentication
- Enable soft delete and purge protection
- Rotate secrets regularly
- Use Key Vault references in app settings

❌ **DON'T**:
- Hardcode secrets in source code
- Commit secrets to Git
- Log secret values
- Share secrets via email/chat
- Use weak passwords

### 2. Access Control

✅ **DO**:
- Implement least privilege principle
- Use RBAC over legacy Access Policies
- Verify permissions on every request
- Log all authorization decisions
- Implement row-level security

❌ **DON'T**:
- Grant Admin role by default
- Skip authorization checks
- Trust client-side validation only
- Allow anonymous access in production
- Reuse credentials across environments

### 3. Logging & Monitoring

✅ **DO**:
- Log all security events
- Use structured JSON logging
- Include correlation IDs
- Set up alerts for anomalies
- Retain logs per compliance requirements

❌ **DON'T**:
- Log sensitive data (passwords, tokens)
- Ignore failed authentication attempts
- Disable logging in production
- Skip log review
- Store logs indefinitely without archiving

### 4. Error Handling

✅ **DO**:
- Return generic errors in production
- Log detailed errors server-side
- Validate all inputs
- Handle errors gracefully
- Implement retry logic with backoff

❌ **DON'T**:
- Expose stack traces to clients
- Return verbose error messages
- Ignore errors silently
- Retry indefinitely
- Skip input validation

---

## Security Checklist

### Development

- [ ] No secrets in code
- [ ] Input validation implemented
- [ ] Error handling comprehensive
- [ ] Logging non include dati sensibili
- [ ] HTTPS enforced
- [ ] Dependencies updated

### Pre-Production

- [ ] RBAC configurato correttamente
- [ ] Managed Identity abilitata
- [ ] Key Vault policies verificate
- [ ] Application Insights configurato
- [ ] Alerts configurati
- [ ] Security review completato

### Production

- [ ] Network security configurato (VNET, Private Endpoints)
- [ ] Backup e disaster recovery testati
- [ ] Monitoring attivo
- [ ] Incident response plan definito
- [ ] Compliance requirements soddisfatti
- [ ] Penetration testing completato

---

**Fine Documento Security Scenarios**
