# Expertise Richieste

Sei un esperto in:

## Cloud Technologies
- **Microsoft Azure** (Azure Functions, Azure Key Vault, Azure Active Directory, Managed Identities)
- **Azure Security** (RBAC, IAM, Policies, Security Best Practices)

## Architetture
- Architetture SOA (Service-Oriented Architecture)
- Architetture a Microservizi
- Serverless Architecture
- FaaS (Function as a Service)

## Tecnologie di Sviluppo
- TypeScript (versione 5.x o superiore)
- Node.js (versione 18.x LTS o superiore)
- Node.js per Serverless (Azure Functions Runtime v4)
- **CLI Ufficiali Microsoft** (da utilizzare per generare il progetto):
  - `Azure Functions Core Tools` (func CLI) - Scaffolding e sviluppo locale
  - `Azure CLI` (az) - Gestione risorse Azure
  - `Azure Developer CLI` (azd) - Deploy e gestione end-to-end (opzionale)
- **Azure SDK for JavaScript/TypeScript** (librerie ufficiali Microsoft):
  - `@azure/identity` - Autenticazione e Managed Identity
  - `@azure/keyvault-secrets` - Gestione secrets di Key Vault
  - `@azure/keyvault-keys` - Gestione chiavi di Key Vault
  - `@azure/keyvault-certificates` - Gestione certificati di Key Vault
  - `@azure/monitor-opentelemetry` - Telemetria e monitoring
  - `@azure/functions` - Core SDK per Azure Functions
  - `@azure/core-rest-pipeline` - HTTP client per API Azure
  - `@azure/logger` - Logging strutturato

---

# Obiettivo

Genera un progetto completo con **almeno due Azure Functions** (FaaS) che dimostrino diversi scenari di sicurezza.

## Requisiti Funzionali

1. **Function 1**: Scenario con accesso a risorse protette
   - Deve accedere ad Azure Key Vault per recuperare secrets/chiavi
   - Implementa autenticazione tramite Managed Identity
   - Prevede logging e audit trail delle operazioni

2. **Function 2**: Scenario con esposizione API sicura
   - Espone un endpoint HTTP protetto
   - Implementa autorizzazione basata su ruoli (RBAC)
   - Validazione input e gestione errori

## Requisiti di Sicurezza

Modella la sicurezza utilizzando:

### Identity & Access Management
- **Managed Identity** (System-assigned o User-assigned)
- **Azure AD Application Identity** per autenticazione service-to-service
- **RBAC (Role-Based Access Control)** con ruoli custom e built-in
- **Access Policies** per Key Vault

### Gestione Secrets e Configurazioni
- **Azure Key Vault** per secrets, chiavi e certificati
- **Key Vault References** nelle configurazioni delle Functions
- Nessun secret hardcoded nel codice

### Policies e Compliance
- **Azure Policy** per governance
- **Network Security**: VNET integration, Private Endpoints (se applicabile)
- **CORS policies** per scenari HTTP

### Best Practices
- Principle of Least Privilege
- Separation of Concerns nella gestione dei ruoli
- Logging e monitoring (Application Insights)
- Gestione errori e resilienza

---

# Output Atteso

## Struttura del Progetto

Genera un progetto Node.js con TypeScript contenente:

```
project-root/
├── src/
│   ├── functions/
│   │   ├── function1/
│   │   │   ├── index.ts
│   │   │   └── function.json
│   │   └── function2/
│   │       ├── index.ts
│   │       └── function.json
│   ├── services/
│   │   ├── keyVaultService.ts
│   │   └── authService.ts
│   ├── utils/
│   │   ├── logger.ts
│   │   └── errorHandler.ts
│   └── types/
│       └── index.ts
├── infrastructure/
│   ├── bicep/ (o terraform)
│   │   ├── main.bicep
│   │   ├── keyVault.bicep
│   │   ├── functions.bicep
│   │   └── rbac.bicep
│   └── README.md
├── docs/
│   ├── SETUP-MANUAL.md
│   ├── ARCHITECTURE.md
│   └── SECURITY-SCENARIOS.md
├── .funcignore
├── host.json
├── local.settings.json.example
├── package.json
├── tsconfig.json
├── .gitignore
└── README.md
```

## Componenti Richiesti

1. **Scaffolding del Progetto**
   - **Utilizza Azure Functions Core Tools** per inizializzare il progetto:
     ```bash
     func init <project-name> --typescript
     func new --name <function-name> --template "HTTP trigger" --language typescript
     ```
   - Struttura generata secondo le best practices Microsoft
   - Configurazioni di base create automaticamente dalla CLI
   - Documentare i comandi utilizzati nel README.md

2. **Codice TypeScript**
   - Strongly typed
   - Async/await pattern
   - Error handling con try-catch
   - Dependency injection dove appropriato
   - **Utilizzo esclusivo di SDK ufficiali Microsoft**:
     - `@azure/identity` per autenticazione (DefaultAzureCredential, ManagedIdentityCredential)
     - `@azure/keyvault-secrets` per operazioni su Key Vault
     - `@azure/functions` per definizione delle Azure Functions
     - `@azure/monitor-opentelemetry` o Application Insights SDK per telemetria
   - Nessuna libreria di terze parti per funzionalità coperte dagli SDK ufficiali
   - Gestione corretta delle credenziali con DefaultAzureCredential chain

3. **Infrastructure as Code (IaC)**
   - Bicep o Terraform per provisioning
   - Definizione Key Vault, Managed Identities, RBAC
   - Configurazioni di sicurezza dichiarative
   - Script di deployment con Azure CLI (az deploy)
   - Comandi documentati secondo la documentazione ufficiale Microsoft

4. **Configurazioni**
   - `host.json` con configurazioni ottimizzate (generato da func CLI)
   - `local.settings.json.example` (template senza secrets)
   - Environment variables ben documentate
   - `package.json` con dipendenze dagli SDK ufficiali Microsoft
   - Versioni specifiche e compatibili degli SDK Azure
   - `.funcignore` configurato correttamente

5. **Documentazione**
   - README.md con:
     - Descrizione degli scenari di sicurezza
     - **Comandi CLI utilizzati per generare il progetto** (func init, func new)
     - Istruzioni di deployment con Azure CLI
     - Configurazione prerequisiti (Azure resources)
     - Esempi di utilizzo
     - Diagramma dell'architettura (opzionale)

6. **Guida alla Configurazione Manuale (Markdown)**
   - Documento dettagliato `SETUP-MANUAL.md` con configurazione passo-passo di:
     - **Prerequisiti e Installazione Tool**
       - Installazione Azure Functions Core Tools
       - Installazione Azure CLI
       - Verifica versioni installate
     - **Azure Key Vault**
       - Creazione via Azure Portal/Azure CLI
       - Configurazione Access Policies
       - Aggiunta di secrets, chiavi e certificati
       - Configurazione network e firewall
     - **Managed Identity**
       - Creazione System-assigned vs User-assigned
       - Configurazione per Azure Functions
       - Verifica dell'identity creata
     - **RBAC (Role-Based Access Control)**
       - Assegnazione ruoli a Managed Identity
       - Creazione ruoli custom (se necessario)
       - Scope dei ruoli (subscription, resource group, resource)
       - Verifica delle assegnazioni
     - **Azure Functions**
       - Creazione Function App via Portal
       - Configurazione del runtime e piano
       - Impostazione Application Settings
       - Configurazione Key Vault References
       - Abilitazione Managed Identity
     - **Application Insights**
       - Creazione e configurazione
       - Collegamento alle Azure Functions
       - Configurazione alerting base
     - **Network Security (se applicabile)**
       - VNET Integration
       - Private Endpoints
       - Service Endpoints
     - Ogni sezione deve includere:
       - Prerequisiti specifici
       - Comandi Azure CLI con spiegazioni
       - Screenshot/step via Azure Portal (descritti testualmente)
       - Validazione della configurazione
       - Troubleshooting comuni

## Criteri di Accettazione

- ✅ **Progetto generato con Azure Functions Core Tools** (func CLI)
- ✅ Almeno 2 Azure Functions funzionanti
- ✅ Integrazione completa con Azure Key Vault
- ✅ Managed Identity configurata e utilizzata
- ✅ RBAC implementato con ruoli appropriati
- ✅ Nessun secret nel codice sorgente
- ✅ **Utilizzo esclusivo di SDK ufficiali Microsoft** (@azure/*)
- ✅ **Utilizzo esclusivo di CLI ufficiali Microsoft** (func, az)
- ✅ Autenticazione con @azure/identity (DefaultAzureCredential)
- ✅ Codice TypeScript compilabile senza errori
- ✅ Comandi CLI documentati secondo la documentazione ufficiale Microsoft
- ✅ IaC per deployment automatizzato
- ✅ Documentazione completa e chiara
- ✅ **Guida configurazione manuale (SETUP-MANUAL.md)** con tutti i passaggi descritti
- ✅ Comandi Azure CLI documentati e testabili
- ✅ Logging strutturato (Application Insights compatible)
- ✅ Gestione errori robusta