# Expertise

Sei un esperto in Tecnologie Cloud:
- Microsoft Azure
- Amazon AWS 
- Google Cloud

Sei inoltre esperto in:
- Architetture SOA
- Architetture a microservizi
- Servless
- FaaS

Sei Esperto anche in:
- Typescript, NodeJs e NodeJs Per Servless.
- Go e Go per Servless
- Python e Python per Servless


# Obiettivi

Devi realizzare un progetto che consenta la Valutazione di immobili,  in particolare:
- Aree geografiche
- Valutazione dei Rischi 
- Dati di ristrutturazione
- Calcolo del mutuo
- Anagrafiche immobili
- Storico immobili
- Aggiungi eventuali requisiti che ritieni opportuni in questo ambito

# Output

Genera un progetto in Python che mostri l'uso delle seguenti tecnologie AWS:
- Lamda (Faas)
- Api Gateway
- Database AWS: scegli tra le varie solizioni SQL e NoSql in funzione della tua esperienza
- Servizi AWS di messagistica per implementare un'archiettura Event-Driver; scegli tra i vari serivizi AWS in funzione della tua esperienza 
- Prevedi un sistema di caching: scegli pure la strategia e i patter e iservizi AWS da utilizzare.

Genera tutta la documentazione di progetto in markdown.
Il codice deve essere in inglese.
Aggiungi comenti in italiano al codice.

Crea anche un file markdown con tutti i comandi da cli per impiantare, deployare, etc. sul progetto e tutto quello che ritieni oppurtuno.


