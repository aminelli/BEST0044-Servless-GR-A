Pagamenti digitali
Spostamento file
ETL conciliazione
Invio mail al verificarsi di eventi
