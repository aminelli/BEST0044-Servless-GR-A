# Property Valuation Platform - Piattaforma Serverless di Valutazione Immobiliare

Una piattaforma serverless completa basata su AWS per la valutazione automatica di immobili, analisi dei rischi, calcolo mutui e gestione anagrafica.

## 🏗️ Architettura

- **100% Serverless**: AWS Lambda, API Gateway, DynamoDB, RDS Aurora
- **Event-Driven**: EventBridge, SQS, SNS per processamento asincrono
- **Multi-layer Caching**: ElastiCache Redis, API Gateway caching
- **Observability**: CloudWatch, X-Ray tracing, metriche custom
- **Security**: JWT authentication, RBAC, encryption at rest/transit

## 🚀 Quick Start

### Prerequisiti

```bash
# AWS CLI
aws --version  # >= 2.15.0

# AWS SAM CLI
sam --version  # >= 1.110.0

# Python
python --version  # >= 3.12

# Node.js (per alcuni tools)
node --version  # >= 20.x
```

### Installazione

```bash
# 1. Clona il repository
git clone <repository-url>
cd property-valuation-platform

# 2. Crea virtual environment
python -m venv venv
source venv/bin/activate  # su Windows: venv\Scripts\activate

# 3. Installa dipendenze
pip install -r requirements.txt
pip install -r requirements-dev.txt

# 4. Configura credenziali AWS
aws configure

# 5. Deploy infrastruttura (environment: dev/staging/prod)
./scripts/deploy.sh dev

# 6. Seed dati di test
./scripts/seed-data.sh dev
```

### Test API

```bash
# Ottieni l'API endpoint dal deploy output
export API_ENDPOINT="https://xxxxx.execute-api.region.amazonaws.com/dev"

# Crea un immobile
curl -X POST "$API_ENDPOINT/properties" \
  -H "Content-Type: application/json" \
  -d '{
    "address": "Via Roma 123, Milano, MI, 20100",
    "surface_sqm": 85.5,
    "construction_year": 2010,
    "property_type": "apartment",
    "rooms": 3,
    "bathrooms": 2
  }'
```

## 📚 Documentazione

- [Architecture](docs/ARCHITECTURE.md) - Diagrammi architetturali e decisioni di design
- [API Documentation](docs/API_DOCUMENTATION.md) - Specifica OpenAPI 3.0 completa
- [Database Design](docs/DATABASE_DESIGN.md) - Schema DynamoDB e RDS
- [Deployment Guide](docs/DEPLOYMENT.md) - Guida deployment completa
- [Operations](docs/OPERATIONS.md) - Monitoring, troubleshooting, disaster recovery
- [Development](docs/DEVELOPMENT.md) - Setup locale e contribution guidelines
- [CLI Commands](docs/CLI_COMMANDS.md) - Tutti i comandi AWS necessari

## 🏛️ Struttura Progetto

```
property-valuation-platform/
├── src/
│   ├── functions/              # Lambda functions (15+)
│   │   ├── api/               # API handlers
│   │   ├── events/            # Event handlers
│   │   └── jobs/              # Background jobs
│   ├── models/                # Domain models (Pydantic)
│   ├── repositories/          # Data access layer
│   ├── services/              # Business logic
│   ├── utils/                 # Utilities condivise
│   └── shared/                # Lambda layers
├── tests/
│   ├── unit/                  # Unit tests
│   ├── integration/           # Integration tests
│   └── fixtures/              # Test data
├── infrastructure/            # AWS SAM templates
├── docs/                      # Documentazione
├── scripts/                   # Automation scripts
└── requirements.txt           # Python dependencies
```

## 🔧 Features Principali

### ✅ Gestione Immobili
- CRUD completo con validazione
- Ricerca avanzata con filtri
- Gestione documenti (S3)
- Storico modifiche

### ✅ Valutazione Automatica
- Algoritmo di stima valore
- Comparazione immobili simili
- Report PDF automatici
- ML-ready architecture

### ✅ Analisi Rischi
- Rischio sismico, idrogeologico, ambientale
- Score complessivo
- Aggiornamenti automatici

### ✅ Calcolo Mutuo
- Simulazione rate (fisso, variabile, misto)
- TAEG/TAN
- Piano ammortamento
- Sostenibilità

### ✅ Analisi Geografica
- Geocoding
- Statistiche zona
- Prossimità servizi
- Trend mercato locale

### ✅ Ristrutturazioni
- Tracking interventi
- Preventivi e ROI
- Impatto su valutazione

## 📊 API Endpoints (20+)

| Metodo | Endpoint | Descrizione |
|--------|----------|-------------|
| POST | /properties | Crea immobile |
| GET | /properties/{id} | Dettagli immobile |
| PUT | /properties/{id} | Aggiorna immobile |
| DELETE | /properties/{id} | Elimina immobile |
| GET | /properties | Lista con filtri |
| POST | /properties/{id}/valuations | Richiedi valutazione |
| GET | /valuations/{id} | Dettagli valutazione |
| GET | /valuations/{id}/report | Download PDF |
| GET | /properties/{id}/risk-assessment | Valutazione rischi |
| POST | /mortgages/calculate | Simula mutuo |
| GET | /areas/{id}/statistics | Statistiche zona |
| GET | /analytics/market-trends | Trend mercato |

[Vedi documentazione completa API](docs/API_DOCUMENTATION.md)

## 🧪 Testing

```bash
# Run all tests
./scripts/test.sh

# Unit tests only
pytest tests/unit/ -v

# Integration tests
pytest tests/integration/ -v

# Coverage report
pytest --cov=src --cov-report=html
open htmlcov/index.html
```

**Coverage target**: > 80%

## 🔐 Sicurezza

- ✅ JWT Authentication
- ✅ RBAC (3 ruoli: admin, valutatore, viewer)
- ✅ Encryption at rest (DynamoDB, RDS, S3)
- ✅ Encryption in transit (TLS 1.2+)
- ✅ Secrets Manager per credenziali
- ✅ API rate limiting
- ✅ Input validation
- ✅ GDPR compliance

## 📈 Performance Targets

| Metrica | Target | Monitoring |
|---------|--------|------------|
| API Response Time (p95) | < 200ms | CloudWatch |
| Lambda Cold Start (p95) | < 3s | X-Ray |
| Cache Hit Ratio | > 70% | CloudWatch Metrics |
| Test Coverage | > 80% | pytest-cov |

## 💰 Cost Optimization

- DynamoDB on-demand per carichi variabili
- Lambda memory ottimizzata (1024-3008 MB)
- API Gateway caching abilitato
- S3 Intelligent-Tiering per documenti
- CloudWatch logs retention: 7 giorni
- Budget alerts configurati

## 🚦 CI/CD

```bash
# Deploy pipeline
git push origin main
  → AWS CodePipeline
    → Build (CodeBuild)
    → Test (pytest)
    → Security scan (bandit)
    → Deploy dev
    → Integration tests
    → Deploy staging
    → Manual approval
    → Deploy prod
```

## 📞 Support

- **Documentazione**: [docs/](docs/)
- **Issues**: GitHub Issues
- **Security**: Vedi [SECURITY.md](SECURITY.md)

## 📄 License

MIT License - see [LICENSE](LICENSE)

## 🤝 Contributing

Vedi [DEVELOPMENT.md](docs/DEVELOPMENT.md) per guidelines di contribuzione.

---

**Versione**: 1.0.0  
**Last Updated**: April 2026  
**AWS Region**: eu-west-1 (Ireland)
