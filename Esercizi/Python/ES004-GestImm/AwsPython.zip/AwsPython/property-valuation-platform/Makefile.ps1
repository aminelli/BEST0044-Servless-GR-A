# Makefile.ps1 - PowerShell Makefile per Windows
# Automazione completa per development, testing, e deployment su Windows

param(
    [Parameter(Position=0)]
    [string]$Task = "help",
    
    [Parameter()]
    [string]$Environment = "dev",
    
    [Parameter()]
    [string]$Region = "eu-west-1"
)

# Configurazione
$PYTHON = "python"
$PIP = "pip"
$PYTEST = "pytest"
$SAM = "sam"
$AWS = "aws"
$STACK_NAME = "property-valuation-platform-$Environment"

# Funzioni helper
function Write-Success($message) {
    Write-Host "[SUCCESS] $message" -ForegroundColor Green
}

function Write-Info($message) {
    Write-Host "[INFO] $message" -ForegroundColor Cyan
}

function Write-Warning($message) {
    Write-Host "[WARNING] $message" -ForegroundColor Yellow
}

function Write-Error($message) {
    Write-Host "[ERROR] $message" -ForegroundColor Red
}

# Task definitions
$Tasks = @{
    "help" = {
        Write-Host "Property Valuation Platform - PowerShell Makefile" -ForegroundColor Green
        Write-Host ""
        Write-Host "Usage: .\Makefile.ps1 <task> [-Environment <env>] [-Region <region>]" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "Setup & Installation:" -ForegroundColor Yellow
        Write-Host "  setup              Setup completo del progetto"
        Write-Host "  install            Installa dipendenze"
        Write-Host "  install-dev        Installa dipendenze di sviluppo"
        Write-Host ""
        Write-Host "Testing:" -ForegroundColor Yellow
        Write-Host "  test               Esegui tutti i test"
        Write-Host "  test-unit          Esegui solo unit test"
        Write-Host "  test-cov           Test con coverage report"
        Write-Host ""
        Write-Host "Code Quality:" -ForegroundColor Yellow
        Write-Host "  lint               Esegui linting"
        Write-Host "  format             Formatta codice"
        Write-Host "  security           Security scan"
        Write-Host "  quality            Tutti i check di qualità"
        Write-Host ""
        Write-Host "Build & Deploy:" -ForegroundColor Yellow
        Write-Host "  build              Build SAM application"
        Write-Host "  validate           Valida template SAM"
        Write-Host "  deploy-dev         Deploy su dev"
        Write-Host "  deploy-staging     Deploy su staging"
        Write-Host "  deploy-prod        Deploy su production"
        Write-Host ""
        Write-Host "Local Development:" -ForegroundColor Yellow
        Write-Host "  local-api          Avvia API locale"
        Write-Host "  local-stack        Avvia servizi locali"
        Write-Host "  stop-local         Ferma servizi locali"
        Write-Host ""
        Write-Host "Monitoring:" -ForegroundColor Yellow
        Write-Host "  logs               Visualizza logs"
        Write-Host "  outputs            Mostra stack outputs"
        Write-Host "  describe           Descrivi stack"
        Write-Host ""
        Write-Host "Utilities:" -ForegroundColor Yellow
        Write-Host "  clean              Pulisci file temporanei"
        Write-Host "  seed               Popola database"
        Write-Host "  check-aws          Verifica credenziali AWS"
        Write-Host "  version            Mostra versioni tools"
        Write-Host ""
    }
    
    "setup" = {
        Write-Info "Setting up project..."
        
        Write-Info "[1/4] Creating virtual environment..."
        & $PYTHON -m venv venv
        
        Write-Info "[2/4] Activating and upgrading pip..."
        & .\venv\Scripts\Activate.ps1
        & $PIP install --upgrade pip
        
        Write-Info "[3/4] Installing dependencies..."
        & $PIP install -r requirements.txt -r requirements-dev.txt
        
        Write-Info "[4/4] Creating .env file..."
        if (-not (Test-Path .env)) {
            Copy-Item .env.example .env
            Write-Success ".env created - please configure it"
        } else {
            Write-Warning ".env already exists"
        }
        
        Write-Success "Setup complete!"
    }
    
    "install" = {
        Write-Info "Installing dependencies..."
        & $PIP install -r requirements.txt
        Write-Success "Dependencies installed"
    }
    
    "install-dev" = {
        Write-Info "Installing dev dependencies..."
        & $PIP install -r requirements.txt -r requirements-dev.txt
        Write-Success "Dev dependencies installed"
    }
    
    "test" = {
        Write-Info "Running all tests..."
        & $PYTEST tests/ -v
    }
    
    "test-unit" = {
        Write-Info "Running unit tests..."
        & $PYTEST tests/unit/ -v
    }
    
    "test-integration" = {
        Write-Info "Running integration tests..."
        & $PYTEST tests/integration/ -v
    }
    
    "test-cov" = {
        Write-Info "Running tests with coverage..."
        & $PYTEST tests/ --cov=src --cov-report=html --cov-report=term-missing
        Write-Info "Coverage report: htmlcov/index.html"
    }
    
    "lint" = {
        Write-Info "Running pylint..."
        & pylint src/ --fail-under=7.0
        Write-Info "Running mypy..."
        & mypy src/
    }
    
    "format" = {
        Write-Info "Formatting code with black..."
        & black src/ tests/ --line-length 100
        Write-Success "Code formatted"
    }
    
    "format-check" = {
        Write-Info "Checking code format..."
        & black src/ tests/ --check --line-length 100
    }
    
    "security" = {
        Write-Info "Running security scan..."
        & bandit -r src/ -ll
    }
    
    "quality" = {
        & $Tasks["lint"].Invoke()
        & $Tasks["format-check"].Invoke()
        & $Tasks["security"].Invoke()
    }
    
    "validate" = {
        Write-Info "Validating SAM template..."
        & $SAM validate --lint
    }
    
    "build" = {
        Write-Info "Building SAM application..."
        & $SAM build --use-container --cached --parallel
        Write-Success "Build complete"
    }
    
    "build-local" = {
        Write-Info "Building SAM application (local)..."
        & $SAM build --cached
        Write-Success "Build complete"
    }
    
    "local-api" = {
        & $Tasks["build-local"].Invoke()
        Write-Info "Starting local API..."
        & $SAM local start-api --port 3000
    }
    
    "dynamodb-local" = {
        Write-Info "Starting DynamoDB Local..."
        docker run -d -p 8000:8000 --name dynamodb-local amazon/dynamodb-local
        Write-Success "DynamoDB Local running on http://localhost:8000"
    }
    
    "redis-local" = {
        Write-Info "Starting Redis Local..."
        docker run -d -p 6379:6379 --name redis-local redis:7-alpine
        Write-Success "Redis Local running on localhost:6379"
    }
    
    "local-stack" = {
        & $Tasks["dynamodb-local"].Invoke()
        & $Tasks["redis-local"].Invoke()
        Write-Success "Local stack running"
    }
    
    "stop-local" = {
        Write-Info "Stopping local services..."
        docker stop dynamodb-local redis-local 2>$null
        docker rm dynamodb-local redis-local 2>$null
        Write-Success "Local services stopped"
    }
    
    "deploy-dev" = {
        Write-Info "Deploying to DEV..."
        & .\scripts\deploy.sh dev
    }
    
    "deploy-staging" = {
        & $Tasks["test-cov"].Invoke()
        & $Tasks["security"].Invoke()
        Write-Info "Deploying to STAGING..."
        & .\scripts\deploy.sh staging
    }
    
    "deploy-prod" = {
        Write-Warning "⚠️  DEPLOYING TO PRODUCTION ⚠️"
        $confirm = Read-Host "Type 'PRODUCTION' to confirm"
        if ($confirm -eq "PRODUCTION") {
            & $Tasks["test-cov"].Invoke()
            & $Tasks["security"].Invoke()
            & .\scripts\deploy.sh prod
        } else {
            Write-Error "Deployment cancelled"
        }
    }
    
    "deploy" = {
        & $Tasks["build"].Invoke()
        Write-Info "Deploying to $Environment..."
        & $SAM deploy `
            --config-env $Environment `
            --stack-name $STACK_NAME `
            --region $Region `
            --capabilities CAPABILITY_IAM `
            --no-confirm-changeset
    }
    
    "seed" = {
        Write-Info "Seeding database..."
        & $PYTHON scripts/seed_data.py --environment $Environment --num-properties 50
    }
    
    "logs" = {
        Write-Info "Fetching logs..."
        & $SAM logs --stack-name $STACK_NAME --tail
    }
    
    "watch" = {
        Write-Info "Watching logs..."
        & $SAM logs --stack-name $STACK_NAME --tail --follow
    }
    
    "outputs" = {
        Write-Info "Stack outputs:"
        & $AWS cloudformation describe-stacks `
            --stack-name $STACK_NAME `
            --query 'Stacks[0].Outputs' `
            --output table
    }
    
    "describe" = {
        & $AWS cloudformation describe-stacks `
            --stack-name $STACK_NAME `
            --output table
    }
    
    "events" = {
        & $AWS cloudformation describe-stack-events `
            --stack-name $STACK_NAME `
            --max-items 20 `
            --output table
    }
    
    "resources" = {
        & $AWS cloudformation describe-stack-resources `
            --stack-name $STACK_NAME `
            --output table
    }
    
    "clean" = {
        Write-Info "Cleaning temporary files..."
        Get-ChildItem -Path . -Recurse -Directory -Filter __pycache__ | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
        Get-ChildItem -Path . -Recurse -Directory -Filter .pytest_cache | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
        Get-ChildItem -Path . -Recurse -Directory -Filter .mypy_cache | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
        Get-ChildItem -Path . -Recurse -Filter "*.pyc" | Remove-Item -Force -ErrorAction SilentlyContinue
        Remove-Item -Path .coverage, htmlcov, .aws-sam -Recurse -Force -ErrorAction SilentlyContinue
        Write-Success "Cleaned"
    }
    
    "clean-all" = {
        & $Tasks["clean"].Invoke()
        Write-Info "Removing virtual environment..."
        Remove-Item -Path venv -Recurse -Force -ErrorAction SilentlyContinue
        Write-Success "All cleaned"
    }
    
    "check-aws" = {
        Write-Info "Checking AWS credentials..."
        & $AWS sts get-caller-identity
    }
    
    "version" = {
        Write-Info "Tool versions:"
        Write-Host "Python:  $(& $PYTHON --version)"
        Write-Host "AWS CLI: $(& $AWS --version)"
        Write-Host "SAM CLI: $(& $SAM --version)"
        Write-Host "Pytest:  $(& $PYTEST --version)"
    }
    
    "status" = {
        Write-Info "Project Status:"
        Write-Host "Environment: $Environment"
        Write-Host "Stack:       $STACK_NAME"
        Write-Host "Region:      $Region"
        git status -s 2>$null
    }
    
    "ready" = {
        & $Tasks["quality"].Invoke()
        & $Tasks["test-cov"].Invoke()
        & $Tasks["build"].Invoke()
        Write-Success "Project ready for commit/deploy!"
    }
}

# Execute task
if ($Tasks.ContainsKey($Task)) {
    try {
        & $Tasks[$Task]
    } catch {
        Write-Error "Task failed: $_"
        exit 1
    }
} else {
    Write-Error "Unknown task: $Task"
    Write-Host ""
    & $Tasks["help"]
    exit 1
}
