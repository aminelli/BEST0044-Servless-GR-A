# Development Guide

Guida per sviluppatori che contribuiscono al progetto Property Valuation Platform.

---

## Setup Ambiente Locale

### 1. Clone Repository

```bash
git clone https://github.com/your-org/property-valuation-platform.git
cd property-valuation-platform
```

### 2. Quick Setup (Automated)

**Linux/Mac**:
```bash
chmod +x scripts/setup.sh
./scripts/setup.sh
```

**Windows (PowerShell)**:
```powershell
.\scripts\setup.ps1
```

Lo script automatizza:
- ✅ Creazione virtual environment
- ✅ Installazione dipendenze
- ✅ Creazione file `.env` da template
- ✅ Setup pre-commit hooks
- ✅ Verifica credenziali AWS

### 3. Manual Setup (Alternative)

Se preferisci setup manuale:

```bash
# Crea virtual environment
python3.12 -m venv venv

# Attiva (Windows)
.\venv\Scripts\activate

# Attiva (Linux/Mac)
source venv/bin/activate

# Verifica
python --version
# Python 3.12.2

# Install dependencies
pip install -r requirements.txt
pip install -r requirements-dev.txt

# Setup environment
cp .env.example .env
# Edit .env with your configuration
```

### 4. Configure Environment Variables

Edit `.env` file (created from `.env.example`):

```bash
# Required settings
AWS_REGION=eu-west-1
ENVIRONMENT=dev
TABLE_NAME=properties-dev
EVENT_BUS_NAME=property-valuation-dev-event-bus

# Optional: Local services
REDIS_HOST=localhost
REDIS_PORT=6379
DYNAMODB_ENDPOINT=http://localhost:8000

# Logging
LOG_LEVEL=DEBUG
POWERTOOLS_SERVICE_NAME=property-valuation
```

**Vedi `.env.example` per tutte le opzioni disponibili.**

### 4. Configure Pre-commit Hooks

```bash
# Install pre-commit
pip install pre-commit

# Setup hooks
pre-commit install

# Run manually
pre-commit run --all-files
```

---

## Local Development con SAM

### Invocare Lambda Localmente

```bash
# Build
sam build

# Invoke singola function
sam local invoke CreatePropertyFunction \
    --event tests/events/create_property.json

# Output:
# {
#   "statusCode": 201,
#   "body": "{\"property_id\": \"...\", ...}"
# }
```

### Local API Gateway

```bash
# Avvia API Gateway locale
sam local start-api --port 3000

# In altro terminale, testa endpoint
curl -X POST http://localhost:3000/properties \
    -H "Content-Type: application/json" \
    -d @tests/fixtures/property_sample.json
```

### DynamoDB Local

```bash
# Docker container con DynamoDB Local
docker run -p 8000:8000 amazon/dynamodb-local

# Crea tabella locale
aws dynamodb create-table \
    --table-name properties-local \
    --attribute-definitions \
        AttributeName=PK,AttributeType=S \
        AttributeName=SK,AttributeType=S \
    --key-schema \
        AttributeName=PK,KeyType=HASH \
        AttributeName=SK,KeyType=RANGE \
    --billing-mode PAY_PER_REQUEST \
    --endpoint-url http://localhost:8000

# List tables
aws dynamodb list-tables --endpoint-url http://localhost:8000
```

---

## Testing

### Unit Tests

```bash
# Run all tests
pytest tests/unit -v

# Run con coverage
pytest tests/unit --cov=src --cov-report=html

# Apri report coverage
open htmlcov/index.html  # Mac
start htmlcov/index.html # Windows
```

### Integration Tests

```bash
# Richiede AWS credentials configurate
pytest tests/integration -v --environment=dev

# Con logging
pytest tests/integration -v -s
```

### Test Specifici

```bash
# Test singolo file
pytest tests/unit/test_models.py -v

# Test singola funzione
pytest tests/unit/test_models.py::test_property_validation -v

# Test con keyword
pytest tests/ -k "valuation" -v
```

### Coverage Requirements

Il progetto richiede **>80% test coverage**. Verifica con:

```bash
pytest tests/ --cov=src --cov-report=term-missing --cov-fail-under=80
```

---

## Code Quality

### Linting con Pylint

```bash
# Lint tutto il codice
pylint src/

# Lint singolo file
pylint src/models/__init__.py

# Con score minimo
pylint src/ --fail-under=8.0
```

### Formatting con Black

```bash
# Format tutto il codice
black src/ tests/

# Check senza modificare
black src/ tests/ --check

# Diff
black src/ --diff
```

### Type Checking con MyPy

```bash
# Type check
mypy src/

# Con config
mypy src/ --config-file=pyproject.toml
```

### Security Scanning con Bandit

```bash
# Scan per vulnerabilità
bandit -r src/ -ll

# Con output JSON
bandit -r src/ -ll -f json -o bandit-report.json
```

### All-in-One Quality Check

```bash
# Script che esegue tutti i check
./scripts/quality_check.sh

# Oppure manualmente
black src/ tests/ --check && \
pylint src/ --fail-under=8.0 && \
mypy src/ && \
bandit -r src/ -ll && \
pytest tests/ --cov=src --cov-fail-under=80
```

---

## Project Structure

```
property-valuation-platform/
├── src/
│   ├── functions/          # Lambda functions
│   │   ├── api/           # API handlers
│   │   ├── events/        # Event handlers
│   │   └── jobs/          # Background jobs
│   ├── models/            # Pydantic domain models
│   ├── repositories/      # Data access layer
│   ├── services/          # Business logic
│   └── utils/             # Utilities
├── tests/
│   ├── unit/              # Unit tests
│   ├── integration/       # Integration tests
│   ├── fixtures/          # Test data
│   └── events/            # Test events
├── infrastructure/
│   └── template.yaml      # SAM template
├── docs/                  # Documentation
├── scripts/               # Automation scripts
├── requirements.txt       # Production deps
├── requirements-dev.txt   # Dev deps
├── pyproject.toml         # Tool config
├── samconfig.toml         # SAM config
└── README.md
```

---

## Git Workflow

### Branch Strategy

- `main`: Production-ready code
- `develop`: Integration branch
- `feature/*`: New features
- `bugfix/*`: Bug fixes
- `hotfix/*`: Production hotfixes

### Creating Feature Branch

```bash
# Update develop
git checkout develop
git pull origin develop

# Create feature branch
git checkout -b feature/mortgage-calculator

# Work on feature
git add .
git commit -m "feat: implement mortgage calculator"

# Push to remote
git push -u origin feature/mortgage-calculator

# Create Pull Request on GitHub
```

### Commit Message Convention

Seguiamo [Conventional Commits](https://www.conventionalcommits.org/):

```
<type>(<scope>): <subject>

<body>

<footer>
```

**Types**:
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation changes
- `style`: Code style (formatting, etc.)
- `refactor`: Code refactoring
- `test`: Adding/updating tests
- `chore`: Maintenance tasks

**Examples**:
```bash
git commit -m "feat(api): add mortgage calculation endpoint"
git commit -m "fix(valuation): correct price adjustment formula"
git commit -m "docs(readme): update deployment instructions"
git commit -m "test(models): add property validation tests"
```

---

## Debugging

### Lambda Function Debugging

```bash
# Con SAM
sam local invoke CreatePropertyFunction \
    --event tests/events/create_property.json \
    --debug

# Con pdb breakpoint
# Aggiungi in codice:
import pdb; pdb.set_trace()

# Run
sam local invoke CreatePropertyFunction --event tests/events/create_property.json
```

### Remote Debugging (Live Lambda)

```bash
# View logs in real-time
sam logs -n CreatePropertyFunction \
    --stack-name property-valuation-platform-dev \
    --tail

# Con AWS CLI
aws logs tail /aws/lambda/property-valuation-dev-CreateProperty --follow
```

### X-Ray Traces

```bash
# Get trace IDs
aws xray get-trace-summaries \
    --start-time $(date -u -d '1 hour ago' +%s) \
    --end-time $(date -u +%s)

# Get trace details
aws xray batch-get-traces --trace-ids <trace-id>
```

---

## Environment Variables

### Local Development

Crea file `.env.local` (non committare):

```bash
# AWS
AWS_REGION=eu-west-1
TABLE_NAME=properties-local
EVENT_BUS_NAME=default

# Redis (opzionale per local)
REDIS_HOST=localhost
REDIS_PORT=6379

# Logging
LOG_LEVEL=DEBUG
POWERTOOLS_SERVICE_NAME=property-valuation-local
```

Carica con:
```python
from dotenv import load_dotenv
load_dotenv('.env.local')
```

---

## Database Migrations

Non usiamo migrations tradizionali (NoSQL), ma per modifiche schema:

### Add New Attribute

```python
# 1. Update Pydantic model
class Property(BaseModel):
    # ... existing fields
    new_field: Optional[str] = None  # Always optional for backwards compatibility

# 2. Update repository
def update_property(self, property_id: str, updates: dict):
    # Gestisce sia vecchi che nuovi items
    ...

# 3. Backfill script (se necessario)
# scripts/backfill_new_field.py
```

### Add New GSI

```yaml
# infrastructure/template.yaml
GlobalSecondaryIndexes:
  - IndexName: GSI3
    KeySchema:
      - AttributeName: GSI3PK
        KeyType: HASH
      - AttributeName: GSI3SK
        KeyType: RANGE
    Projection:
      ProjectionType: ALL
```

Deploy con:
```bash
sam deploy --config-env dev
# ⚠️ GSI creation prende ~5-10 minuti
```

---

## Performance Profiling

### Lambda Duration Analysis

```bash
# Con AWS CLI
aws logs filter-log-events \
    --log-group-name /aws/lambda/property-valuation-dev-CreateProperty \
    --filter-pattern "REPORT RequestId" \
    --start-time $(date -u -d '1 hour ago' +%s)000 \
    | jq '.events[].message' \
    | grep "Duration"
```

### Cold Start Optimization

```python
# ❌ Bad: Import inside handler
def lambda_handler(event, context):
    import boto3  # Cold start penalty
    ...

# ✅ Good: Import at module level
import boto3  # Loaded once

def lambda_handler(event, context):
    ...
```

### Profiling con cProfile

```python
import cProfile
import pstats

def lambda_handler(event, context):
    profiler = cProfile.Profile()
    profiler.enable()
    
    # Your code here
    result = process_valuation()
    
    profiler.disable()
    stats = pstats.Stats(profiler)
    stats.sort_stats('cumulative')
    stats.print_stats(20)
    
    return result
```

---

## Troubleshooting Common Issues

### Issue: "Module not found"

```bash
# Rebuild dependencies layer
rm -rf .aws-sam
sam build --use-container
```

### Issue: DynamoDB "ResourceNotFoundException"

```bash
# Verifica table esiste
aws dynamodb list-tables --region eu-west-1

# Crea table se manca
sam deploy --config-env dev
```

### Issue: Lambda timeout

```yaml
# Aumenta timeout in template.yaml
CreatePropertyFunction:
  Type: AWS::Serverless::Function
  Properties:
    Timeout: 60  # Da 30 a 60 secondi
```

### Issue: Permission denied errors

```bash
# Verifica IAM role policies
aws iam get-role-policy \
    --role-name property-valuation-dev-CreatePropertyRole \
    --policy-name CreatePropertyPolicy
```

---

## Best Practices

### Lambda Functions

✅ **DO**:
- Keep handlers thin (delegate to services)
- Use AWS Lambda Powertools
- Log structured JSON
- Handle errors gracefully
- Set appropriate timeouts/memory
- Use environment variables for config

❌ **DON'T**:
- Put business logic in handlers
- Make synchronous calls when async possible
- Ignore errors
- Hardcode configuration
- Use global state

### DynamoDB

✅ **DO**:
- Use single-table design
- Optimize for access patterns
- Use batch operations
- Enable point-in-time recovery
- Use consistent reads only when needed

❌ **DON'T**:
- Scan tables (use Query with GSI)
- Use auto-incrementing IDs (use UUIDs)
- Store large items (>400KB)
- Over-provision capacity

### Security

✅ **DO**:
- Use AWS Secrets Manager for secrets
- Enable encryption at rest
- Use HTTPS only
- Validate all inputs
- Follow least privilege for IAM

❌ **DON'T**:
- Commit secrets to Git
- Disable CORS without reason
- Trust user input
- Use overly permissive IAM policies

---

## Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Write tests for your changes
4. Ensure all tests pass (`pytest tests/`)
5. Ensure code quality (`black`, `pylint`, `mypy`)
6. Commit changes (`git commit -m 'feat: add amazing feature'`)
7. Push to branch (`git push origin feature/amazing-feature`)
8. Open Pull Request

### Pull Request Checklist

- [ ] Tests added/updated
- [ ] Documentation updated
- [ ] Code formatted with Black
- [ ] Pylint score >= 8.0
- [ ] MyPy passes
- [ ] Coverage >= 80%
- [ ] Commit messages follow convention
- [ ] PR description explains changes

---

## Resources

- [AWS Lambda Developer Guide](https://docs.aws.amazon.com/lambda/latest/dg/welcome.html)
- [AWS SAM Documentation](https://docs.aws.amazon.com/serverless-application-model/)
- [DynamoDB Best Practices](https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/best-practices.html)
- [AWS Lambda Powertools](https://docs.powertools.aws.dev/lambda/python/latest/)
- [Pydantic Documentation](https://docs.pydantic.dev/)

---

## Support

- **Issues**: https://github.com/your-org/property-valuation-platform/issues
- **Discussions**: https://github.com/your-org/property-valuation-platform/discussions
- **Slack**: #property-valuation-dev
