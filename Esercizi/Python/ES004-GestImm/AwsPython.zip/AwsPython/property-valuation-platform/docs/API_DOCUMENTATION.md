# API Documentation

## Base URL

```
https://{api-id}.execute-api.{region}.amazonaws.com/prod
```

**Example**: `https://abc123xyz.execute-api.eu-west-1.amazonaws.com/prod`

---

## Authentication

Tutti gli endpoint richiedono autenticazione JWT tramite AWS Cognito.

### Headers Richiesti
```http
Authorization: Bearer <jwt_token>
Content-Type: application/json
```

### Ottenere un JWT Token

```bash
aws cognito-idp initiate-auth \
  --auth-flow USER_PASSWORD_AUTH \
  --client-id <client-id> \
  --auth-parameters USERNAME=<username>,PASSWORD=<password>
```

Risposta:
```json
{
  "AuthenticationResult": {
    "AccessToken": "eyJraWQiOiJ...",
    "IdToken": "eyJraWQiOiJ...",
    "RefreshToken": "eyJraWQiOiJ...",
    "ExpiresIn": 3600
  }
}
```

---

## Endpoints Overview

| Metodo | Endpoint | Descrizione | Auth |
|--------|----------|-------------|------|
| POST | /properties | Crea nuovo immobile | ✅ |
| GET | /properties/{id} | Dettagli immobile | ✅ |
| PUT | /properties/{id} | Aggiorna immobile | ✅ |
| DELETE | /properties/{id} | Elimina immobile (soft) | ✅ |
| GET | /properties | Lista immobili | ✅ |
| POST | /properties/{id}/valuations | Richiedi valutazione | ✅ |
| GET | /properties/{id}/valuations | Storico valutazioni | ✅ |
| GET | /properties/{id}/risk-assessment | Valutazione rischi | ✅ |
| POST | /mortgages/calculate | Simula mutuo | ✅ |
| GET | /areas/{id}/statistics | Statistiche zona | ✅ |
| GET | /renovations/{id}/analysis | Analisi ristrutturazione | ✅ |

---

## Properties API

### POST /properties

Crea un nuovo immobile.

**Request Body**:
```json
{
  "address": {
    "street": "Via Roma 123",
    "city": "Milano",
    "province": "MI",
    "postal_code": "20100",
    "country": "Italia",
    "coordinates": {
      "latitude": 45.4642,
      "longitude": 9.1900
    }
  },
  "property_type": "apartment",
  "surface_sqm": 85.5,
  "construction_year": 2010,
  "condition": "good",
  "rooms": 3,
  "bathrooms": 2,
  "floor": 3,
  "has_elevator": true,
  "has_parking": true,
  "has_garden": false,
  "has_terrace": true,
  "energy_class": "B",
  "heating_type": "autonomous",
  "amenities": ["balcony", "double_glazing", "alarm_system"]
}
```

**Response** `201 Created`:
```json
{
  "property_id": "550e8400-e29b-41d4-a716-446655440000",
  "message": "Immobile creato con successo",
  "data": {
    "property_id": "550e8400-e29b-41d4-a716-446655440000",
    "address": { "..." },
    "property_type": "apartment",
    "surface_sqm": 85.5,
    "created_at": "2026-04-28T10:00:00Z",
    "updated_at": "2026-04-28T10:00:00Z"
  }
}
```

**Errors**:
- `400` - Validation error
- `409` - Immobile già esistente
- `500` - Errore server

**Example cURL**:
```bash
curl -X POST https://api.example.com/prod/properties \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -d @property.json
```

---

### GET /properties/{id}

Recupera dettagli di un immobile specifico.

**Path Parameters**:
- `id` (string, required): Property ID (UUID)

**Response** `200 OK`:
```json
{
  "data": {
    "property_id": "550e8400-e29b-41d4-a716-446655440000",
    "address": {
      "street": "Via Roma 123",
      "city": "Milano",
      "province": "MI",
      "postal_code": "20100",
      "country": "Italia",
      "coordinates": {
        "latitude": 45.4642,
        "longitude": 9.1900
      }
    },
    "property_type": "apartment",
    "surface_sqm": 85.5,
    "construction_year": 2010,
    "condition": "good",
    "rooms": 3,
    "bathrooms": 2,
    "floor": 3,
    "has_elevator": true,
    "has_parking": true,
    "created_at": "2026-04-28T10:00:00Z",
    "updated_at": "2026-04-28T10:00:00Z"
  }
}
```

**Headers**:
- `X-Cache: HIT` - Risposta da cache
- `X-Cache: MISS` - Risposta da database

**Errors**:
- `404` - Immobile non trovato
- `500` - Errore server

---

### PUT /properties/{id}

Aggiorna un immobile esistente.

**Path Parameters**:
- `id` (string, required): Property ID

**Request Body** (tutti i campi opzionali):
```json
{
  "condition": "excellent",
  "energy_class": "A",
  "has_parking": true,
  "amenities": ["balcony", "double_glazing", "alarm_system", "air_conditioning"]
}
```

**Response** `200 OK`:
```json
{
  "message": "Immobile aggiornato con successo",
  "data": { "..." }
}
```

**Errors**:
- `400` - Validation error
- `404` - Immobile non trovato
- `500` - Errore server

---

### DELETE /properties/{id}

Elimina un immobile (soft delete).

**Path Parameters**:
- `id` (string, required): Property ID

**Response** `200 OK`:
```json
{
  "message": "Immobile eliminato con successo"
}
```

**Errors**:
- `404` - Immobile non trovato
- `500` - Errore server

---

### GET /properties

Lista immobili con filtri e paginazione.

**Query Parameters**:
- `city` (string, optional): Filtra per città
- `property_type` (string, optional): Filtra per tipo (apartment, house, villa, ...)
- `min_surface` (number, optional): Superficie minima (mq)
- `max_surface` (number, optional): Superficie massima (mq)
- `min_price` (number, optional): Prezzo minimo (€)
- `max_price` (number, optional): Prezzo massimo (€)
- `limit` (number, optional): Risultati per pagina (default: 20, max: 100)
- `page_token` (string, optional): Token paginazione

**Response** `200 OK`:
```json
{
  "items": [
    {
      "property_id": "550e8400-e29b-41d4-a716-446655440000",
      "address": { "..." },
      "property_type": "apartment",
      "surface_sqm": 85.5,
      "estimated_value": 250000
    }
  ],
  "total_count": 1243,
  "page_token": "eyJsYXN0X2V2YWx1YXRlZF9rZXkiOiB7InBrIjogIi4uLiJ9fQ==",
  "has_more": true
}
```

**Example**:
```bash
curl "https://api.example.com/prod/properties?city=Milano&property_type=apartment&limit=10" \
  -H "Authorization: Bearer ${TOKEN}"
```

---

## Valuations API

### POST /properties/{id}/valuations

Richiede una nuova valutazione per un immobile.

**Path Parameters**:
- `id` (string, required): Property ID

**Request Body** (opzionale):
```json
{
  "methodology": "comparative",
  "force_refresh": false
}
```

**Parameters**:
- `methodology` (string): "comparative" | "income" | "cost" (default: "comparative")
- `force_refresh` (boolean): Forza ricalcolo anche se valutazione recente esiste

**Response** `201 Created`:
```json
{
  "message": "Valutazione completata con successo",
  "data": {
    "valuation_id": "val-abc-123",
    "property_id": "550e8400-e29b-41d4-a716-446655440000",
    "estimated_value": 250000,
    "min_value": 225000,
    "max_value": 275000,
    "price_per_sqm": 2923,
    "methodology": "comparative",
    "comparable_properties": ["prop-1", "prop-2", "prop-3"],
    "confidence_level": 0.85,
    "valuation_date": "2026-04-28T10:30:00Z",
    "valid_until": "2026-07-27T10:30:00Z"
  },
  "calculation_time_seconds": 1.234
}
```

**Errors**:
- `404` - Immobile non trovato
- `500` - Errore calcolo

**Example**:
```bash
curl -X POST https://api.example.com/prod/properties/550e8400.../valuations \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{"methodology": "comparative", "force_refresh": true}'
```

---

### GET /properties/{id}/valuations

Recupera lo storico delle valutazioni per un immobile.

**Path Parameters**:
- `id` (string, required): Property ID

**Query Parameters**:
- `limit` (number, optional): Numero di valutazioni (default: 10)

**Response** `200 OK`:
```json
{
  "property_id": "550e8400-e29b-41d4-a716-446655440000",
  "valuations": [
    {
      "valuation_id": "val-abc-123",
      "estimated_value": 250000,
      "valuation_date": "2026-04-28T10:30:00Z",
      "methodology": "comparative"
    },
    {
      "valuation_id": "val-abc-122",
      "estimated_value": 245000,
      "valuation_date": "2026-01-15T14:20:00Z",
      "methodology": "comparative"
    }
  ],
  "total_count": 5
}
```

---

## Risk Assessment API

### GET /properties/{id}/risk-assessment

Recupera la valutazione dei rischi per un immobile.

**Path Parameters**:
- `id` (string, required): Property ID

**Response** `200 OK`:
```json
{
  "property_id": "550e8400-e29b-41d4-a716-446655440000",
  "risk_assessment": {
    "assessment_id": "risk-xyz-789",
    "seismic_risk": "medium",
    "seismic_zone": "3",
    "hydrogeological_risk": "low",
    "flood_zone": false,
    "environmental_risk": "low",
    "contaminated_site": false,
    "overall_risk_score": 3.2,
    "recommendations": [
      "Considerare assicurazione sismica",
      "Verificare conformità normativa antisismica"
    ],
    "assessment_date": "2026-04-28T11:00:00Z"
  }
}
```

**Risk Levels**: "very_low" | "low" | "medium" | "high" | "very_high"

---

## Mortgage Calculator API

### POST /mortgages/calculate

Calcola una simulazione di mutuo.

**Request Body**:
```json
{
  "loan_amount": 200000,
  "property_value": 250000,
  "mortgage_type": "fixed",
  "duration_years": 25,
  "interest_rate": 3.5,
  "applicant_income": 45000
}
```

**Parameters**:
- `loan_amount` (number, required): Importo mutuo (€)
- `property_value` (number, required): Valore immobile (€)
- `mortgage_type` (string, required): "fixed" | "variable" | "mixed"
- `duration_years` (number, required): Durata mutuo (anni)
- `interest_rate` (number, required): Tasso interesse annuo (%)
- `applicant_income` (number, optional): Reddito annuo richiedente (€)

**Response** `200 OK`:
```json
{
  "message": "Simulazione mutuo calcolata con successo",
  "data": {
    "simulation_id": "sim-abc-456",
    "loan_amount": 200000,
    "property_value": 250000,
    "mortgage_type": "fixed",
    "duration_years": 25,
    "interest_rate": 3.5,
    "monthly_payment": 1001.32,
    "total_interest": 100396.00,
    "total_amount": 300396.00,
    "taeg": 3.5,
    "tan": 3.5,
    "ltv_ratio": 80.00,
    "applicant_income": 45000,
    "dti_ratio": 26.70,
    "is_sustainable": true
  },
  "summary": {
    "monthly_payment": "1001.32€",
    "total_to_repay": "300396.00€",
    "total_interest": "100396.00€",
    "ltv_ratio": "80.00%",
    "dti_ratio": "26.70%",
    "is_sustainable": true
  }
}
```

**Formula Utilizzata** (Ammortamento alla Francese):
```
M = P * [i(1 + i)^n] / [(1 + i)^n - 1]

Dove:
M = rata mensile
P = capitale (loan_amount)
i = tasso interesse mensile (interest_rate / 12 / 100)
n = numero rate (duration_years * 12)
```

**Sustainability Check**:
- `DTI Ratio < 35%` → `is_sustainable: true`
- `DTI Ratio >= 35%` → `is_sustainable: false`

---

## Area Statistics API

### GET /areas/{id}/statistics

Recupera statistiche di mercato per una zona geografica.

**Path Parameters**:
- `id` (string, required): Area ID (es: "milano-centro", "roma-parioli")

**Query Parameters**:
- `period` (string, optional): Periodo analisi ("1month" | "3months" | "6months" | "1year")

**Response** `200 OK`:
```json
{
  "area_id": "milano-centro",
  "area_name": "Milano Centro",
  "statistics": {
    "total_properties": 1234,
    "average_price_per_sqm": 4500,
    "median_price_per_sqm": 4200,
    "min_price_per_sqm": 2800,
    "max_price_per_sqm": 7500,
    "price_trend": "increasing",
    "price_change_percentage": 5.2,
    "average_days_on_market": 45,
    "transactions_last_month": 89,
    "property_types_distribution": {
      "apartment": 78,
      "house": 12,
      "villa": 5,
      "office": 3,
      "commercial": 2
    },
    "last_updated": "2026-04-28T00:00:00Z"
  }
}
```

---

## Error Responses

Tutti gli errori seguono questo formato:

```json
{
  "error": "ERROR_CODE",
  "message": "Descrizione errore human-readable",
  "details": { /* Dettagli aggiuntivi */ }
}
```

### Common Error Codes

| Status | Error Code | Description |
|--------|-----------|-------------|
| 400 | VALIDATION_ERROR | Dati input non validi |
| 401 | UNAUTHORIZED | Token JWT mancante o invalido |
| 403 | FORBIDDEN | Permessi insufficienti |
| 404 | NOT_FOUND | Risorsa non trovata |
| 409 | CONFLICT | Conflitto (es. risorsa già esistente) |
| 429 | RATE_LIMIT_EXCEEDED | Troppi richieste |
| 500 | INTERNAL_ERROR | Errore server |
| 503 | SERVICE_UNAVAILABLE | Servizio temporaneamente non disponibile |

---

## Rate Limiting

**Limits**:
- 100 requests/second per API key
- 10,000 requests/day per API key

**Headers di Risposta**:
```http
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 87
X-RateLimit-Reset: 1619712000
```

Quando il limite viene superato:
```http
HTTP/1.1 429 Too Many Requests
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 0
X-RateLimit-Reset: 1619712000

{
  "error": "RATE_LIMIT_EXCEEDED",
  "message": "Troppi richieste. Riprova tra 1 secondo."
}
```

---

## Pagination

Tutti gli endpoint che restituiscono liste supportano paginazione basata su token.

**Query Parameters**:
- `limit`: Numero di risultati (default: 20, max: 100)
- `page_token`: Token per pagina successiva

**Response Structure**:
```json
{
  "items": [...],
  "total_count": 1234,
  "page_token": "base64_encoded_token",
  "has_more": true
}
```

**Example**:
```bash
# Prima pagina
curl "https://api.example.com/prod/properties?limit=20"

# Pagina successiva
curl "https://api.example.com/prod/properties?limit=20&page_token=eyJ..."
```

---

## API Versioning

Current version: **v1**

L'API segue semantic versioning. Breaking changes comportano un aumento della versione major.

**Base URL include version**:
```
https://{api-id}.execute-api.{region}.amazonaws.com/v1
```

---

## OpenAPI 3.0 Specification

La specifica OpenAPI completa è disponibile a:
```
https://{api-id}.execute-api.{region}.amazonaws.com/v1/openapi.json
```

Per importare in Postman/Swagger:
```bash
curl https://api.example.com/v1/openapi.json > openapi.yaml
```

---

## SDK & Client Libraries

### Python
```python
import requests

API_BASE = "https://api.example.com/prod"
TOKEN = "your-jwt-token"

headers = {
    "Authorization": f"Bearer {TOKEN}",
    "Content-Type": "application/json"
}

# Create property
response = requests.post(
    f"{API_BASE}/properties",
    headers=headers,
    json={
        "address": {...},
        "property_type": "apartment",
        "surface_sqm": 85.5
    }
)

property_data = response.json()
print(property_data['property_id'])
```

### JavaScript/TypeScript
```javascript
const API_BASE = 'https://api.example.com/prod';
const TOKEN = 'your-jwt-token';

async function createProperty(data) {
  const response = await fetch(`${API_BASE}/properties`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${TOKEN}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(data)
  });
  
  return await response.json();
}
```

---

## Testing

### Health Check
```bash
curl https://api.example.com/prod/health
```

**Response**:
```json
{
  "status": "healthy",
  "version": "1.0.0",
  "timestamp": "2026-04-28T12:00:00Z"
}
```

---

## Support

Per problemi o domande:
- **Email**: api-support@example.com
- **Docs**: https://docs.example.com
- **Status Page**: https://status.example.com
