# Makefile Guide

Guida completa all'uso del Makefile per l'automazione del progetto.

## 🚀 Quick Start

### Linux/Mac

```bash
# Setup iniziale
make setup

# Esegui test
make test

# Deploy su dev
make deploy-dev
```

### Windows (PowerShell)

```powershell
# Setup iniziale
.\Makefile.ps1 setup

# Esegui test
.\Makefile.ps1 test

# Deploy su dev
.\Makefile.ps1 deploy-dev
```

## 📋 Comandi Disponibili

### Setup & Installazione

| Comando | Descrizione | Esempio |
|---------|-------------|---------|
| `make setup` | Setup completo (venv + deps + .env) | `make setup` |
| `make install` | Installa solo dipendenze production | `make install` |
| `make install-dev` | Installa dipendenze di sviluppo | `make install-dev` |

**Output atteso**:
```
[1/4] Creating virtual environment...
[2/4] Activating and upgrading pip...
[3/4] Installing dependencies...
[4/4] Creating .env file...
✓ Setup complete!
```

### Testing

| Comando | Descrizione | Esempio |
|---------|-------------|---------|
| `make test` | Esegui tutti i test | `make test` |
| `make test-unit` | Solo unit test | `make test-unit` |
| `make test-integration` | Solo integration test | `make test-integration` |
| `make test-cov` | Test con coverage report | `make test-cov` |
| `make test-watch` | Test in watch mode | `make test-watch` |

**Esempio con coverage**:
```bash
make test-cov
# Output:
# Running tests with coverage...
# ========== 52 passed in 3.45s ==========
# Coverage report: htmlcov/index.html
# 
# Name                                Stmts   Miss  Cover
# -------------------------------------------------------
# src/models/__init__.py                 95      2    98%
# src/repositories/dynamodb_repository   87      5    94%
# src/services/valuation_service.py     112      8    93%
# -------------------------------------------------------
# TOTAL                                 856     42    95%
```

### Code Quality

| Comando | Descrizione | Esempio |
|---------|-------------|---------|
| `make lint` | Linting con pylint + mypy | `make lint` |
| `make format` | Formatta codice con black | `make format` |
| `make format-check` | Verifica formattazione | `make format-check` |
| `make security` | Security scan con bandit | `make security` |
| `make quality` | Tutti i check di qualità | `make quality` |

**Best practice workflow**:
```bash
# Prima di commit
make format      # Auto-formatta
make quality     # Verifica tutto
make test        # Assicurati che funzioni
```

### Build & Validation

| Comando | Descrizione | Esempio |
|---------|-------------|---------|
| `make validate` | Valida template SAM | `make validate` |
| `make build` | Build con container Docker | `make build` |
| `make build-local` | Build senza container (veloce) | `make build-local` |

**Differenza build vs build-local**:
- `build`: Usa Docker container (più lento, prod-like)
- `build-local`: Usa ambiente locale (veloce, per dev)

### Development Locale

| Comando | Descrizione | Esempio |
|---------|-------------|---------|
| `make local-api` | Avvia API Gateway locale (port 3000) | `make local-api` |
| `make dynamodb-local` | Avvia DynamoDB locale | `make dynamodb-local` |
| `make redis-local` | Avvia Redis locale | `make redis-local` |
| `make local-stack` | Avvia tutti i servizi locali | `make local-stack` |
| `make stop-local` | Ferma servizi locali | `make stop-local` |

**Workflow sviluppo locale**:
```bash
# 1. Avvia servizi locali
make local-stack
# DynamoDB: http://localhost:8000
# Redis: localhost:6379

# 2. Avvia API locale
make local-api
# API: http://localhost:3000

# 3. Test API
curl http://localhost:3000/health

# 4. Stop quando finito
make stop-local
```

**Shortcut completo**:
```bash
make dev  # = local-stack + local-api
```

### Deployment

| Comando | Descrizione | Esempio |
|---------|-------------|---------|
| `make deploy-dev` | Deploy su dev | `make deploy-dev` |
| `make deploy-staging` | Deploy su staging (con test) | `make deploy-staging` |
| `make deploy-prod` | Deploy su prod (con conferma) | `make deploy-prod` |
| `make deploy` | Deploy generico | `ENVIRONMENT=dev make deploy` |

**Flusso deployment**:

**Dev** (veloce, no test):
```bash
make deploy-dev
# Build → Deploy → Output URL
```

**Staging** (con test e security):
```bash
make deploy-staging
# Test → Coverage → Security → Build → Deploy
```

**Production** (con conferma):
```bash
make deploy-prod
# Test → Coverage → Security → Conferma → Build → Deploy → Tag
```

**Deploy custom**:
```bash
# Deploy su region specifica
REGION=us-east-1 make deploy

# Deploy con environment custom
ENVIRONMENT=qa make deploy
```

### Data Management

| Comando | Descrizione | Esempio |
|---------|-------------|---------|
| `make seed` | Popola DB con 50 properties | `ENVIRONMENT=dev make seed` |
| `make seed-prod` | Seed production (con conferma) | `make seed-prod` |

**Seed con parametri**:
```bash
# Seed dev con 100 properties
python scripts/seed_data.py --environment dev --num-properties 100

# Seed con valuations
python scripts/seed_data.py --environment dev --with-valuations
```

### Monitoring & Logs

| Comando | Descrizione | Esempio |
|---------|-------------|---------|
| `make logs` | Logs ultimi 10 minuti | `make logs` |
| `make watch` | Watch logs real-time | `make watch` |
| `make logs-function` | Logs funzione specifica | `make logs-function` |
| `make metrics` | Metriche CloudWatch | `make metrics` |

**Esempio watch logs**:
```bash
make watch
# [CreatePropertyFunction] 2024-01-15 10:30:15 Property created: 123
# [GetPropertyFunction] 2024-01-15 10:30:17 Cache HIT for key: property:123
# [ValuationFunction] 2024-01-15 10:30:20 Valuation completed in 1.2s
```

### AWS Operations

| Comando | Descrizione | Esempio |
|---------|-------------|---------|
| `make outputs` | Mostra outputs stack | `make outputs` |
| `make describe` | Descrivi stack | `make describe` |
| `make events` | Eventi recenti stack | `make events` |
| `make resources` | Lista risorse create | `make resources` |
| `make delete-stack` | Elimina stack (con conferma) | `make delete-stack` |

**Outputs utili**:
```bash
make outputs
# ApiUrl: https://abc123.execute-api.eu-west-1.amazonaws.com/prod
# UserPoolId: eu-west-1_ABC123XYZ
# PropertiesTableName: properties-dev
# EventBusName: property-valuation-dev-event-bus
```

### Cleanup

| Comando | Descrizione | Esempio |
|---------|-------------|---------|
| `make clean` | Pulisci file temporanei | `make clean` |
| `make clean-all` | Pulisci tutto incluso venv | `make clean-all` |

**Cosa rimuove `clean`**:
- `__pycache__/`
- `.pytest_cache/`
- `.mypy_cache/`
- `*.pyc`
- `.coverage`, `htmlcov/`
- `.aws-sam/`

### Utilities

| Comando | Descrizione | Esempio |
|---------|-------------|---------|
| `make check-env` | Verifica .env file | `make check-env` |
| `make check-aws` | Verifica credenziali AWS | `make check-aws` |
| `make version` | Versioni tools | `make version` |
| `make status` | Status progetto | `make status` |

### Workflow Completi

| Comando | Descrizione | Componenti |
|---------|-------------|------------|
| `make init` | Inizializza progetto | `setup` + `check-aws` |
| `make dev` | Ambiente sviluppo | `local-stack` + `local-api` |
| `make work` | Quick workflow | `format` + `test` |
| `make ready` | Pronto per commit | `quality` + `test-cov` + `build` |
| `make ci-test` | Pipeline CI | `install-dev` + `quality` + `test-cov` |
| `make pre-commit` | Pre-commit hook | `format` + `lint` + `test` |

## 🎯 Workflow Comuni

### 1. Primo Setup Progetto

```bash
# Clone repo
git clone <repo-url>
cd property-valuation-platform

# Setup completo
make init

# Configura .env
nano .env

# Test che tutto funzioni
make test
```

### 2. Daily Development

```bash
# Mattina: update e test
git pull
make install-dev
make test

# Sviluppo
make dev  # Avvia servizi locali

# Test modifiche
make work  # format + test

# Prima di commit
make ready
git add .
git commit -m "feat: ..."
```

### 3. Before Push/PR

```bash
# Full check
make ready
# quality → test-cov → build

# Se tutto OK
git push origin feature-branch
```

### 4. Deploy Workflow

```bash
# Dev (rapido, per test)
make deploy-dev

# Test manuale
curl https://API_URL/health

# Se OK, staging
make deploy-staging

# Se staging OK, production
make deploy-prod  # Con conferma
```

### 5. Troubleshooting

```bash
# Vedi logs
make watch

# Vedi eventi stack
make events

# Vedi risorse
make resources

# Verifica credenziali
make check-aws
```

### 6. Cleanup & Reset

```bash
# Pulisci solo temp files
make clean

# Reset completo
make clean-all
make setup
```

## 🔧 Customizzazione

### Variabili d'Ambiente

Puoi sovrascrivere le variabili:

```bash
# Region custom
REGION=us-east-1 make deploy

# Environment custom
ENVIRONMENT=qa make build

# Combinazione
ENVIRONMENT=staging REGION=eu-central-1 make deploy
```

### Aggiungi Nuovi Task

Modifica `Makefile`:

```makefile
##@ Custom Tasks

my-task: ## Descrizione task
	@echo "$(GREEN)Running my task...$(NC)"
	# comandi qui
```

Poi:
```bash
make my-task
```

## 📊 CI/CD Integration

### GitHub Actions

```yaml
# .github/workflows/ci.yml
- name: Run tests
  run: make ci-test

- name: Build
  run: make build

- name: Deploy
  run: make deploy-dev
```

### Pre-commit Hook

```bash
# .git/hooks/pre-commit
#!/bin/bash
make pre-commit
```

## 🐛 Troubleshooting

### Problema: `make: command not found`

**Soluzione Windows**:
Usa `Makefile.ps1` invece:
```powershell
.\Makefile.ps1 test
```

### Problema: `No rule to make target`

**Soluzione**:
Verifica nome task:
```bash
make help  # Vedi tutti i task disponibili
```

### Problema: Build fallisce

**Soluzione**:
```bash
# Pulisci e riprova
make clean
make build

# Se persiste, usa build locale
make build-local
```

### Problema: Test falliscono

**Soluzione**:
```bash
# Reinstalla deps
make clean-all
make setup

# Test singolarmente
make test-unit
make test-integration
```

## 📚 Risorse

- [GNU Make Manual](https://www.gnu.org/software/make/manual/)
- [AWS SAM CLI](https://docs.aws.amazon.com/serverless-application-model/latest/developerguide/serverless-sam-cli-command-reference.html)
- [Pytest Documentation](https://docs.pytest.org/)

## 💡 Tips & Tricks

1. **Auto-complete**: Aggiungi a `.bashrc`:
   ```bash
   complete -W "$(make -qp | awk -F':' '/^[a-zA-Z0-9][^$#\/\t=]*:([^=]|$)/ {split($1,A,/ /);for(i in A)print A[i]}')" make
   ```

2. **Alias utili**:
   ```bash
   alias mt="make test"
   alias md="make deploy-dev"
   alias ml="make logs"
   ```

3. **Help contestuale**:
   ```bash
   make help  # Sempre disponibile
   ```

4. **Dry run**:
   ```bash
   make -n build  # Mostra comandi senza eseguire
   ```
