# Deployment Guide

Questa guida descrive come deploy are la Property Valuation Platform in AWS usando AWS SAM.

---

## Prerequisiti

### Tools Richiesti

✅ **AWS CLI 2.15+**
```bash
aws --version
# aws-cli/2.15.0 Python/3.11.0 Windows/10 exe/AMD64
```

✅ **AWS SAM CLI 1.115+**
```bash
sam --version
# SAM CLI, version 1.115.0
```

✅ **Python 3.12+**
```bash
python --version
# Python 3.12.2
```

✅ **Docker Desktop** (per local testing)
```bash
docker --version
# Docker version 26.0.0
```

✅ **Git**
```bash
git --version
# git version 2.44.0
```

### Configurazione AWS

1. **Configura credenziali AWS**:
```bash
aws configure
# AWS Access Key ID: AKIA...
# AWS Secret Access Key: ***
# Default region name: eu-west-1
# Default output format: json
```

2. **Verifica accesso**:
```bash
aws sts get-caller-identity
```

3. **Permessi IAM richiesti**:
   - CloudFormation (full)
   - Lambda (full)
   - API Gateway (full)
   - DynamoDB (full)
   - S3 (full)
   - IAM (role creation)
   - Cognito (full)
   - EventBridge (full)
   - SQS/SNS (full)
   - CloudWatch Logs (full)
   - X-Ray (full)

---

## Quick Start Deployment

### 1. Clone Repository

```bash
git clone https://github.com/your-org/property-valuation-platform.git
cd property-valuation-platform
```

### 2. Install Dependencies

```bash
# Installa dipendenze Python
pip install -r requirements.txt
pip install -r requirements-dev.txt

# Crea Lambda layer (opzionale - SAM lo fa automaticamente)
mkdir -p .aws-sam/build/dependencies/python
pip install -r requirements.txt -t .aws-sam/build/dependencies/python
```

### 3. Build con SAM

```bash
sam build --use-container

# Output:
# Building codeuri: src/functions/api/create_property runtime: python3.12 architecture: arm64 functions: CreatePropertyFunction
# ...
# Build Succeeded
```

**Note**:
- `--use-container`: Usa Docker per build (garantisce compatibilità con Lambda)
- Architettura: `arm64` (Graviton2 - più performante e cost-effective)

### 4. Deploy (Development)

```bash
sam deploy --guided

# Segui il wizard:
# Stack Name [property-valuation-platform-dev]: 
# AWS Region [eu-west-1]:
# Parameter Environment [dev]:
# Parameter DomainPrefix [property-val-dev]:
# Confirm changes before deploy [Y/n]: Y
# Allow SAM CLI IAM role creation [Y/n]: Y
# Disable rollback [y/N]: N
# CreatePropertyFunction may not have authorization defined, Is this okay? [y/N]: y
# Save arguments to configuration file [Y/n]: Y
# SAM configuration file [samconfig.toml]:
# SAM configuration environment [default]:
```

**Deploy Process**:
1. SAM crea changeset CloudFormation
2. Mostra preview delle risorse
3. Richiede conferma
4. Esegue deploy (5-10 minuti)

### 5. Verifica Deploy

```bash
# Ottieni URL API Gateway
aws cloudformation describe-stacks \
  --stack-name property-valuation-platform-dev \
  --query 'Stacks[0].Outputs[?OutputKey==`ApiUrl`].OutputValue' \
  --output text

# Test health check
curl https://<api-id>.execute-api.eu-west-1.amazonaws.com/prod/health
```

---

## Ambienti

La piattaforma supporta 3 ambienti:

### Development (`dev`)
- **Purpose**: Testing e sviluppo
- **DynamoDB**: On-demand billing
- **API Gateway**: No caching
- **Lambda**: Tracing attivo, verbose logging
- **Retention**: 3 giorni CloudWatch Logs
- **Cost**: ~$50/mese

**Deploy**:
```bash
sam build && sam deploy --config-env dev
```

### Staging (`staging`)
- **Purpose**: Pre-produzione, QA
- **DynamoDB**: Provisioned (5 RCU/WCU con autoscaling)
- **API Gateway**: Caching attivo (0.5 GB)
- **Lambda**: Tracing attivo
- **Retention**: 7 giorni CloudWatch Logs
- **Cost**: ~$120/mese

**Deploy**:
```bash
sam build && sam deploy --config-env staging
```

### Production (`prod`)
- **Purpose**: Produzione
- **DynamoDB**: Provisioned (10 RCU/WCU con autoscaling) + PITR
- **API Gateway**: Caching attivo (1.6 GB)
- **Lambda**: Provisioned concurrency per funzioni critiche
- **ElastiCache**: t4g.micro con replica
- **Retention**: 30 giorni CloudWatch Logs
- **Backup**: Automatici
- **Cost**: ~$250/mese

**Deploy**:
```bash
sam build && sam deploy --config-env prod
```

---

## samconfig.toml

File di configurazione per ambienti multipli:

```toml
version = 0.1

[default.global.parameters]
stack_name = "property-valuation-platform-dev"

[default.build.parameters]
cached = true
parallel = true

[default.deploy.parameters]
capabilities = "CAPABILITY_IAM"
confirm_changeset = true
resolve_s3 = true
region = "eu-west-1"
image_repositories = []

parameter_overrides = "Environment=dev DomainPrefix=property-val-dev"

[dev]
[dev.deploy.parameters]
stack_name = "property-valuation-platform-dev"
parameter_overrides = "Environment=dev DomainPrefix=property-val-dev"

[staging]
[staging.deploy.parameters]
stack_name = "property-valuation-platform-staging"
parameter_overrides = "Environment=staging DomainPrefix=property-val-staging"
confirm_changeset = true

[prod]
[prod.deploy.parameters]
stack_name = "property-valuation-platform-prod"
parameter_overrides = "Environment=prod DomainPrefix=property-val-prod"
confirm_changeset = true
fail_on_empty_changeset = false
```

---

## CI/CD Pipeline (GitHub Actions)

### .github/workflows/deploy.yml

```yaml
name: Deploy to AWS

on:
  push:
    branches:
      - main
      - develop
  pull_request:
    branches:
      - main

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.12'
      
      - name: Install dependencies
        run: |
          pip install -r requirements.txt
          pip install -r requirements-dev.txt
      
      - name: Run tests
        run: |
          pytest tests/ -v --cov=src --cov-report=xml
      
      - name: Upload coverage
        uses: codecov/codecov-action@v4
        with:
          file: ./coverage.xml

  deploy-dev:
    needs: test
    if: github.ref == 'refs/heads/develop'
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Configure AWS credentials
        uses: aws-actions/configure-aws-credentials@v4
        with:
          aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID }}
          aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
          aws-region: eu-west-1
      
      - name: SAM Build
        run: sam build --use-container
      
      - name: SAM Deploy Dev
        run: |
          sam deploy \
            --config-env dev \
            --no-confirm-changeset \
            --no-fail-on-empty-changeset

  deploy-prod:
    needs: test
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    environment: production
    steps:
      - uses: actions/checkout@v4
      
      - name: Configure AWS credentials
        uses: aws-actions/configure-aws-credentials@v4
        with:
          aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID_PROD }}
          aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY_PROD }}
          aws-region: eu-west-1
      
      - name: SAM Build
        run: sam build --use-container
      
      - name: SAM Deploy Prod
        run: |
          sam deploy \
            --config-env prod \
            --no-confirm-changeset \
            --no-fail-on-empty-changeset
      
      - name: Run smoke tests
        run: |
          python scripts/smoke_test.py
```

---

## Database Migrations

### Creazione Tabelle DynamoDB

Le tabelle vengono create automaticamente da SAM template. Se serve creare manualmente:

```bash
aws dynamodb create-table \
  --table-name properties-dev \
  --attribute-definitions \
      AttributeName=PK,AttributeType=S \
      AttributeName=SK,AttributeType=S \
      AttributeName=GSI1PK,AttributeType=S \
      AttributeName=GSI1SK,AttributeType=S \
  --key-schema \
      AttributeName=PK,KeyType=HASH \
      AttributeName=SK,KeyType=RANGE \
  --global-secondary-indexes \
      '[
        {
          "IndexName": "GSI1",
          "KeySchema": [
            {"AttributeName": "GSI1PK", "KeyType": "HASH"},
            {"AttributeName": "GSI1SK", "KeyType": "RANGE"}
          ],
          "Projection": {"ProjectionType": "ALL"}
        }
      ]' \
  --billing-mode PAY_PER_REQUEST \
  --stream-specification StreamEnabled=true,StreamViewType=NEW_AND_OLD_IMAGES \
  --point-in-time-recovery-specification PointInTimeRecoveryEnabled=true \
  --sse-specification Enabled=true
```

### Seed Data

```bash
# Popola database con dati di esempio
python scripts/seed_data.py --environment dev --num-properties 100

# Output:
# Creating 100 sample properties...
# ✓ Created property: abc-123 (Milano)
# ✓ Created property: def-456 (Roma)
# ...
# ✓ Done! Created 100 properties in 12.3s
```

---

## Secrets Management

### AWS Secrets Manager

```bash
# Crea secret per RDS password
aws secretsmanager create-secret \
  --name property-valuation/dev/db-password \
  --description "RDS Aurora password for dev environment" \
  --secret-string "$(openssl rand -base64 32)"

# Recupera secret
aws secretsmanager get-secret-value \
  --secret-id property-valuation/dev/db-password \
  --query 'SecretString' \
  --output text
```

### Environment Variables

Non salvare mai secrets in variabili d'ambiente. Usa AWS Secrets Manager o Systems Manager Parameter Store.

```python
# ❌ WRONG
DB_PASSWORD = os.environ['DB_PASSWORD']

# ✅ CORRECT
import boto3
secretsmanager = boto3.client('secretsmanager')
secret = secretsmanager.get_secret_value(SecretId='property-valuation/dev/db-password')
DB_PASSWORD = secret['SecretString']
```

---

## Rollback

### Automatico (CloudFormation)

Se il deploy fallisce, CloudFormation fa rollback automaticamente.

```bash
# Disabilita rollback per debugging
sam deploy --no-fail-on-empty-changeset --disable-rollback
```

### Manuale (Previous Version)

```bash
# Lista versioni stack
aws cloudformation list-stacks --stack-status-filter UPDATE_COMPLETE

# Rollback a versione precedente
aws cloudformation update-stack \
  --stack-name property-valuation-platform-dev \
  --use-previous-template

# Oppure elimina changeset
aws cloudformation delete-change-set \
  --stack-name property-valuation-platform-dev \
  --change-set-name <changeset-name>
```

---

## Troubleshooting

### Deploy Fails

**Error**: `Resource handler returned message: "Invalid permissions on Lambda function"`

**Solution**:
```bash
# Verifica IAM roles
aws iam list-roles | grep property-valuation

# Verifica trust policy
aws iam get-role --role-name property-valuation-dev-CreatePropertyRole
```

---

**Error**: `Unable to upload artifact ... Access Denied`

**Solution**:
```bash
# SAM crea bucket automaticamente. Se serve creare manualmente:
aws s3 mb s3://property-valuation-sam-artifacts-dev --region eu-west-1
```

---

**Error**: `Rate exceeded` during deployment

**Solution**:
```bash
# Deploy con --capabilities per evitare prompt
sam deploy --capabilities CAPABILITY_IAM --no-confirm-changeset
```

---

### Lambda Function Errors

```bash
# Visualizza logs ultimi 10 minuti
sam logs -n CreatePropertyFunction --stack-name property-valuation-platform-dev --tail

# Oppure con AWS CLI
aws logs tail /aws/lambda/property-valuation-dev-CreatePropertyFunction --follow
```

---

### DynamoDB Throttling

```bash
# Verifica metriche
aws cloudwatch get-metric-statistics \
  --namespace AWS/DynamoDB \
  --metric-name UserErrors \
  --dimensions Name=TableName,Value=properties-dev \
  --start-time 2026-04-28T00:00:00Z \
  --end-time 2026-04-28T23:59:59Z \
  --period 3600 \
  --statistics Sum

# Aumenta capacity se necessario
aws dynamodb update-table \
  --table-name properties-dev \
  --provisioned-throughput ReadCapacityUnits=20,WriteCapacityUnits=20
```

---

## Post-Deployment Tasks

### 1. Setup Cognito User Pool

```bash
# Crea admin user
aws cognito-idp admin-create-user \
  --user-pool-id <user-pool-id> \
  --username admin@example.com \
  --user-attributes \
      Name=email,Value=admin@example.com \
      Name=email_verified,Value=true \
  --message-action SUPPRESS

# Set password
aws cognito-idp admin-set-user-password \
  --user-pool-id <user-pool-id> \
  --username admin@example.com \
  --password 'TempPassword123!' \
  --permanent
```

### 2. Setup CloudWatch Alarms

```bash
# Alarm per Lambda errors
aws cloudwatch put-metric-alarm \
  --alarm-name property-valuation-dev-lambda-errors \
  --alarm-description "Alert on Lambda errors" \
  --metric-name Errors \
  --namespace AWS/Lambda \
  --statistic Sum \
  --period 300 \
  --evaluation-periods 1 \
  --threshold 5 \
  --comparison-operator GreaterThanThreshold \
  --dimensions Name=FunctionName,Value=property-valuation-dev-CreateProperty
```

### 3. Enable X-Ray

Già abilitato in template.yaml. Verifica:

```bash
# Visualizza service map
aws xray get-service-graph \
  --start-time $(date -u -d '1 hour ago' +%s) \
  --end-time $(date -u +%s)
```

---

## Cost Optimization

### Pre-Deployment Estimate

```bash
# Usa AWS Pricing Calculator
# https://calculator.aws/#/

# Stima costi con template SAM
sam validate --lint
sam build --use-container
sam deploy --dry-run
```

### Post-Deployment Monitoring

```bash
# Visualizza costi per servizio (ultimi 7 giorni)
aws ce get-cost-and-usage \
  --time-period Start=2026-04-21,End=2026-04-28 \
  --granularity DAILY \
  --metrics "UnblendedCost" \
  --group-by Type=SERVICE
```

### Cost Alerts

```bash
# Setup budget alert
aws budgets create-budget \
  --account-id <account-id> \
  --budget file://budget.json \
  --notifications-with-subscribers file://notifications.json
```

---

## Cleanup

### Delete Stack

```bash
# Development
sam delete --stack-name property-valuation-platform-dev --no-prompts

# Staging
sam delete --stack-name property-valuation-platform-staging --no-prompts

# Production (richiede conferma)
sam delete --stack-name property-valuation-platform-prod
```

**Note**: Questo **non** elimina:
- S3 buckets (protetti da deletion)
- CloudWatch Log Groups (retention policy)
- DynamoDB backups

### Manual Cleanup

```bash
# Empty S3 buckets
aws s3 rm s3://property-valuation-dev-documents --recursive
aws s3 rb s3://property-valuation-dev-documents --force

# Delete log groups
aws logs delete-log-group --log-group-name /aws/lambda/property-valuation-dev-CreateProperty

# Delete DynamoDB backups
aws dynamodb delete-backup --backup-arn <backup-arn>
```

---

## Best Practices

✅ **Usa SAM**: Infrastructure as Code garantisce consistency  
✅ **Multi-account**: Dev/Staging/Prod in account AWS separati  
✅ **Least Privilege**: IAM roles con permessi minimi necessari  
✅ **Secrets**: AWS Secrets Manager, mai hardcoded  
✅ **Monitoring**: CloudWatch Alarms + X-Ray attivi  
✅ **Backup**: PITR su DynamoDB, automated backups su RDS  
✅ **CI/CD**: Automated testing prima di ogni deploy  
✅ **Cost**: Budget alerts configurati  

---

## Deployment Checklist

Prima del deploy in produzione:

- [ ] Tests passati (unit + integration)
- [ ] Security scan completato (Bandit, SAST)
- [ ] Performance testing eseguito
- [ ] Backup configurati
- [ ] Monitoring e alarms setup
- [ ] Secrets configurati in Secrets Manager
- [ ] Cognito User Pool configurato
- [ ] DNS/Custom domain configurato (opzionale)
- [ ] Documentation aggiornata
- [ ] Rollback plan definito
