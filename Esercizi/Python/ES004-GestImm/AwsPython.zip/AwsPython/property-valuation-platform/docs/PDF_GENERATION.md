# PDF Report Generation

Sistema completo di generazione PDF report per valutazioni immobiliari con ReportLab.

## 📋 Overview

Il sistema genera report PDF professionali con:
- ✅ **Header/Footer** personalizzati con branding
- ✅ **Sezioni dettagliate**: immobile, valutazione, comparabili, rischi
- ✅ **Tabelle formattate** con dati strutturati
- ✅ **Stili professionali** con colori e tipografia
- ✅ **Upload automatico** su S3 con presigned URL
- ✅ **Trigger multipli**: SQS, EventBridge, API diretta

## 🏗️ Architettura

```
┌─────────────────┐
│  Valuation      │
│  Completed      │──────┐
└─────────────────┘      │
                         ▼
                  ┌─────────────┐
                  │ EventBridge │
                  └─────────────┘
                         │
                         ├────────────────┐
                         ▼                ▼
              ┌──────────────────┐  ┌──────────┐
              │ GeneratePDF      │  │   SQS    │
              │ Lambda           │  │  Queue   │
              └──────────────────┘  └──────────┘
                         │                │
                         ▼                ▼
              ┌──────────────────┐  ┌──────────┐
              │  ReportLab       │  │  Batch   │
              │  PDF Generation  │  │  Process │
              └──────────────────┘  └──────────┘
                         │
                         ▼
              ┌──────────────────┐
              │  S3 Bucket       │
              │  /reports/...    │
              └──────────────────┘
                         │
                         ▼
              ┌──────────────────┐
              │  Presigned URL   │
              │  (7 days)        │
              └──────────────────┘
```

## 📂 Struttura File

```
src/
├── utils/
│   └── pdf_generator.py          # Utility generazione PDF con ReportLab
└── functions/
    └── async/
        └── generate_pdf_report.py # Lambda function

tests/
└── unit/
    ├── test_pdf_generator.py      # Test utility PDF
    └── test_lambda_generate_pdf.py # Test Lambda function

events/
├── valuation-completed-event.json # Event EventBridge
└── pdf-generation-request.json    # Request diretta
```

## 🚀 Usage

### 1. Trigger Automatico (EventBridge)

Quando viene completata una valutazione, EventBridge trigger automaticamente la generazione PDF:

```python
# In calculate_valuation.py
eventbridge.put_events(
    Entries=[{
        'Source': 'property-valuation',
        'DetailType': 'ValuationCompleted',
        'Detail': json.dumps({
            'property_id': property_id,
            'valuation_id': valuation_id,
            'estimated_value': float(valuation.estimated_value)
        })
    }]
)
# → PDF viene generato automaticamente
```

### 2. Trigger via SQS

Invia messaggio alla coda SQS per generazione asincrona:

```python
import boto3
import json

sqs = boto3.client('sqs')

sqs.send_message(
    QueueUrl='https://sqs.eu-west-1.amazonaws.com/.../pdf-generation-queue',
    MessageBody=json.dumps({
        'property_id': '123e4567-e89b-12d3-a456-426614174000',
        'valuation_id': '987fcdeb-51a2-43f7-8e9d-123456789abc',
        'include_risk': True
    })
)
```

### 3. Invocazione Diretta (API)

```bash
# Via Lambda invoke
aws lambda invoke \
  --function-name property-valuation-platform-dev-generate-pdf-report \
  --payload '{
    "property_id": "123e4567-e89b-12d3-a456-426614174000",
    "valuation_id": "987fcdeb-51a2-43f7-8e9d-123456789abc",
    "include_risk": true
  }' \
  response.json

# Response
{
  "statusCode": 200,
  "body": {
    "message": "PDF generato con successo",
    "data": {
      "s3_key": "reports/123.../987....pdf",
      "download_url": "https://s3.../presigned-url",
      "generation_time_seconds": 2.34
    }
  }
}
```

### 4. Test Locale

```bash
# Test con SAM local
sam local invoke GeneratePDFReportFunction \
  --event events/pdf-generation-request.json

# Test con pytest
pytest tests/unit/test_pdf_generator.py -v
pytest tests/unit/test_lambda_generate_pdf.py -v
```

## 📄 Contenuto Report PDF

Il PDF generato include:

### 1. **Header/Footer**
- Logo e branding
- Data generazione
- Numero pagina

### 2. **Sezione Titolo**
- Indirizzo immobile
- Data valutazione
- Metodologia usata
- Riferimento pratica
- **Valore stimato in evidenza**

### 3. **Dettagli Immobile**
Tabella con:
- Tipologia, superficie, locali, bagni
- Piano, anno costruzione
- Condizione, classe energetica
- Features (ascensore, parking, giardino, terrazzo)

### 4. **Valutazione**
Tabella con:
- Valore stimato, minimo, massimo
- Prezzo al mq
- Livello confidenza
- Metodologia

**Range grafico**:
- Spiegazione intervallo di valutazione
- Percentuale variazione

### 5. **Immobili Comparabili** (se disponibili)
Tabella fino a 5 immobili con:
- Indirizzo
- Superficie
- Prezzo/mq
- Valore totale

### 6. **Valutazione Rischi** (opzionale)
Se `include_risk=true`:
- Rischio sismico
- Rischio idrogeologico
- Rischio ambientale
- Score complessivo

### 7. **Note e Disclaimer**
- Metodologia valutazione
- Limitazioni
- Validità (6 mesi)
- Note confidenzialità

## 🎨 Personalizzazione

### Modifica Stili

Edita `src/utils/pdf_generator.py`:

```python
def _setup_custom_styles(self):
    # Cambia colore principale
    self.styles.add(ParagraphStyle(
        name='CustomTitle',
        textColor=colors.HexColor('#YOUR_COLOR'),  # ← Cambia qui
        fontSize=24,
        # ...
    ))
```

### Aggiungi Logo

```python
def _add_header_footer(self, canvas_obj, doc):
    # Aggiungi logo
    logo_path = "assets/logo.png"
    if os.path.exists(logo_path):
        canvas_obj.drawImage(
            logo_path,
            x=2*cm,
            y=self.page_height - 1.8*cm,
            width=3*cm,
            height=1.5*cm,
            preserveAspectRatio=True
        )
```

### Aggiungi Sezione Custom

```python
def _build_custom_section(self, data: Dict[str, Any]) -> List:
    """Nuova sezione personalizzata."""
    elements = []
    
    elements.append(Paragraph(
        "TITOLO SEZIONE",
        self.styles['SectionTitle']
    ))
    
    # Aggiungi contenuto...
    
    return elements

# In generate_valuation_report():
story.extend(self._build_custom_section(property_data))
```

## ⚙️ Configurazione

### Variabili d'Ambiente

```bash
# .env
DOCUMENTS_BUCKET=property-valuation-documents-dev
TABLE_NAME=properties-dev
AWS_REGION=eu-west-1
ENVIRONMENT=dev
```

### SAM Template

```yaml
GeneratePDFReportFunction:
  Type: AWS::Serverless::Function
  Properties:
    MemorySize: 3008  # Memoria alta per PDF generation
    Timeout: 120      # 2 minuti max
    Environment:
      Variables:
        DOCUMENTS_BUCKET: !Ref DocumentsBucket
```

## 📊 Performance

### Metriche Tipiche

| Metrica | Valore | Note |
|---------|--------|------|
| Generation Time | 1-3 sec | Dipende da complessità |
| File Size | 50-200 KB | Report standard |
| Memory Used | 200-500 MB | Su 3GB allocati |
| Cold Start | ~2 sec | Con Layer dependencies |

### Ottimizzazioni

1. **Lambda Layer**: Dependencies (ReportLab) in layer condiviso
2. **Memory**: 3008 MB per generazione veloce
3. **S3 Intelligent-Tiering**: Ottimizzazione costi storage
4. **Presigned URL**: 7 giorni validità, no auth necessaria

## 🧪 Testing

### Unit Test

```bash
# Test PDF generator
pytest tests/unit/test_pdf_generator.py -v

# Specifico
pytest tests/unit/test_pdf_generator.py::TestPDFGenerator::test_generate_complete_report -v
```

### Integration Test

```bash
# Test completo con mock AWS
pytest tests/unit/test_lambda_generate_pdf.py -v
```

### Test Manuale

```python
from src.utils.pdf_generator import get_pdf_generator

generator = get_pdf_generator()

pdf_buffer = generator.generate_valuation_report(
    property_data={...},
    valuation_data={...},
    risk_assessment={...}
)

# Salva per ispezione
with open('test_report.pdf', 'wb') as f:
    f.write(pdf_buffer.getvalue())
```

## 🔍 Monitoring

### CloudWatch Metrics

```bash
# PDF generati
aws cloudwatch get-metric-statistics \
  --namespace PropertyValuation \
  --metric-name PDFGenerated \
  --dimensions Name=FunctionName,Value=generate-pdf-report \
  --start-time 2024-01-01T00:00:00Z \
  --end-time 2024-01-31T23:59:59Z \
  --period 86400 \
  --statistics Sum

# Tempo generazione
--metric-name PDFGenerationTime
--statistics Average,Maximum
```

### Logs

```bash
# Watch logs
make watch

# Filtra errori PDF
sam logs --filter "PDF_GENERATION_ERROR" --stack-name property-valuation-platform-dev
```

## 📦 S3 Storage

### Struttura

```
documents-bucket/
└── reports/
    └── {property_id}/
        ├── {valuation_id_1}.pdf
        ├── {valuation_id_2}.pdf
        └── ...
```

### Lifecycle Policy

```yaml
LifecycleConfiguration:
  Rules:
    - Id: DeleteOldReports
      Status: Enabled
      ExpirationInDays: 365  # Cancella dopo 1 anno
      Transitions:
        - Days: 90
          StorageClass: GLACIER  # Archivio dopo 3 mesi
```

## 🚨 Error Handling

### Errori Comuni

| Errore | Causa | Soluzione |
|--------|-------|-----------|
| Property not found | ID inesistente | Verifica ID property |
| Valuation not found | ID valutazione errato | Check valuation_id |
| S3 upload failed | Permessi S3 | Verifica IAM policy |
| Memory exceeded | PDF troppo complesso | Aumenta memory |
| Timeout | Generation > 120s | Semplifica report |

### Retry Logic

SQS automaticamente fa retry su errore:
- Max receive: 3 volte
- DLQ dopo 3 fallimenti
- Visibility timeout: 120s

## 💰 Costi

### Stima Mensile (1000 PDF/mese)

| Servizio | Costo | Note |
|----------|-------|------|
| Lambda | ~$2 | 3GB, 2sec avg |
| S3 Storage | ~$1 | 100MB totali |
| S3 Requests | ~$0.01 | PUT/GET |
| **Totale** | **~$3/mese** | |

## 🔗 Risorse

- [ReportLab Docs](https://www.reportlab.com/docs/reportlab-userguide.pdf)
- [AWS Lambda Layers](https://docs.aws.amazon.com/lambda/latest/dg/configuration-layers.html)
- [S3 Presigned URLs](https://docs.aws.amazon.com/AmazonS3/latest/userguide/ShareObjectPreSignedURL.html)
