# Architecture Documentation

## Panoramica Architetturale

La Property Valuation Platform è una soluzione **100% serverless** costruita su AWS che fornisce servizi di valutazione immobiliare, analisi rischi, calcolo mutui e gestione anagrafica.

### Principi Architetturali

✅ **Serverless-First**: Zero gestione infrastruttura, auto-scaling automatico  
✅ **Event-Driven**: Processamento asincrono con EventBridge, SQS, SNS  
✅ **API-First**: REST API con OpenAPI 3.0 specification  
✅ **Security by Design**: JWT auth, RBAC, encryption everywhere  
✅ **Observable**: CloudWatch, X-Ray tracing, metriche custom  
✅ **Cost-Optimized**: Pay-per-use, caching aggressivo, retention policies  

---

## Diagramma C4 - Context Level

```
┌─────────────────────────────────────────────────────────────────┐
│                          CONTEXT DIAGRAM                          │
│                                                                   │
│  ┌──────────┐           ┌────────────────────────────┐          │
│  │   Web    │◄─────────►│  Property Valuation API    │          │
│  │   App    │   HTTPS   │   (API Gateway + Lambda)   │          │
│  └──────────┘           └────────────────────────────┘          │
│       │                              │                           │
│       │                              │                           │
│  ┌──────────┐                       │                           │
│  │  Mobile  │◄──────────────────────┘                           │
│  │   App    │          HTTPS                                    │
│  └──────────┘                                                    │
│                                                                   │
│  External Systems:                                               │
│  ┌────────────┐        ┌──────────────┐                        │
│  │   Banks    │◄──────►│  Email/SMS   │                        │
│  │  APIs      │        │  Service     │                        │
│  └────────────┘        └──────────────┘                        │
└─────────────────────────────────────────────────────────────────┘
```

---

## Diagramma C4 - Container Level

```
┌────────────────────────────────────────────────────────────────────┐
│                        CONTAINER DIAGRAM                             │
│                                                                      │
│   ┌─────────────────────────────────────────────────────────┐      │
│   │              API Gateway (REST API)                      │      │
│   │  - JWT Authentication                                    │      │
│   │  - Rate Limiting: 100 req/sec                           │      │
│   │  - Cache: 5min TTL                                      │      │
│   └──────────────┬──────────────────────────────────────────┘      │
│                  │                                                  │
│   ┌──────────────▼──────────────────────────────────────────┐      │
│   │           Lambda Functions (15+)                        │      │
│   │  ┌────────────────┐  ┌────────────────┐                │      │
│   │  │ API Handlers   │  │ Event Handlers │                │      │
│   │  │ - Create       │  │ - PropertyCreated │             │      │
│   │  │ - Get          │  │ - ValuationDone   │             │      │
│   │  │ - Update       │  └────────────────┘                │      │
│   │  │ - Valuation    │  ┌────────────────┐                │      │
│   │  │ - Mortgage     │  │ Background Jobs│                │      │
│   │  └────────────────┘  │ - PDF Gen      │                │      │
│   │                      │ - Notifications │                │      │
│   │                      └────────────────┘                │      │
│   └──────────┬────────────────┬─────────────────────────────┘      │
│              │                │                                     │
│   ┌──────────▼──────┐  ┌──────▼──────────┐  ┌──────────────┐     │
│   │   DynamoDB      │  │  EventBridge    │  │      S3      │     │
│   │ (Single Table)  │  │   Event Bus     │  │  Documents   │     │
│   │                 │  └─────┬───────────┘  │   & Reports  │     │
│   │ - Properties    │        │               └──────────────┘     │
│   │ - Valuations    │        │                                     │
│   │ - Risks         │  ┌─────▼─────┐  ┌──────────────┐           │
│   └─────────────────┘  │    SQS    │  │     SNS      │           │
│                        │  Queues   │  │   Topics     │           │
│                        │ - Notif   │  │ - Alerts     │           │
│                        │ - PDF     │  └──────────────┘           │
│   ┌─────────────────┐  └───────────┘                              │
│   │ ElastiCache    │                                               │
│   │    Redis       │   ┌──────────────┐                          │
│   │ - Hot data     │   │  CloudWatch  │                          │
│   │ - Sessions     │   │  + X-Ray     │                          │
│   └─────────────────┘   │  Monitoring  │                          │
│                         └──────────────┘                          │
└────────────────────────────────────────────────────────────────────┘
```

---

## Component Diagram - Lambda Functions

### API Functions (8)
| Function            | Endpoint                             | Description         | Timeout | Memory |
| ------------------- | ------------------------------------ | ------------------- | ------- | ------ |
| create-property     | POST /properties                     | Crea immobile       | 30s     | 1024MB |
| get-property        | GET /properties/{id}                 | Dettagli immobile   | 10s     | 1024MB |
| update-property     | PUT /properties/{id}                 | Aggiorna immobile   | 30s     | 1024MB |
| list-properties     | GET /properties                      | Lista con filtri    | 30s     | 1024MB |
| calculate-valuation | POST /properties/{id}/valuations     | Calcola valutazione | 60s     | 2048MB |
| get-risk-assessment | GET /properties/{id}/risk-assessment | Valuta rischi       | 30s     | 1024MB |
| calculate-mortgage  | POST /mortgages/calculate            | Simula mutuo        | 10s     | 1024MB |
| get-area-stats      | GET /areas/{id}/statistics           | Statistiche zona    | 30s     | 1024MB |

### Event Handlers (3)
- **property-created-handler**: Triggered by PropertyCreated event
- **valuation-completed-handler**: Triggered by ValuationCompleted event  
- **risk-changed-handler**: Triggered by RiskAssessmentChanged event

### Background Jobs (4)
- **generate-pdf-report**: Genera PDF valutazione (SQS trigger)
- **send-notification**: Invia email/SMS (SQS trigger)
- **cache-warmer**: Pre-carica cache hot data (CloudWatch Events)
- **data-archiver**: Archivia dati storici (CloudWatch Events)

---

## Event-Driven Flows

### Flow 1: PropertyCreated
```
┌──────────────┐      ┌────────────────┐      ┌──────────────────┐
│ POST         │─────►│ create-property│─────►│   DynamoDB       │
│ /properties  │      │    Lambda      │      │   Save Property  │
└──────────────┘      └────────┬───────┘      └──────────────────┘
                               │
                               │ Publish Event
                               │
                      ┌────────▼───────────┐
                      │    EventBridge     │
                      │  PropertyCreated   │
                      └────────┬───────────┘
                               │
              ┌────────────────┼────────────────┐
              │                │                │
     ┌────────▼───────┐  ┌────▼─────┐  ┌──────▼──────┐
     │Update Search   │  │  Send    │  │  Trigger    │
     │    Index       │  │  Notif   │  │  Valuation  │
     └────────────────┘  └──────────┘  └─────────────┘
```

### Flow 2: ValuationCompleted
```
┌──────────────────┐    ┌──────────────────┐    ┌────────────┐
│ POST valuations  │───►│calculate-valuation│───►│ DynamoDB  │
└──────────────────┘    │     Lambda        │    │   Save    │
                        └────────┬──────────┘    └───────────┘
                                 │
                                 │ Publish Event
                                 │
                        ┌────────▼────────────┐
                        │    EventBridge      │
                        │ ValuationCompleted  │
                        └────────┬────────────┘
                                 │
                    ┌────────────┼────────────┐
                    │            │            │
            ┌───────▼──────┐ ┌──▼─────┐ ┌────▼──────┐
            │Generate PDF  │ │ Email  │ │ Update    │
            │    (SQS)     │ │(SQS)   │ │  Cache    │
            └──────────────┘ └────────┘ └───────────┘
```

### Flow 3: RiskAssessmentChanged
```
┌──────────────────────┐    ┌──────────────┐
│  Risk Assessment     │───►│  EventBridge │
│  Update (External)   │    │   RiskChanged│
└──────────────────────┘    └──────┬───────┘
                                   │
                          ┌────────▼──────────┐
                          │ risk-changed      │
                          │   -handler        │
                          └────────┬──────────┘
                                   │
                    ┌──────────────┼──────────────┐
                    │              │              │
           ┌────────▼───┐  ┌───────▼────┐  ┌─────▼──────┐
           │ Recalculate│  │   Notify   │  │  Update    │
           │ Valuation  │  │Stakeholders│  │  Property  │
           └────────────┘  └────────────┘  └────────────┘
```

---

## Database Design

### DynamoDB Single-Table Design

**Table**: `properties-{environment}`

#### Access Patterns

| #   | Access Pattern              | Keys Used                                   | Index |
| --- | --------------------------- | ------------------------------------------- | ----- |
| 1   | Get property by ID          | PK=PROPERTY#{id}, SK=METADATA               | Main  |
| 2   | Get valuations for property | PK=PROPERTY#{id}, SK begins_with VALUATION# | Main  |
| 3   | Get risks for property      | PK=PROPERTY#{id}, SK begins_with RISK#      | Main  |
| 4   | Query properties by city    | GSI1PK=CITY#{city}                          | GSI1  |
| 5   | Query properties by type    | GSI2PK=TYPE#{type}                          | GSI2  |

#### Item Structure Examples

**Property Item**:
```json
{
  "PK": "PROPERTY#abc-123",
  "SK": "METADATA",
  "EntityType": "Property",
  "PropertyId": "abc-123",
  "Address": {...},
  "PropertyType": "apartment",
  "SurfaceSqm": 85.5,
  "GSI1PK": "CITY#Milano",
  "GSI1SK": "TYPE#apartment#abc-123",
  "GSI2PK": "TYPE#apartment",
  "GSI2SK": "PRICE#85.5",
  "CreatedAt": "2026-04-28T10:00:00Z",
  "UpdatedAt": "2026-04-28T10:00:00Z"
}
```

**Valuation Item**:
```json
{
  "PK": "PROPERTY#abc-123",
  "SK": "VALUATION#2026-04-28T10:30:00Z",
  "EntityType": "Valuation",
  "ValuationId": "val-456",
  "EstimatedValue": 250000,
  "PricePerSqm": 2923,
  "Methodology": "comparative",
  "ConfidenceLevel": 0.85
}
```

---

## Caching Strategy

### Layer 1: API Gateway Cache
- **TTL**: 5 minuti
- **Size**: 0.5 GB
- **Endpoints cachati**: GET /properties/{id}, GET /areas/{id}/statistics
- **Cache keys**: Include query params

### Layer 2: ElastiCache Redis
- **Purpose**: Hot data, session management
- **TTL Strategy**:
  - Calcoli mutuo: 5 minuti
  - Anagrafica immobili: 1 ora  
  - Statistiche zona: 24 ore
- **Pattern**: Cache-aside
- **Eviction**: LRU (Least Recently Used)

### Layer 3: DynamoDB (optional DAX)
- **Purpose**: Accelerare query frequenti
- **Use case**: Anagrafica immobili ad alto traffico
- **Configuration**: Solo se > 1000 req/sec sustained

---

## Security Architecture

### Authentication Flow
```
User ──► Cognito User Pool ──► JWT Token ──► API Gateway
                                              │
                                              ▼
                                       Lambda (verified)
```

### Authorization (RBAC)
- **admin**: Full access
- **valutatore**: Create/update properties, run valuations
- **viewer**: Read-only access

### Encryption
- **At Rest**: 
  - DynamoDB: SSE enabled
  - S3: AES-256
  - RDS: Storage encryption
- **In Transit**: TLS 1.2+ only

### Secrets Management
- **AWS Secrets Manager**: DB passwords, API keys
- **No hardcoded secrets** in code/env vars

---

## Monitoring & Observability

### CloudWatch Metrics
**Business Metrics**:
- ValuationsCompleted/Hour
- AverageValuationTime
- MortgageCalculations/Day

**Technical Metrics**:
- Lambda duration (p50, p95, p99)
- Lambda errors & throttles
- API Gateway 4xx/5xx
- DynamoDB throttled requests
- Cache hit ratio

### X-Ray Tracing
- End-to-end request tracing
- Service map visualization
- Latency analysis per component

### CloudWatch Alarms
- API Gateway 5xx > 1%
- Lambda errors > 5
- DynamoDB throttles > 10
- SQS queue depth > 1000

---

## Disaster Recovery

### Backup Strategy
- **DynamoDB**: Point-in-Time Recovery (35 days)
- **RDS Aurora**: Automated backups (7 days)
- **S3**: Versioning enabled

### RTO/RPO
- **RTO** (Recovery Time Objective): < 1 hour
- **RPO** (Recovery Point Objective): < 5 minutes

### Multi-Region (Future)
- DynamoDB Global Tables
- Aurora Global Database
- CloudFront CDN for global edge caching

---

## Architecture Decision Records (ADRs)

### ADR-001: Single-Table Design for DynamoDB
**Context**: Need flexible data model with multiple access patterns  
**Decision**: Use single-table design with PK/SK pattern + GSIs  
**Consequences**: 
- ✅ Reduced costs (1 table vs many)
- ✅ Better performance (no joins)
- ❌ More complex query patterns
- ❌ Harder to visualize data

### ADR-002: AWS Lambda Powertools
**Context**: Need standardized logging, metrics, tracing  
**Decision**: Use AWS Lambda Powertools for Python  
**Consequences**:
- ✅ Best practices out-of-the-box
- ✅ Reduced boilerplate code
- ✅ Better observability
- ❌ Additional dependency

### ADR-003: EventBridge over Direct SQS
**Context**: Need event routing and filtering  
**Decision**: Use EventBridge as event bus, SQS for queuing  
**Consequences**:
- ✅ Better decoupling
- ✅ Easy to add consumers
- ✅ Built-in filtering
- ❌ Slightly higher latency

---

## Performance Targets

| Metric                  | Target  | Measured      |
| ----------------------- | ------- | ------------- |
| API Response Time (p95) | < 200ms | CloudWatch    |
| Lambda Cold Start (p95) | < 3s    | X-Ray         |
| Cache Hit Ratio         | > 70%   | CloudWatch    |
| Valuation Calculation   | < 2s    | Custom Metric |
| PDF Generation          | < 30s   | Custom Metric |

---

## Cost Optimization

**Monthly Cost Estimate (1000 users, 10k req/day)**:

| Service     | Monthly Cost    | Optimization                    |
| ----------- | --------------- | ------------------------------- |
| Lambda      | $50             | 1024MB memory, ARM architecture |
| API Gateway | $35             | Caching enabled                 |
| DynamoDB    | $40             | On-demand billing               |
| S3          | $10             | Intelligent-Tiering             |
| ElastiCache | $30             | t4g.micro node                  |
| CloudWatch  | $15             | 7-day retention                 |
| **Total**   | **~$180/month** |                                 |

**Cost per valuation**: ~$0.02
