#!/usr/bin/env python3
"""
Script per popolamento database con dati di esempio.

Usage:
    python scripts/seed_data.py --environment dev --num-properties 100
"""

import argparse
import json
import random
import sys
from datetime import datetime, timedelta
from decimal import Decimal
from uuid import uuid4

import boto3
from faker import Faker

# Setup faker
fake = Faker('it_IT')


def get_table_name(environment: str) -> str:
    """Ottiene nome tabella DynamoDB per environment"""
    return f"properties-{environment}"


def generate_property():
    """Genera dati immobile casuali"""
    property_types = ["apartment", "house", "villa", "office", "commercial", "warehouse"]
    conditions = ["new", "excellent", "good", "fair", "poor", "to_renovate"]
    energy_classes = ["A+", "A", "B", "C", "D", "E", "F", "G"]
    
    city = random.choice([
        "Milano", "Roma", "Firenze", "Torino", "Bologna",
        "Napoli", "Venezia", "Genova", "Verona", "Palermo"
    ])
    
    property_type = random.choice(property_types)
    
    property_data = {
        "PK": f"PROPERTY#{uuid4()}",
        "SK": "METADATA",
        "EntityType": "Property",
        "PropertyId": str(uuid4()),
        "Address": {
            "street": fake.street_address(),
            "city": city,
            "province": city[:2].upper(),
            "postal_code": fake.postcode(),
            "country": "Italia",
            "coordinates": {
                "latitude": float(fake.latitude()),
                "longitude": float(fake.longitude())
            }
        },
        "PropertyType": property_type,
        "SurfaceSqm": Decimal(str(random.randint(40, 300))),
        "ConstructionYear": random.randint(1950, 2024),
        "Condition": random.choice(conditions),
        "Rooms": random.randint(1, 6),
        "Bathrooms": random.randint(1, 3),
        "Floor": random.randint(0, 10) if property_type == "apartment" else None,
        "HasElevator": random.choice([True, False]),
        "HasParking": random.choice([True, False]),
        "HasGarden": property_type in ["house", "villa"] and random.choice([True, False]),
        "HasTerrace": random.choice([True, False]),
        "EnergyClass": random.choice(energy_classes),
        "HeatingType": random.choice(["autonomous", "centralized", "heat_pump"]),
        "GSI1PK": f"CITY#{city}",
        "GSI1SK": f"TYPE#{property_type}#{uuid4()}",
        "GSI2PK": f"TYPE#{property_type}",
        "GSI2SK": f"SURFACE#{random.randint(40, 300)}",
        "CreatedAt": datetime.utcnow().isoformat(),
        "UpdatedAt": datetime.utcnow().isoformat(),
        "IsDeleted": False
    }
    
    return property_data


def seed_properties(table_name: str, num_properties: int):
    """
    Popola tabella con immobili di esempio.
    
    Args:
        table_name: Nome tabella DynamoDB
        num_properties: Numero di immobili da creare
    """
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(table_name)
    
    print(f"📝 Creating {num_properties} sample properties in table '{table_name}'...")
    
    created_count = 0
    
    for i in range(num_properties):
        try:
            property_data = generate_property()
            
            # Salva in DynamoDB
            table.put_item(Item=property_data)
            
            created_count += 1
            
            if (i + 1) % 10 == 0:
                print(f"   ✓ Created {i + 1}/{num_properties} properties...")
            
        except Exception as e:
            print(f"   ✗ Error creating property {i + 1}: {e}")
            continue
    
    print(f"\n✅ Done! Created {created_count}/{num_properties} properties successfully.")
    
    return created_count


def seed_valuations(table_name: str, num_valuations: int = 50):
    """
    Popola tabella con valutazioni di esempio.
    
    Args:
        table_name: Nome tabella DynamoDB
        num_valuations: Numero di valutazioni da creare
    """
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(table_name)
    
    print(f"\n📊 Creating {num_valuations} sample valuations...")
    
    # Recupera alcuni property IDs esistenti
    response = table.scan(
        FilterExpression='EntityType = :type',
        ExpressionAttributeValues={':type': 'Property'},
        Limit=20
    )
    
    properties = response.get('Items', [])
    
    if not properties:
        print("⚠️  No properties found. Skipping valuations.")
        return 0
    
    created_count = 0
    
    for i in range(min(num_valuations, len(properties) * 3)):
        try:
            property_item = random.choice(properties)
            property_id = property_item['PropertyId']
            
            estimated_value = Decimal(str(random.randint(100000, 1000000)))
            
            valuation_data = {
                "PK": f"PROPERTY#{property_id}",
                "SK": f"VALUATION#{datetime.utcnow().isoformat()}",
                "EntityType": "Valuation",
                "ValuationId": str(uuid4()),
                "PropertyId": property_id,
                "EstimatedValue": estimated_value,
                "MinValue": (estimated_value * Decimal('0.9')).quantize(Decimal('0.01')),
                "MaxValue": (estimated_value * Decimal('1.1')).quantize(Decimal('0.01')),
                "PricePerSqm": Decimal(str(random.randint(1500, 5000))),
                "Methodology": "comparative",
                "ConfidenceLevel": Decimal(str(random.uniform(0.7, 0.95))),
                "ValuationDate": datetime.utcnow().isoformat(),
                "ValidUntil": (datetime.utcnow() + timedelta(days=90)).isoformat()
            }
            
            table.put_item(Item=valuation_data)
            created_count += 1
            
        except Exception as e:
            print(f"   ✗ Error creating valuation {i + 1}: {e}")
            continue
    
    print(f"✅ Created {created_count} valuations.")
    return created_count


def main():
    parser = argparse.ArgumentParser(description='Seed DynamoDB with sample data')
    parser.add_argument(
        '--environment',
        '-e',
        required=True,
        choices=['dev', 'staging', 'prod'],
        help='Environment (dev, staging, prod)'
    )
    parser.add_argument(
        '--num-properties',
        '-n',
        type=int,
        default=100,
        help='Number of properties to create (default: 100)'
    )
    parser.add_argument(
        '--with-valuations',
        action='store_true',
        help='Also create sample valuations'
    )
    
    args = parser.parse_args()
    
    # Conferma per production
    if args.environment == 'prod':
        response = input("⚠️  WARNING: You are seeding PRODUCTION database. Continue? [y/N]: ")
        if response.lower() != 'y':
            print("Aborted.")
            sys.exit(0)
    
    table_name = get_table_name(args.environment)
    
    print(f"\n🚀 Starting seed process...")
    print(f"   Environment: {args.environment}")
    print(f"   Table: {table_name}")
    print(f"   Properties: {args.num_properties}\n")
    
    try:
        # Seed properties
        properties_created = seed_properties(table_name, args.num_properties)
        
        # Seed valuations se richiesto
        if args.with_valuations:
            valuations_created = seed_valuations(table_name)
        
        print(f"\n🎉 Seed completed successfully!")
        
    except Exception as e:
        print(f"\n❌ Error during seed: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
