#!/bin/bash
# Script di deployment automatizzato per Property Valuation Platform

set -e  # Exit on error

# Colori per output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Funzione per logging
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Parsing argomenti
ENVIRONMENT=${1:-dev}
STACK_NAME="property-valuation-platform-${ENVIRONMENT}"
REGION=${AWS_REGION:-eu-west-1}

if [[ ! "$ENVIRONMENT" =~ ^(dev|staging|prod)$ ]]; then
    log_error "Environment must be one of: dev, staging, prod"
    echo "Usage: $0 <environment> [options]"
    exit 1
fi

log_info "Starting deployment to ${ENVIRONMENT} environment..."
log_info "Stack: ${STACK_NAME}"
log_info "Region: ${REGION}"

# Verifica prerequisiti
log_info "Checking prerequisites..."

# AWS CLI
if ! command -v aws &> /dev/null; then
    log_error "AWS CLI not found. Please install it."
    exit 1
fi

# SAM CLI
if ! command -v sam &> /dev/null; then
    log_error "SAM CLI not found. Please install it."
    exit 1
fi

# Python
if ! command -v python3 &> /dev/null; then
    log_error "Python 3 not found."
    exit 1
fi

log_info "✓ All prerequisites met"

# Verifica credenziali AWS
log_info "Verifying AWS credentials..."
if ! aws sts get-caller-identity &> /dev/null; then
    log_error "AWS credentials not configured. Run 'aws configure'"
    exit 1
fi

AWS_ACCOUNT=$(aws sts get-caller-identity --query Account --output text)
log_info "✓ Authenticated as account: ${AWS_ACCOUNT}"

# Conferma per production
if [ "$ENVIRONMENT" == "prod" ]; then
    log_warning "⚠️  DEPLOYING TO PRODUCTION ⚠️"
    read -p "Are you sure you want to deploy to PRODUCTION? [y/N] " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        log_info "Deployment cancelled."
        exit 0
    fi
fi

# Run tests
log_info "Running tests..."
if [ "$ENVIRONMENT" == "prod" ] || [ "$ENVIRONMENT" == "staging" ]; then
    python3 -m pytest tests/ -v --cov=src --cov-report=term-missing
    
    if [ $? -ne 0 ]; then
        log_error "Tests failed. Deployment aborted."
        exit 1
    fi
    log_info "✓ All tests passed"
else
    log_warning "Skipping tests for dev environment"
fi

# Security scan
log_info "Running security scan..."
if command -v bandit &> /dev/null; then
    bandit -r src/ -ll || log_warning "Security issues found (non-blocking)"
else
    log_warning "Bandit not installed. Skipping security scan."
fi

# Linting
log_info "Running linters..."
if command -v pylint &> /dev/null; then
    pylint src/ --fail-under=7.0 || log_warning "Linting issues found (non-blocking)"
else
    log_warning "Pylint not installed. Skipping linting."
fi

# SAM Build
log_info "Building SAM application..."
sam build --use-container --cached --parallel

if [ $? -ne 0 ]; then
    log_error "SAM build failed"
    exit 1
fi

log_info "✓ Build completed"

# SAM Validate
log_info "Validating SAM template..."
sam validate --lint

if [ $? -ne 0 ]; then
    log_error "Template validation failed"
    exit 1
fi

log_info "✓ Template validated"

# SAM Deploy
log_info "Deploying to AWS..."

if [ "$ENVIRONMENT" == "prod" ]; then
    # Production: con conferma changeset
    sam deploy \
        --config-env ${ENVIRONMENT} \
        --stack-name ${STACK_NAME} \
        --region ${REGION} \
        --capabilities CAPABILITY_IAM \
        --confirm-changeset
else
    # Dev/Staging: senza conferma
    sam deploy \
        --config-env ${ENVIRONMENT} \
        --stack-name ${STACK_NAME} \
        --region ${REGION} \
        --capabilities CAPABILITY_IAM \
        --no-confirm-changeset \
        --no-fail-on-empty-changeset
fi

if [ $? -ne 0 ]; then
    log_error "Deployment failed"
    exit 1
fi

log_info "✓ Deployment completed"

# Recupera outputs
log_info "Retrieving stack outputs..."

API_URL=$(aws cloudformation describe-stacks \
    --stack-name ${STACK_NAME} \
    --region ${REGION} \
    --query 'Stacks[0].Outputs[?OutputKey==`ApiUrl`].OutputValue' \
    --output text)

USER_POOL_ID=$(aws cloudformation describe-stacks \
    --stack-name ${STACK_NAME} \
    --region ${REGION} \
    --query 'Stacks[0].Outputs[?OutputKey==`UserPoolId`].OutputValue' \
    --output text)

echo ""
log_info "================================"
log_info "Deployment Summary"
log_info "================================"
echo "Environment:   ${ENVIRONMENT}"
echo "Stack Name:    ${STACK_NAME}"
echo "Region:        ${REGION}"
echo "API URL:       ${API_URL}"
echo "User Pool ID:  ${USER_POOL_ID}"
log_info "================================"

# Health check
if [ -n "$API_URL" ]; then
    log_info "Running health check..."
    
    sleep 5  # Attendi che API sia pronta
    
    HEALTH_STATUS=$(curl -s -o /dev/null -w "%{http_code}" ${API_URL}/health || echo "000")
    
    if [ "$HEALTH_STATUS" == "200" ]; then
        log_info "✓ Health check passed"
    else
        log_warning "Health check failed (HTTP ${HEALTH_STATUS})"
    fi
fi

# Post-deployment tasks
if [ "$ENVIRONMENT" == "prod" ]; then
    log_info "Running post-deployment tasks..."
    
    # Tag resources
    aws cloudformation update-stack \
        --stack-name ${STACK_NAME} \
        --region ${REGION} \
        --use-previous-template \
        --tags \
            Key=Environment,Value=${ENVIRONMENT} \
            Key=ManagedBy,Value=SAM \
            Key=DeployedBy,Value=$(whoami) \
            Key=DeployedAt,Value=$(date -u +"%Y-%m-%dT%H:%M:%SZ") \
        --capabilities CAPABILITY_IAM \
        || log_warning "Failed to update tags"
fi

echo ""
log_info "🎉 Deployment completed successfully!"
log_info "Next steps:"
echo "  1. Test API: curl ${API_URL}/health"
echo "  2. View logs: sam logs -t --stack-name ${STACK_NAME}"
echo "  3. Monitor: aws cloudwatch get-dashboard --dashboard-name ${STACK_NAME}"
echo ""
