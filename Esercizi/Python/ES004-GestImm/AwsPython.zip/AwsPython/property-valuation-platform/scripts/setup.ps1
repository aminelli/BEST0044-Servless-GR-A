# Property Valuation Platform - Windows Setup Script

Write-Host "================================" -ForegroundColor Green
Write-Host "Property Valuation Platform" -ForegroundColor Green
Write-Host "Local Development Setup" -ForegroundColor Green
Write-Host "================================" -ForegroundColor Green
Write-Host ""

# 1. Check prerequisites
Write-Host "[1/6] Checking prerequisites..." -ForegroundColor Yellow

# Python
if (Get-Command python -ErrorAction SilentlyContinue) {
    $pythonVersion = python --version
    Write-Host "✓ $pythonVersion" -ForegroundColor Green
} else {
    Write-Host "✗ Python not found. Please install Python 3.12+" -ForegroundColor Red
    exit 1
}

# AWS CLI
if (Get-Command aws -ErrorAction SilentlyContinue) {
    $awsVersion = aws --version
    Write-Host "✓ AWS CLI installed" -ForegroundColor Green
} else {
    Write-Host "✗ AWS CLI not found. Please install it." -ForegroundColor Red
    exit 1
}

# SAM CLI
if (Get-Command sam -ErrorAction SilentlyContinue) {
    Write-Host "✓ SAM CLI installed" -ForegroundColor Green
} else {
    Write-Host "✗ SAM CLI not found. Please install it." -ForegroundColor Red
    exit 1
}

Write-Host ""

# 2. Create virtual environment
Write-Host "[2/6] Setting up Python virtual environment..." -ForegroundColor Yellow

if (-not (Test-Path "venv")) {
    python -m venv venv
    Write-Host "✓ Virtual environment created" -ForegroundColor Green
} else {
    Write-Host "⚠ Virtual environment already exists" -ForegroundColor Yellow
}

# Activate venv
& .\venv\Scripts\Activate.ps1

Write-Host ""

# 3. Install dependencies
Write-Host "[3/6] Installing Python dependencies..." -ForegroundColor Yellow

python -m pip install --upgrade pip | Out-Null
pip install -r requirements.txt | Out-Null
pip install -r requirements-dev.txt | Out-Null

Write-Host "✓ Dependencies installed" -ForegroundColor Green
Write-Host ""

# 4. Setup environment file
Write-Host "[4/6] Configuring environment variables..." -ForegroundColor Yellow

if (-not (Test-Path ".env")) {
    Copy-Item .env.example .env
    Write-Host "✓ Created .env file from template" -ForegroundColor Green
    Write-Host "⚠ Please edit .env and configure your AWS credentials" -ForegroundColor Yellow
} else {
    Write-Host "⚠ .env file already exists (skipping)" -ForegroundColor Yellow
}

Write-Host ""

# 5. Setup pre-commit hooks (optional)
Write-Host "[5/6] Setting up pre-commit hooks..." -ForegroundColor Yellow

if (Get-Command pre-commit -ErrorAction SilentlyContinue) {
    pre-commit install | Out-Null
    Write-Host "✓ Pre-commit hooks installed" -ForegroundColor Green
} else {
    Write-Host "⚠ pre-commit not found (optional - install with: pip install pre-commit)" -ForegroundColor Yellow
}

Write-Host ""

# 6. Verify AWS credentials
Write-Host "[6/6] Verifying AWS credentials..." -ForegroundColor Yellow

try {
    $account = aws sts get-caller-identity --query Account --output text 2>$null
    if ($account) {
        Write-Host "✓ AWS credentials configured (Account: $account)" -ForegroundColor Green
    } else {
        Write-Host "✗ AWS credentials not configured" -ForegroundColor Red
        Write-Host "Run: aws configure" -ForegroundColor Yellow
    }
} catch {
    Write-Host "✗ AWS credentials not configured" -ForegroundColor Red
    Write-Host "Run: aws configure" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "================================" -ForegroundColor Green
Write-Host "Setup Complete!" -ForegroundColor Green
Write-Host "================================" -ForegroundColor Green
Write-Host ""
Write-Host "Next steps:"
Write-Host ""
Write-Host "1. Edit .env file with your configuration:"
Write-Host "   notepad .env" -ForegroundColor Yellow
Write-Host ""
Write-Host "2. Start DynamoDB Local (optional):"
Write-Host "   docker run -p 8000:8000 amazon/dynamodb-local" -ForegroundColor Yellow
Write-Host ""
Write-Host "3. Start Redis (optional):"
Write-Host "   docker run -p 6379:6379 redis:7-alpine" -ForegroundColor Yellow
Write-Host ""
Write-Host "4. Run tests:"
Write-Host "   pytest tests/ -v" -ForegroundColor Yellow
Write-Host ""
Write-Host "5. Start local API:"
Write-Host "   sam build" -ForegroundColor Yellow
Write-Host "   sam local start-api --port 3000" -ForegroundColor Yellow
Write-Host ""
Write-Host "6. Deploy to AWS (dev):"
Write-Host "   .\scripts\deploy.sh dev" -ForegroundColor Yellow
Write-Host ""
Write-Host "Happy coding! 🚀" -ForegroundColor Green
Write-Host ""
