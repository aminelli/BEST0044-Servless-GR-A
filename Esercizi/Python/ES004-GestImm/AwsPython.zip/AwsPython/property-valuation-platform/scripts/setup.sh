#!/bin/bash
# Setup script for Property Valuation Platform local development

set -e

# Colori
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${GREEN}================================${NC}"
echo -e "${GREEN}Property Valuation Platform${NC}"
echo -e "${GREEN}Local Development Setup${NC}"
echo -e "${GREEN}================================${NC}"
echo ""

# 1. Check prerequisites
echo -e "${YELLOW}[1/6]${NC} Checking prerequisites..."

if ! command -v python3 &> /dev/null; then
    echo -e "${RED}✗ Python 3 not found. Please install Python 3.12+${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Python $(python3 --version)${NC}"

if ! command -v aws &> /dev/null; then
    echo -e "${RED}✗ AWS CLI not found. Please install it.${NC}"
    exit 1
fi
echo -e "${GREEN}✓ AWS CLI $(aws --version)${NC}"

if ! command -v sam &> /dev/null; then
    echo -e "${RED}✗ SAM CLI not found. Please install it.${NC}"
    exit 1
fi
echo -e "${GREEN}✓ SAM CLI installed${NC}"

echo ""

# 2. Create virtual environment
echo -e "${YELLOW}[2/6]${NC} Setting up Python virtual environment..."

if [ ! -d "venv" ]; then
    python3 -m venv venv
    echo -e "${GREEN}✓ Virtual environment created${NC}"
else
    echo -e "${YELLOW}⚠ Virtual environment already exists${NC}"
fi

# Activate venv
source venv/bin/activate 2>/dev/null || source venv/Scripts/activate 2>/dev/null || {
    echo -e "${RED}✗ Failed to activate virtual environment${NC}"
    exit 1
}

echo ""

# 3. Install dependencies
echo -e "${YELLOW}[3/6]${NC} Installing Python dependencies..."

pip install --upgrade pip > /dev/null
pip install -r requirements.txt > /dev/null
pip install -r requirements-dev.txt > /dev/null

echo -e "${GREEN}✓ Dependencies installed${NC}"
echo ""

# 4. Setup environment file
echo -e "${YELLOW}[4/6]${NC} Configuring environment variables..."

if [ ! -f ".env" ]; then
    cp .env.example .env
    echo -e "${GREEN}✓ Created .env file from template${NC}"
    echo -e "${YELLOW}⚠ Please edit .env and configure your AWS credentials${NC}"
else
    echo -e "${YELLOW}⚠ .env file already exists (skipping)${NC}"
fi

echo ""

# 5. Setup pre-commit hooks (optional)
echo -e "${YELLOW}[5/6]${NC} Setting up pre-commit hooks..."

if command -v pre-commit &> /dev/null; then
    pre-commit install > /dev/null 2>&1
    echo -e "${GREEN}✓ Pre-commit hooks installed${NC}"
else
    echo -e "${YELLOW}⚠ pre-commit not found (optional - install with: pip install pre-commit)${NC}"
fi

echo ""

# 6. Verify AWS credentials
echo -e "${YELLOW}[6/6]${NC} Verifying AWS credentials..."

if aws sts get-caller-identity > /dev/null 2>&1; then
    ACCOUNT=$(aws sts get-caller-identity --query Account --output text)
    echo -e "${GREEN}✓ AWS credentials configured (Account: ${ACCOUNT})${NC}"
else
    echo -e "${RED}✗ AWS credentials not configured${NC}"
    echo -e "${YELLOW}Run: aws configure${NC}"
fi

echo ""
echo -e "${GREEN}================================${NC}"
echo -e "${GREEN}Setup Complete!${NC}"
echo -e "${GREEN}================================${NC}"
echo ""
echo "Next steps:"
echo ""
echo "1. Edit .env file with your configuration:"
echo "   ${YELLOW}nano .env${NC}"
echo ""
echo "2. Start DynamoDB Local (optional):"
echo "   ${YELLOW}docker run -p 8000:8000 amazon/dynamodb-local${NC}"
echo ""
echo "3. Start Redis (optional):"
echo "   ${YELLOW}docker run -p 6379:6379 redis:7-alpine${NC}"
echo ""
echo "4. Run tests:"
echo "   ${YELLOW}pytest tests/ -v${NC}"
echo ""
echo "5. Start local API:"
echo "   ${YELLOW}sam build && sam local start-api --port 3000${NC}"
echo ""
echo "6. Deploy to AWS (dev):"
echo "   ${YELLOW}./scripts/deploy.sh dev${NC}"
echo ""
echo -e "${GREEN}Happy coding! 🚀${NC}"
echo ""
