"""
Integration tests for complete API flows.
"""
import json
import pytest
from uuid import uuid4

from src.functions.api.create_property import lambda_handler as create_handler
from src.functions.api.get_property import lambda_handler as get_handler
from src.functions.api.calculate_valuation import lambda_handler as valuation_handler


class TestPropertyAPIFlow:
    """Integration tests for property API flow."""
    
    def test_create_and_retrieve_property(
        self, api_gateway_event, lambda_context,
        sample_property_data, dynamodb_table
    ):
        """Test creating a property and retrieving it."""
        # Create property
        create_event = api_gateway_event("POST", "/properties", body=sample_property_data)
        create_response = create_handler(create_event, lambda_context)
        
        assert create_response["statusCode"] == 201
        created_body = json.loads(create_response["body"])
        property_id = created_body["id"]
        
        # Retrieve property
        get_event = api_gateway_event(
            "GET",
            f"/properties/{property_id}",
            path_parameters={"id": property_id}
        )
        get_response = get_handler(get_event, lambda_context)
        
        assert get_response["statusCode"] == 200
        retrieved_body = json.loads(get_response["body"])
        assert retrieved_body["id"] == property_id
        assert retrieved_body["address"]["city"] == "Milano"
    
    def test_create_property_and_calculate_valuation(
        self, api_gateway_event, lambda_context,
        sample_property_data, dynamodb_table
    ):
        """Test creating property and calculating valuation."""
        # Create property
        create_event = api_gateway_event("POST", "/properties", body=sample_property_data)
        create_response = create_handler(create_event, lambda_context)
        
        property_id = json.loads(create_response["body"])["id"]
        
        # Calculate valuation
        valuation_event = api_gateway_event(
            "POST",
            f"/properties/{property_id}/valuations",
            path_parameters={"id": property_id},
            body={"methodology": "comparative"}
        )
        valuation_response = valuation_handler(valuation_event, lambda_context)
        
        assert valuation_response["statusCode"] == 201
        valuation_body = json.loads(valuation_response["body"])
        assert "estimated_value" in valuation_body
        assert valuation_body["estimated_value"] > 0
        assert valuation_body["methodology"] == "comparative"
    
    def test_get_nonexistent_property(
        self, api_gateway_event, lambda_context, dynamodb_table
    ):
        """Test retrieving non-existent property returns 404."""
        fake_id = str(uuid4())
        get_event = api_gateway_event(
            "GET",
            f"/properties/{fake_id}",
            path_parameters={"id": fake_id}
        )
        
        response = get_handler(get_event, lambda_context)
        
        assert response["statusCode"] == 404
        body = json.loads(response["body"])
        assert "error" in body
