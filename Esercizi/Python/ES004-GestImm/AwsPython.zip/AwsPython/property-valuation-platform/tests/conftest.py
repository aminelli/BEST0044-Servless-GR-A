"""
Pytest configuration and shared fixtures.
"""
import os
import json
from decimal import Decimal
from datetime import datetime, timezone
from uuid import uuid4

import pytest
import boto3
from moto import mock_aws

# Set test environment variables
os.environ["AWS_DEFAULT_REGION"] = "eu-west-1"
os.environ["TABLE_NAME"] = "properties-test"
os.environ["EVENT_BUS_NAME"] = "property-valuation-test-event-bus"
os.environ["POWERTOOLS_SERVICE_NAME"] = "property-valuation-test"
os.environ["LOG_LEVEL"] = "DEBUG"
os.environ["ENVIRONMENT"] = "test"


@pytest.fixture(scope="function")
def aws_credentials():
    """Mocked AWS Credentials for moto."""
    os.environ["AWS_ACCESS_KEY_ID"] = "testing"
    os.environ["AWS_SECRET_ACCESS_KEY"] = "testing"
    os.environ["AWS_SECURITY_TOKEN"] = "testing"
    os.environ["AWS_SESSION_TOKEN"] = "testing"


@pytest.fixture(scope="function")
def dynamodb_table(aws_credentials):
    """Create a mocked DynamoDB table."""
    with mock_aws():
        dynamodb = boto3.resource("dynamodb", region_name="eu-west-1")
        
        table = dynamodb.create_table(
            TableName="properties-test",
            KeySchema=[
                {"AttributeName": "PK", "KeyType": "HASH"},
                {"AttributeName": "SK", "KeyType": "RANGE"},
            ],
            AttributeDefinitions=[
                {"AttributeName": "PK", "AttributeType": "S"},
                {"AttributeName": "SK", "AttributeType": "S"},
                {"AttributeName": "GSI1PK", "AttributeType": "S"},
                {"AttributeName": "GSI1SK", "AttributeType": "S"},
                {"AttributeName": "GSI2PK", "AttributeType": "S"},
                {"AttributeName": "GSI2SK", "AttributeType": "S"},
            ],
            GlobalSecondaryIndexes=[
                {
                    "IndexName": "GSI1",
                    "KeySchema": [
                        {"AttributeName": "GSI1PK", "KeyType": "HASH"},
                        {"AttributeName": "GSI1SK", "KeyType": "RANGE"},
                    ],
                    "Projection": {"ProjectionType": "ALL"},
                },
                {
                    "IndexName": "GSI2",
                    "KeySchema": [
                        {"AttributeName": "GSI2PK", "KeyType": "HASH"},
                        {"AttributeName": "GSI2SK", "KeyType": "RANGE"},
                    ],
                    "Projection": {"ProjectionType": "ALL"},
                },
            ],
            BillingMode="PAY_PER_REQUEST",
        )
        
        yield table


@pytest.fixture(scope="function")
def eventbridge_client(aws_credentials):
    """Create a mocked EventBridge client."""
    with mock_aws():
        client = boto3.client("events", region_name="eu-west-1")
        
        # Create event bus
        client.create_event_bus(Name="property-valuation-test-event-bus")
        
        yield client


@pytest.fixture(scope="function")
def sqs_client(aws_credentials):
    """Create a mocked SQS client."""
    with mock_aws():
        client = boto3.client("sqs", region_name="eu-west-1")
        
        # Create test queue
        response = client.create_queue(QueueName="test-queue")
        os.environ["NOTIFICATION_QUEUE_URL"] = response["QueueUrl"]
        
        yield client


@pytest.fixture
def sample_property_data():
    """Sample property data for testing."""
    return {
        "address": {
            "street": "Via Roma 123",
            "city": "Milano",
            "province": "MI",
            "postal_code": "20100",
            "country": "Italia",
            "coordinates": {
                "latitude": 45.4642,
                "longitude": 9.1900
            }
        },
        "property_type": "apartment",
        "surface_sqm": 85,
        "construction_year": 1990,
        "condition": "good",
        "rooms": 3,
        "bathrooms": 2,
        "floor": 3,
        "elevator": True,
        "parking": True,
        "garden": False,
        "terrace": True,
        "energy_class": "C",
        "heating": "centralized"
    }


@pytest.fixture
def sample_valuation_data():
    """Sample valuation data for testing."""
    return {
        "property_id": str(uuid4()),
        "estimated_value": Decimal("350000.00"),
        "min_value": Decimal("320000.00"),
        "max_value": Decimal("380000.00"),
        "price_per_sqm": Decimal("4117.65"),
        "methodology": "comparative",
        "confidence_level": 0.85,
        "valuation_date": datetime.now(timezone.utc).isoformat()
    }


@pytest.fixture
def sample_mortgage_request():
    """Sample mortgage calculation request."""
    return {
        "loan_amount": 200000,
        "property_value": 300000,
        "mortgage_type": "fixed",
        "duration_years": 20,
        "interest_rate": 3.5,
        "monthly_income": 3500
    }


@pytest.fixture
def lambda_context():
    """Mock Lambda context object."""
    class LambdaContext:
        def __init__(self):
            self.function_name = "test-function"
            self.function_version = "$LATEST"
            self.invoked_function_arn = "arn:aws:lambda:eu-west-1:123456789012:function:test-function"
            self.memory_limit_in_mb = 128
            self.aws_request_id = str(uuid4())
            self.log_group_name = "/aws/lambda/test-function"
            self.log_stream_name = "2024/01/01/[$LATEST]test"
            
        def get_remaining_time_in_millis(self):
            return 300000
    
    return LambdaContext()


@pytest.fixture
def api_gateway_event():
    """Mock API Gateway event."""
    def _event(
        method="GET",
        path="/properties",
        body=None,
        path_parameters=None,
        query_parameters=None,
        headers=None
    ):
        return {
            "resource": path,
            "path": path,
            "httpMethod": method,
            "headers": headers or {
                "Accept": "application/json",
                "Content-Type": "application/json",
            },
            "queryStringParameters": query_parameters,
            "pathParameters": path_parameters,
            "body": json.dumps(body) if body else None,
            "isBase64Encoded": False,
            "requestContext": {
                "authorizer": {
                    "claims": {
                        "sub": "test-user-id",
                        "cognito:username": "testuser",
                        "cognito:groups": "admin"
                    }
                },
                "requestId": str(uuid4()),
                "identity": {
                    "sourceIp": "127.0.0.1"
                }
            }
        }
    
    return _event


@pytest.fixture
def eventbridge_event():
    """Mock EventBridge event."""
    def _event(detail_type, detail):
        return {
            "version": "0",
            "id": str(uuid4()),
            "detail-type": detail_type,
            "source": "property-valuation.service",
            "account": "123456789012",
            "time": datetime.now(timezone.utc).isoformat(),
            "region": "eu-west-1",
            "resources": [],
            "detail": detail
        }
    
    return _event
