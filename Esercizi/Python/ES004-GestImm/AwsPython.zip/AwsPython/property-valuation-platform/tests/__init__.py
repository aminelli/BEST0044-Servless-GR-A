"""
Test suite for Property Valuation Platform.
"""
