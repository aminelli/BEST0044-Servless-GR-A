# Test Suite

Comprehensive test suite for the Property Valuation Platform.

## 📁 Structure

```
tests/
├── conftest.py                          # Pytest configuration and shared fixtures
├── unit/                                # Unit tests
│   ├── test_models.py                   # Pydantic model validation tests
│   ├── test_repositories.py             # DynamoDB repository tests
│   ├── test_valuation_service.py        # Valuation calculation logic tests
│   ├── test_cache.py                    # Redis cache service tests
│   └── test_lambda_create_property.py   # Lambda handler tests
├── integration/                         # Integration tests
│   └── test_api_flow.py                 # End-to-end API flow tests
└── README.md                            # This file
```

## 🚀 Running Tests

### Run All Tests

```bash
pytest tests/ -v
```

### Run with Coverage

```bash
pytest tests/ --cov=src --cov-report=html --cov-report=term
```

### Run Specific Test Categories

```bash
# Unit tests only
pytest tests/unit/ -v

# Integration tests only
pytest tests/integration/ -v

# Specific test file
pytest tests/unit/test_models.py -v

# Specific test class
pytest tests/unit/test_models.py::TestProperty -v

# Specific test function
pytest tests/unit/test_models.py::TestProperty::test_valid_property -v
```

### Run with Markers

```bash
# Fast tests only (unit tests)
pytest tests/ -m "not slow" -v

# Slow tests (integration)
pytest tests/ -m "slow" -v
```

## 📊 Coverage Requirements

The project requires **>80% code coverage** as configured in `pyproject.toml`.

View coverage report:

```bash
pytest tests/ --cov=src --cov-report=html
open htmlcov/index.html  # Linux/Mac
start htmlcov/index.html # Windows
```

## 🧪 Test Categories

### Unit Tests

Test individual components in isolation with mocked dependencies:

- **Models** (`test_models.py`): Pydantic validation, field constraints, enum values
- **Repositories** (`test_repositories.py`): CRUD operations, DynamoDB queries
- **Services** (`test_valuation_service.py`): Business logic, calculations, adjustments
- **Cache** (`test_cache.py`): Redis operations, TTL, pattern invalidation
- **Lambda Handlers** (`test_lambda_*.py`): Request/response, error handling, event publishing

### Integration Tests

Test multiple components working together:

- **API Flows** (`test_api_flow.py`): Create → Retrieve → Valuation workflows
- **Event Handling**: EventBridge → Lambda → DynamoDB flows
- **Cache Integration**: API → Cache → DynamoDB interactions

## 🔧 Fixtures

Shared fixtures are defined in `conftest.py`:

| Fixture | Description |
|---------|-------------|
| `aws_credentials` | Mocked AWS credentials for tests |
| `dynamodb_table` | Mocked DynamoDB table with GSIs |
| `eventbridge_client` | Mocked EventBridge client |
| `sqs_client` | Mocked SQS client with test queue |
| `sample_property_data` | Valid property data dictionary |
| `sample_valuation_data` | Valid valuation data |
| `sample_mortgage_request` | Mortgage calculation request |
| `lambda_context` | Mock Lambda context object |
| `api_gateway_event` | Factory for API Gateway events |
| `eventbridge_event` | Factory for EventBridge events |

## 📝 Writing New Tests

### Unit Test Template

```python
import pytest
from src.your_module import YourClass

class TestYourClass:
    """Tests for YourClass."""
    
    @pytest.fixture
    def instance(self):
        """Create instance for testing."""
        return YourClass()
    
    def test_your_function(self, instance):
        """Test your function does X."""
        result = instance.your_function("input")
        assert result == "expected"
    
    def test_error_handling(self, instance):
        """Test error handling."""
        with pytest.raises(ValueError):
            instance.your_function(None)
```

### Integration Test Template

```python
class TestYourFlow:
    """Integration tests for your flow."""
    
    def test_complete_flow(
        self, api_gateway_event, lambda_context, dynamodb_table
    ):
        """Test complete flow from A to Z."""
        # Setup
        event = api_gateway_event("POST", "/endpoint", body={...})
        
        # Execute
        response = lambda_handler(event, lambda_context)
        
        # Assert
        assert response["statusCode"] == 200
```

## 🐛 Debugging Tests

### Run with Print Statements

```bash
pytest tests/ -v -s
```

### Run with PDB Debugger

```bash
pytest tests/ --pdb
```

### Show Local Variables on Failure

```bash
pytest tests/ -v --showlocals
```

### Stop on First Failure

```bash
pytest tests/ -x
```

## 📦 Mocking

We use `moto` for mocking AWS services:

```python
from moto import mock_aws

@mock_aws
def test_with_aws_mocks():
    # DynamoDB, S3, SQS, etc. are automatically mocked
    client = boto3.client('dynamodb')
    # ... test code
```

## 🔍 Best Practices

1. **Arrange-Act-Assert**: Structure tests clearly
2. **One assertion per test**: Keep tests focused
3. **Descriptive names**: `test_create_property_with_invalid_surface_returns_400`
4. **Use fixtures**: Share setup code
5. **Mock external dependencies**: AWS services, Redis, HTTP calls
6. **Test edge cases**: Empty values, negatives, extremes
7. **Test error paths**: Invalid input, exceptions, timeouts

## 📈 Continuous Integration

Tests run automatically in CI/CD:

```yaml
# .github/workflows/test.yml
- name: Run tests
  run: |
    pytest tests/ --cov=src --cov-report=xml
    
- name: Upload coverage
  uses: codecov/codecov-action@v3
```

## 🎯 Coverage Goals

| Component | Current | Target |
|-----------|---------|--------|
| Models | 95%+ | 100% |
| Repositories | 85%+ | 90% |
| Services | 80%+ | 85% |
| Lambda Functions | 75%+ | 85% |
| Utils | 80%+ | 90% |
| **Overall** | **>80%** | **>85%** |

## 🚨 Common Issues

### Issue: `ModuleNotFoundError`

**Solution**: Install dependencies
```bash
pip install -r requirements-dev.txt
```

### Issue: `moto` not mocking correctly

**Solution**: Use `@mock_aws` decorator
```python
from moto import mock_aws

@mock_aws
def test_function():
    # Your test
```

### Issue: Tests pass locally but fail in CI

**Solution**: Check environment variables in `conftest.py`

## 📚 Resources

- [Pytest Documentation](https://docs.pytest.org/)
- [Moto Documentation](http://docs.getmoto.org/)
- [AWS Lambda Testing Best Practices](https://docs.aws.amazon.com/lambda/latest/dg/testing-functions.html)
