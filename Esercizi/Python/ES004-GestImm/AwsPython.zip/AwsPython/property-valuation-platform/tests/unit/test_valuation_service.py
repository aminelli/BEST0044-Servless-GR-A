"""
Unit tests for ValuationService.
"""
import pytest
from decimal import Decimal
from unittest.mock import Mock, patch

from src.services.valuation_service import ValuationService
from src.models import Property, PropertyType, PropertyCondition, EnergyClass


class TestValuationService:
    """Tests for ValuationService."""
    
    @pytest.fixture
    def service(self):
        """Create ValuationService instance."""
        return ValuationService()
    
    @pytest.fixture
    def sample_property(self, sample_property_data):
        """Create sample property."""
        return Property(**sample_property_data)
    
    def test_calculate_valuation_comparative(self, service, sample_property):
        """Test comparative valuation calculation."""
        result = service.calculate_valuation(sample_property, methodology="comparative")
        
        assert result is not None
        assert result.estimated_value > 0
        assert result.min_value < result.estimated_value < result.max_value
        assert result.confidence_level > 0
        assert result.confidence_level <= 1.0
        assert result.methodology == "comparative"
    
    def test_calculate_valuation_income_not_implemented(self, service, sample_property):
        """Test income methodology raises NotImplementedError."""
        with pytest.raises(NotImplementedError):
            service.calculate_valuation(sample_property, methodology="income")
    
    def test_calculate_valuation_cost_not_implemented(self, service, sample_property):
        """Test cost methodology raises NotImplementedError."""
        with pytest.raises(NotImplementedError):
            service.calculate_valuation(sample_property, methodology="cost")
    
    def test_calculate_base_price_per_sqm_milano(self, service):
        """Test base price calculation for Milano."""
        price = service._calculate_base_price_per_sqm("Milano", PropertyType.APARTMENT)
        assert price == Decimal("4500")
    
    def test_calculate_base_price_per_sqm_roma(self, service):
        """Test base price calculation for Roma."""
        price = service._calculate_base_price_per_sqm("Roma", PropertyType.APARTMENT)
        assert price == Decimal("3800")
    
    def test_calculate_base_price_per_sqm_unknown_city(self, service):
        """Test base price for unknown city uses default."""
        price = service._calculate_base_price_per_sqm("SmallTown", PropertyType.APARTMENT)
        assert price == Decimal("2000")
    
    def test_apply_adjustments_excellent_condition(self, service, sample_property):
        """Test adjustments for excellent condition."""
        sample_property.condition = PropertyCondition.EXCELLENT
        base_price = Decimal("4000")
        
        adjusted_price = service._apply_adjustments(sample_property, base_price)
        
        # Excellent condition: +15%
        expected_min = base_price * Decimal("1.10")
        expected_max = base_price * Decimal("1.20")
        assert adjusted_price >= expected_min
        assert adjusted_price <= expected_max
    
    def test_apply_adjustments_to_renovate(self, service, sample_property):
        """Test adjustments for property to renovate."""
        sample_property.condition = PropertyCondition.TO_RENOVATE
        base_price = Decimal("4000")
        
        adjusted_price = service._apply_adjustments(sample_property, base_price)
        
        # To renovate: -20%
        expected_max = base_price * Decimal("0.85")
        assert adjusted_price <= expected_max
    
    def test_apply_adjustments_with_parking(self, service, sample_property):
        """Test parking adds value."""
        sample_property.parking = True
        base_price = Decimal("4000")
        
        adjusted_price = service._apply_adjustments(sample_property, base_price)
        
        # Parking should add value
        assert adjusted_price >= base_price
    
    def test_apply_adjustments_with_garden(self, service, sample_property):
        """Test garden adds value."""
        sample_property.garden = True
        base_price = Decimal("4000")
        
        adjusted_price = service._apply_adjustments(sample_property, base_price)
        
        # Garden should add significant value
        assert adjusted_price > base_price * Decimal("1.05")
    
    def test_apply_adjustments_energy_class_a(self, service, sample_property):
        """Test high energy class adds value."""
        sample_property.energy_class = EnergyClass.A
        base_price = Decimal("4000")
        
        adjusted_price = service._apply_adjustments(sample_property, base_price)
        
        # Energy class A should add value
        assert adjusted_price >= base_price
    
    def test_apply_adjustments_energy_class_g(self, service, sample_property):
        """Test low energy class reduces value."""
        sample_property.energy_class = EnergyClass.G
        base_price = Decimal("4000")
        
        adjusted_price = service._apply_adjustments(sample_property, base_price)
        
        # Energy class G should reduce value
        assert adjusted_price <= base_price
    
    def test_find_comparable_properties(self, service, sample_property):
        """Test finding comparable properties."""
        comparables = service._find_comparable_properties(sample_property)
        
        # Should return mock data for now
        assert isinstance(comparables, list)
        assert len(comparables) > 0
    
    def test_valuation_range_is_reasonable(self, service, sample_property):
        """Test valuation range is within reasonable bounds."""
        result = service.calculate_valuation(sample_property)
        
        # Range should be about ±10% of estimated value
        range_percentage = (result.max_value - result.min_value) / result.estimated_value
        assert range_percentage >= Decimal("0.15")  # At least 15%
        assert range_percentage <= Decimal("0.25")  # At most 25%
