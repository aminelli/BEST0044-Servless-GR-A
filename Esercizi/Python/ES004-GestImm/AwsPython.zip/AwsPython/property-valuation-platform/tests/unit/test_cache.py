"""
Unit tests for CacheService.
"""
import json
import pytest
from decimal import Decimal
from unittest.mock import Mock, patch, MagicMock

from src.utils.cache import CacheService, DecimalEncoder


class TestDecimalEncoder:
    """Tests for DecimalEncoder."""
    
    def test_encode_decimal(self):
        """Test encoding Decimal to float."""
        data = {"price": Decimal("1234.56")}
        result = json.dumps(data, cls=DecimalEncoder)
        assert result == '{"price": 1234.56}'
    
    def test_encode_nested_decimal(self):
        """Test encoding nested Decimal values."""
        data = {
            "property": {
                "price": Decimal("300000.00"),
                "price_per_sqm": Decimal("3529.41")
            }
        }
        result = json.dumps(data, cls=DecimalEncoder)
        parsed = json.loads(result)
        assert parsed["property"]["price"] == 300000.0
        assert parsed["property"]["price_per_sqm"] == 3529.41


class TestCacheService:
    """Tests for CacheService."""
    
    @pytest.fixture
    def mock_redis(self):
        """Create mock Redis client."""
        with patch('src.utils.cache.redis.Redis') as mock:
            redis_client = MagicMock()
            mock.return_value = redis_client
            yield redis_client
    
    @pytest.fixture
    def cache_service(self, mock_redis):
        """Create CacheService with mocked Redis."""
        return CacheService()
    
    def test_get_cache_hit(self, cache_service, mock_redis):
        """Test cache hit returns value."""
        test_data = {"id": "123", "name": "Test"}
        mock_redis.get.return_value = json.dumps(test_data)
        
        result = cache_service.get("test_key")
        
        assert result == test_data
        mock_redis.get.assert_called_once_with("test_key")
    
    def test_get_cache_miss(self, cache_service, mock_redis):
        """Test cache miss returns None."""
        mock_redis.get.return_value = None
        
        result = cache_service.get("nonexistent_key")
        
        assert result is None
        mock_redis.get.assert_called_once_with("nonexistent_key")
    
    def test_get_invalid_json(self, cache_service, mock_redis):
        """Test invalid JSON returns None."""
        mock_redis.get.return_value = "invalid json {"
        
        result = cache_service.get("bad_key")
        
        assert result is None
    
    def test_set_cache(self, cache_service, mock_redis):
        """Test setting cache value."""
        test_data = {"id": "123", "name": "Test"}
        ttl = 300
        
        cache_service.set("test_key", test_data, ttl)
        
        mock_redis.setex.assert_called_once()
        args = mock_redis.setex.call_args[0]
        assert args[0] == "test_key"
        assert args[1] == ttl
        assert json.loads(args[2]) == test_data
    
    def test_set_cache_with_decimal(self, cache_service, mock_redis):
        """Test setting cache with Decimal values."""
        test_data = {"price": Decimal("1234.56")}
        
        cache_service.set("test_key", test_data, 300)
        
        args = mock_redis.setex.call_args[0]
        parsed = json.loads(args[2])
        assert parsed["price"] == 1234.56
    
    def test_delete_cache(self, cache_service, mock_redis):
        """Test deleting cache key."""
        cache_service.delete("test_key")
        
        mock_redis.delete.assert_called_once_with("test_key")
    
    def test_invalidate_pattern(self, cache_service, mock_redis):
        """Test invalidating keys by pattern."""
        mock_redis.keys.return_value = [b"property:1", b"property:2", b"property:3"]
        
        cache_service.invalidate_pattern("property:*")
        
        mock_redis.keys.assert_called_once_with("property:*")
        assert mock_redis.delete.call_count == 3
    
    def test_get_ttl(self, cache_service, mock_redis):
        """Test getting TTL."""
        mock_redis.ttl.return_value = 250
        
        result = cache_service.get_ttl("test_key")
        
        assert result == 250
        mock_redis.ttl.assert_called_once_with("test_key")
    
    def test_increment(self, cache_service, mock_redis):
        """Test incrementing counter."""
        mock_redis.incrby.return_value = 5
        
        result = cache_service.increment("counter_key", 2)
        
        assert result == 5
        mock_redis.incrby.assert_called_once_with("counter_key", 2)
    
    def test_connection_error_handling(self, mock_redis):
        """Test graceful handling of connection errors."""
        import redis
        mock_redis.get.side_effect = redis.ConnectionError("Connection failed")
        
        cache_service = CacheService()
        result = cache_service.get("test_key")
        
        # Should return None instead of raising exception
        assert result is None
