"""
Unit tests for Pydantic models.
"""
from decimal import Decimal
from datetime import datetime
import pytest
from pydantic import ValidationError

from src.models import (
    Property, Address, GeoLocation, RiskAssessment, Valuation,
    MortgageSimulation, Renovation, AreaStatistics,
    PropertyType, PropertyCondition, EnergyClass, RiskLevel, MortgageType
)


class TestGeoLocation:
    """Tests for GeoLocation model."""
    
    def test_valid_coordinates(self):
        """Test valid latitude and longitude."""
        geo = GeoLocation(latitude=45.4642, longitude=9.1900)
        assert geo.latitude == 45.4642
        assert geo.longitude == 9.1900
    
    def test_invalid_latitude_high(self):
        """Test latitude above 90 raises error."""
        with pytest.raises(ValidationError):
            GeoLocation(latitude=91.0, longitude=0.0)
    
    def test_invalid_latitude_low(self):
        """Test latitude below -90 raises error."""
        with pytest.raises(ValidationError):
            GeoLocation(latitude=-91.0, longitude=0.0)
    
    def test_invalid_longitude_high(self):
        """Test longitude above 180 raises error."""
        with pytest.raises(ValidationError):
            GeoLocation(latitude=0.0, longitude=181.0)
    
    def test_invalid_longitude_low(self):
        """Test longitude below -180 raises error."""
        with pytest.raises(ValidationError):
            GeoLocation(latitude=0.0, longitude=-181.0)


class TestAddress:
    """Tests for Address model."""
    
    def test_valid_address(self):
        """Test valid address creation."""
        address = Address(
            street="Via Roma 123",
            city="Milano",
            province="MI",
            postal_code="20100",
            country="Italia",
            coordinates=GeoLocation(latitude=45.4642, longitude=9.1900)
        )
        assert address.city == "Milano"
        assert address.coordinates.latitude == 45.4642
    
    def test_address_without_coordinates(self):
        """Test address without coordinates is valid."""
        address = Address(
            street="Via Roma 123",
            city="Milano",
            province="MI",
            postal_code="20100",
            country="Italia"
        )
        assert address.coordinates is None


class TestProperty:
    """Tests for Property model."""
    
    def test_valid_property(self, sample_property_data):
        """Test valid property creation."""
        prop = Property(**sample_property_data)
        assert prop.address.city == "Milano"
        assert prop.property_type == PropertyType.APARTMENT
        assert prop.surface_sqm == 85
        assert prop.rooms == 3
    
    def test_property_with_id(self, sample_property_data):
        """Test property with generated ID."""
        prop = Property(**sample_property_data)
        assert prop.id is not None
        assert len(str(prop.id)) == 36  # UUID format
    
    def test_property_with_timestamps(self, sample_property_data):
        """Test property has created/updated timestamps."""
        prop = Property(**sample_property_data)
        assert prop.created_at is not None
        assert prop.updated_at is not None
        assert isinstance(prop.created_at, datetime)
    
    def test_invalid_surface_negative(self, sample_property_data):
        """Test negative surface raises error."""
        sample_property_data["surface_sqm"] = -10
        with pytest.raises(ValidationError):
            Property(**sample_property_data)
    
    def test_invalid_surface_zero(self, sample_property_data):
        """Test zero surface raises error."""
        sample_property_data["surface_sqm"] = 0
        with pytest.raises(ValidationError):
            Property(**sample_property_data)
    
    def test_invalid_rooms_negative(self, sample_property_data):
        """Test negative rooms raises error."""
        sample_property_data["rooms"] = -1
        with pytest.raises(ValidationError):
            Property(**sample_property_data)
    
    def test_invalid_construction_year_future(self, sample_property_data):
        """Test future construction year raises error."""
        sample_property_data["construction_year"] = 2030
        with pytest.raises(ValidationError):
            Property(**sample_property_data)
    
    def test_invalid_construction_year_old(self, sample_property_data):
        """Test very old construction year raises error."""
        sample_property_data["construction_year"] = 1700
        with pytest.raises(ValidationError):
            Property(**sample_property_data)
    
    def test_property_condition_enum(self, sample_property_data):
        """Test property condition enum values."""
        for condition in ["new", "excellent", "good", "fair", "to_renovate"]:
            sample_property_data["condition"] = condition
            prop = Property(**sample_property_data)
            assert prop.condition == PropertyCondition(condition)


class TestRiskAssessment:
    """Tests for RiskAssessment model."""
    
    def test_valid_risk_assessment(self):
        """Test valid risk assessment creation."""
        risk = RiskAssessment(
            property_id="123e4567-e89b-12d3-a456-426614174000",
            seismic_risk=RiskLevel.MEDIUM,
            hydrogeological_risk=RiskLevel.LOW,
            environmental_risk=RiskLevel.LOW,
            overall_risk_score=0.3,
            assessment_date=datetime.now()
        )
        assert risk.seismic_risk == RiskLevel.MEDIUM
        assert risk.overall_risk_score == 0.3
    
    def test_invalid_risk_score_high(self):
        """Test risk score above 1.0 raises error."""
        with pytest.raises(ValidationError):
            RiskAssessment(
                property_id="123e4567-e89b-12d3-a456-426614174000",
                seismic_risk=RiskLevel.LOW,
                hydrogeological_risk=RiskLevel.LOW,
                environmental_risk=RiskLevel.LOW,
                overall_risk_score=1.5,
                assessment_date=datetime.now()
            )
    
    def test_invalid_risk_score_negative(self):
        """Test negative risk score raises error."""
        with pytest.raises(ValidationError):
            RiskAssessment(
                property_id="123e4567-e89b-12d3-a456-426614174000",
                seismic_risk=RiskLevel.LOW,
                hydrogeological_risk=RiskLevel.LOW,
                environmental_risk=RiskLevel.LOW,
                overall_risk_score=-0.1,
                assessment_date=datetime.now()
            )


class TestValuation:
    """Tests for Valuation model."""
    
    def test_valid_valuation(self, sample_valuation_data):
        """Test valid valuation creation."""
        valuation = Valuation(**sample_valuation_data)
        assert valuation.estimated_value == Decimal("350000.00")
        assert valuation.confidence_level == 0.85
    
    def test_valuation_range_validation(self):
        """Test min/max value range is valid."""
        valuation = Valuation(
            property_id="123e4567-e89b-12d3-a456-426614174000",
            estimated_value=Decimal("300000"),
            min_value=Decimal("280000"),
            max_value=Decimal("320000"),
            price_per_sqm=Decimal("3529"),
            methodology="comparative",
            confidence_level=0.8,
            valuation_date=datetime.now()
        )
        assert valuation.min_value < valuation.estimated_value < valuation.max_value
    
    def test_invalid_confidence_high(self, sample_valuation_data):
        """Test confidence above 1.0 raises error."""
        sample_valuation_data["confidence_level"] = 1.5
        with pytest.raises(ValidationError):
            Valuation(**sample_valuation_data)
    
    def test_invalid_confidence_negative(self, sample_valuation_data):
        """Test negative confidence raises error."""
        sample_valuation_data["confidence_level"] = -0.1
        with pytest.raises(ValidationError):
            Valuation(**sample_valuation_data)


class TestMortgageSimulation:
    """Tests for MortgageSimulation model."""
    
    def test_valid_mortgage(self):
        """Test valid mortgage simulation."""
        mortgage = MortgageSimulation(
            loan_amount=Decimal("200000"),
            property_value=Decimal("300000"),
            mortgage_type=MortgageType.FIXED,
            duration_years=20,
            interest_rate=Decimal("3.5"),
            monthly_payment=Decimal("1159.25"),
            total_interest=Decimal("78220"),
            TAEG=Decimal("3.8"),
            TAN=Decimal("3.5"),
            LTV=Decimal("66.67"),
            DTI=Decimal("33.12")
        )
        assert mortgage.loan_amount == Decimal("200000")
        assert mortgage.mortgage_type == MortgageType.FIXED
    
    def test_invalid_duration_zero(self):
        """Test zero duration raises error."""
        with pytest.raises(ValidationError):
            MortgageSimulation(
                loan_amount=Decimal("200000"),
                property_value=Decimal("300000"),
                mortgage_type=MortgageType.FIXED,
                duration_years=0,
                interest_rate=Decimal("3.5"),
                monthly_payment=Decimal("1159.25"),
                total_interest=Decimal("78220"),
                TAEG=Decimal("3.8"),
                TAN=Decimal("3.5"),
                LTV=Decimal("66.67"),
                DTI=Decimal("33.12")
            )
    
    def test_invalid_interest_negative(self):
        """Test negative interest rate raises error."""
        with pytest.raises(ValidationError):
            MortgageSimulation(
                loan_amount=Decimal("200000"),
                property_value=Decimal("300000"),
                mortgage_type=MortgageType.FIXED,
                duration_years=20,
                interest_rate=Decimal("-1.0"),
                monthly_payment=Decimal("1159.25"),
                total_interest=Decimal("78220"),
                TAEG=Decimal("3.8"),
                TAN=Decimal("3.5"),
                LTV=Decimal("66.67"),
                DTI=Decimal("33.12")
            )


class TestEnums:
    """Tests for enum types."""
    
    def test_property_type_enum(self):
        """Test PropertyType enum values."""
        assert PropertyType.APARTMENT.value == "apartment"
        assert PropertyType.HOUSE.value == "house"
        assert PropertyType.VILLA.value == "villa"
    
    def test_property_condition_enum(self):
        """Test PropertyCondition enum values."""
        assert PropertyCondition.NEW.value == "new"
        assert PropertyCondition.TO_RENOVATE.value == "to_renovate"
    
    def test_energy_class_enum(self):
        """Test EnergyClass enum values."""
        assert EnergyClass.A_PLUS.value == "A+"
        assert EnergyClass.G.value == "G"
    
    def test_risk_level_enum(self):
        """Test RiskLevel enum values."""
        assert RiskLevel.LOW.value == "low"
        assert RiskLevel.VERY_HIGH.value == "very_high"
    
    def test_mortgage_type_enum(self):
        """Test MortgageType enum values."""
        assert MortgageType.FIXED.value == "fixed"
        assert MortgageType.VARIABLE.value == "variable"
