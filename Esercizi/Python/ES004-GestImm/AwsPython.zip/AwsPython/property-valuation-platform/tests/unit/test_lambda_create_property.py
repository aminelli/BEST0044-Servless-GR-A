"""
Unit tests for create_property Lambda function.
"""
import json
import pytest
from unittest.mock import patch, MagicMock

from src.functions.api.create_property import lambda_handler


class TestCreatePropertyHandler:
    """Tests for create_property Lambda handler."""
    
    @pytest.fixture
    def mock_repository(self):
        """Mock PropertyRepository."""
        with patch('src.functions.api.create_property.PropertyRepository') as mock:
            repo_instance = MagicMock()
            mock.return_value = repo_instance
            yield repo_instance
    
    @pytest.fixture
    def mock_eventbridge(self):
        """Mock EventBridge client."""
        with patch('src.functions.api.create_property.eventbridge') as mock:
            yield mock
    
    def test_create_property_success(
        self, api_gateway_event, lambda_context, 
        sample_property_data, mock_repository, mock_eventbridge
    ):
        """Test successful property creation."""
        event = api_gateway_event("POST", "/properties", body=sample_property_data)
        
        # Mock repository response
        mock_repository.create.return_value = {
            "id": "123e4567-e89b-12d3-a456-426614174000",
            **sample_property_data
        }
        
        response = lambda_handler(event, lambda_context)
        
        assert response["statusCode"] == 201
        body = json.loads(response["body"])
        assert body["id"] == "123e4567-e89b-12d3-a456-426614174000"
        assert body["address"]["city"] == "Milano"
        
        # Verify EventBridge event was sent
        mock_eventbridge.put_events.assert_called_once()
    
    def test_create_property_validation_error(
        self, api_gateway_event, lambda_context, mock_repository
    ):
        """Test validation error for invalid data."""
        invalid_data = {
            "address": {"city": "Milano"},  # Missing required fields
            "surface_sqm": -10  # Invalid negative value
        }
        event = api_gateway_event("POST", "/properties", body=invalid_data)
        
        response = lambda_handler(event, lambda_context)
        
        assert response["statusCode"] == 400
        body = json.loads(response["body"])
        assert "error" in body
        assert "validation" in body["error"].lower()
    
    def test_create_property_missing_body(
        self, api_gateway_event, lambda_context
    ):
        """Test error when request body is missing."""
        event = api_gateway_event("POST", "/properties", body=None)
        
        response = lambda_handler(event, lambda_context)
        
        assert response["statusCode"] == 400
        body = json.loads(response["body"])
        assert "error" in body
    
    def test_create_property_repository_error(
        self, api_gateway_event, lambda_context,
        sample_property_data, mock_repository
    ):
        """Test handling of repository errors."""
        event = api_gateway_event("POST", "/properties", body=sample_property_data)
        mock_repository.create.side_effect = Exception("Database error")
        
        response = lambda_handler(event, lambda_context)
        
        assert response["statusCode"] == 500
        body = json.loads(response["body"])
        assert "error" in body
    
    def test_create_property_cors_headers(
        self, api_gateway_event, lambda_context,
        sample_property_data, mock_repository, mock_eventbridge
    ):
        """Test CORS headers are present."""
        event = api_gateway_event("POST", "/properties", body=sample_property_data)
        mock_repository.create.return_value = {"id": "123", **sample_property_data}
        
        response = lambda_handler(event, lambda_context)
        
        assert "Access-Control-Allow-Origin" in response["headers"]
        assert response["headers"]["Content-Type"] == "application/json"
