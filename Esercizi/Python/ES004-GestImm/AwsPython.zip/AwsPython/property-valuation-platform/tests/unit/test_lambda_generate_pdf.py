"""
Unit tests for generate_pdf_report Lambda function.
"""
import json
import pytest
from unittest.mock import Mock, MagicMock, patch
from io import BytesIO

from src.functions.async.generate_pdf_report import lambda_handler, generate_pdf_report


class TestGeneratePDFReportFunction:
    """Tests for PDF generation Lambda function."""
    
    @pytest.fixture
    def mock_repos(self, sample_property_data, sample_valuation_data):
        """Mock all repositories."""
        with patch('src.functions.async.generate_pdf_report.property_repo') as prop_repo, \
             patch('src.functions.async.generate_pdf_report.valuation_repo') as val_repo, \
             patch('src.functions.async.generate_pdf_report.risk_repo') as risk_repo:
            
            # Property repo
            prop_repo.get_by_id.return_value = {
                'id': '123e4567-e89b-12d3-a456-426614174000',
                **sample_property_data
            }
            
            # Valuation repo
            valuation = {
                'valuation_id': '987fcdeb-51a2-43f7-8e9d-123456789abc',
                **sample_valuation_data
            }
            val_repo.get_valuations_for_property.return_value = [valuation]
            
            # Risk repo
            risk_repo.get_latest_risk_assessment.return_value = {
                'property_id': '123e4567-e89b-12d3-a456-426614174000',
                'seismic_risk': 'medium',
                'hydrogeological_risk': 'low',
                'environmental_risk': 'low',
                'overall_risk_score': 0.3
            }
            
            yield {
                'property': prop_repo,
                'valuation': val_repo,
                'risk': risk_repo
            }
    
    @pytest.fixture
    def mock_pdf_generator(self):
        """Mock PDF generator."""
        with patch('src.functions.async.generate_pdf_report.pdf_generator') as mock:
            pdf_buffer = BytesIO(b'%PDF-1.4 fake pdf content')
            mock.generate_valuation_report.return_value = pdf_buffer
            yield mock
    
    @pytest.fixture
    def mock_s3(self):
        """Mock S3 client."""
        with patch('src.functions.async.generate_pdf_report.s3_client') as mock:
            mock.put_object.return_value = {'ETag': 'test-etag'}
            mock.generate_presigned_url.return_value = 'https://s3.amazonaws.com/test-url'
            yield mock
    
    def test_generate_pdf_success(self, mock_repos, mock_pdf_generator, mock_s3):
        """Test successful PDF generation."""
        result = generate_pdf_report(
            property_id='123e4567-e89b-12d3-a456-426614174000',
            valuation_id='987fcdeb-51a2-43f7-8e9d-123456789abc',
            include_risk=True
        )
        
        assert result is not None
        assert result['property_id'] == '123e4567-e89b-12d3-a456-426614174000'
        assert result['valuation_id'] == '987fcdeb-51a2-43f7-8e9d-123456789abc'
        assert 's3_key' in result
        assert 'download_url' in result
        assert result['download_url'] == 'https://s3.amazonaws.com/test-url'
        
        # Verify PDF generator was called
        mock_pdf_generator.generate_valuation_report.assert_called_once()
        
        # Verify S3 upload
        mock_s3.put_object.assert_called_once()
    
    def test_generate_pdf_without_risk(self, mock_repos, mock_pdf_generator, mock_s3):
        """Test PDF generation without risk assessment."""
        result = generate_pdf_report(
            property_id='123e4567-e89b-12d3-a456-426614174000',
            valuation_id='987fcdeb-51a2-43f7-8e9d-123456789abc',
            include_risk=False
        )
        
        assert result is not None
        
        # Verify risk repo was not called
        mock_repos['risk'].get_latest_risk_assessment.assert_not_called()
    
    def test_generate_pdf_property_not_found(self, mock_repos):
        """Test error when property not found."""
        mock_repos['property'].get_by_id.return_value = None
        
        with pytest.raises(ValueError, match="non trovato"):
            generate_pdf_report(
                property_id='nonexistent',
                valuation_id='987fcdeb-51a2-43f7-8e9d-123456789abc'
            )
    
    def test_generate_pdf_valuation_not_found(self, mock_repos):
        """Test error when valuation not found."""
        mock_repos['valuation'].get_valuations_for_property.return_value = []
        
        with pytest.raises(ValueError, match="non trovata"):
            generate_pdf_report(
                property_id='123e4567-e89b-12d3-a456-426614174000',
                valuation_id='nonexistent'
            )
    
    def test_lambda_handler_sqs_event(
        self, mock_repos, mock_pdf_generator, mock_s3, lambda_context
    ):
        """Test Lambda handler with SQS event."""
        event = {
            'Records': [
                {
                    'body': json.dumps({
                        'property_id': '123e4567-e89b-12d3-a456-426614174000',
                        'valuation_id': '987fcdeb-51a2-43f7-8e9d-123456789abc',
                        'include_risk': True
                    })
                }
            ]
        }
        
        response = lambda_handler(event, lambda_context)
        
        assert response['statusCode'] == 200
        body = json.loads(response['body'])
        assert '1 PDF generati' in body['message']
        assert len(body['results']) == 1
    
    def test_lambda_handler_eventbridge_event(
        self, mock_repos, mock_pdf_generator, mock_s3, lambda_context
    ):
        """Test Lambda handler with EventBridge event."""
        event = {
            'detail-type': 'ValuationCompleted',
            'source': 'property-valuation',
            'detail': {
                'property_id': '123e4567-e89b-12d3-a456-426614174000',
                'valuation_id': '987fcdeb-51a2-43f7-8e9d-123456789abc',
                'include_risk': True
            }
        }
        
        response = lambda_handler(event, lambda_context)
        
        assert response['statusCode'] == 200
        body = json.loads(response['body'])
        assert body['message'] == 'PDF generato con successo'
    
    def test_lambda_handler_direct_request(
        self, mock_repos, mock_pdf_generator, mock_s3, lambda_context
    ):
        """Test Lambda handler with direct API request."""
        event = {
            'body': json.dumps({
                'property_id': '123e4567-e89b-12d3-a456-426614174000',
                'valuation_id': '987fcdeb-51a2-43f7-8e9d-123456789abc',
                'include_risk': False
            })
        }
        
        response = lambda_handler(event, lambda_context)
        
        assert response['statusCode'] == 200
        assert 'Access-Control-Allow-Origin' in response['headers']
    
    def test_lambda_handler_missing_params(self, lambda_context):
        """Test Lambda handler with missing parameters."""
        event = {
            'body': json.dumps({
                'property_id': '123e4567-e89b-12d3-a456-426614174000'
                # Missing valuation_id
            })
        }
        
        response = lambda_handler(event, lambda_context)
        
        assert response['statusCode'] == 400
        body = json.loads(response['body'])
        assert 'obbligatori' in body['message']
    
    def test_lambda_handler_error_handling(
        self, mock_repos, lambda_context
    ):
        """Test error handling in Lambda handler."""
        mock_repos['property'].get_by_id.return_value = None
        
        event = {
            'body': json.dumps({
                'property_id': 'nonexistent',
                'valuation_id': '987fcdeb-51a2-43f7-8e9d-123456789abc'
            })
        }
        
        response = lambda_handler(event, lambda_context)
        
        assert response['statusCode'] == 404
        body = json.loads(response['body'])
        assert body['error'] == 'NOT_FOUND'
