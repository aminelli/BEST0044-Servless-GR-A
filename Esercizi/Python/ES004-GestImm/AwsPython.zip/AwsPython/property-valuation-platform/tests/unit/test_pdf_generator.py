"""
Unit tests for PDF Generator utility.
"""
import pytest
from io import BytesIO

from src.utils.pdf_generator import PDFGenerator, get_pdf_generator


class TestPDFGenerator:
    """Tests for PDFGenerator."""
    
    @pytest.fixture
    def generator(self):
        """Create PDFGenerator instance."""
        return PDFGenerator()
    
    @pytest.fixture
    def sample_property_for_pdf(self, sample_property_data):
        """Sample property data formatted for PDF."""
        return {
            'id': '123e4567-e89b-12d3-a456-426614174000',
            **sample_property_data
        }
    
    @pytest.fixture
    def sample_valuation_for_pdf(self):
        """Sample valuation data formatted for PDF."""
        return {
            'valuation_id': '987fcdeb-51a2-43f7-8e9d-123456789abc',
            'property_id': '123e4567-e89b-12d3-a456-426614174000',
            'estimated_value': 350000.00,
            'min_value': 320000.00,
            'max_value': 380000.00,
            'price_per_sqm': 4117.65,
            'methodology': 'comparative',
            'confidence_level': 0.85,
            'valuation_date': '2024-01-15T10:30:00Z',
            'comparable_properties': [
                {
                    'address': 'Via Dante 45, Milano',
                    'surface_sqm': 80,
                    'price_per_sqm': 4200,
                    'total_value': 336000
                },
                {
                    'address': 'Via Manzoni 12, Milano',
                    'surface_sqm': 90,
                    'price_per_sqm': 4100,
                    'total_value': 369000
                }
            ]
        }
    
    @pytest.fixture
    def sample_risk_for_pdf(self):
        """Sample risk assessment data for PDF."""
        return {
            'property_id': '123e4567-e89b-12d3-a456-426614174000',
            'seismic_risk': 'medium',
            'hydrogeological_risk': 'low',
            'environmental_risk': 'low',
            'overall_risk_score': 0.3,
            'assessment_date': '2024-01-15T10:00:00Z'
        }
    
    def test_pdf_generator_initialization(self, generator):
        """Test PDF generator initializes correctly."""
        assert generator is not None
        assert generator.styles is not None
        assert generator.page_width > 0
        assert generator.page_height > 0
    
    def test_custom_styles_created(self, generator):
        """Test custom styles are created."""
        assert 'CustomTitle' in generator.styles
        assert 'CustomSubtitle' in generator.styles
        assert 'SectionTitle' in generator.styles
        assert 'InfoBox' in generator.styles
        assert 'Highlight' in generator.styles
    
    def test_generate_simple_report(
        self, generator, sample_property_for_pdf, sample_valuation_for_pdf
    ):
        """Test generating simple report without risk assessment."""
        pdf_buffer = generator.generate_valuation_report(
            property_data=sample_property_for_pdf,
            valuation_data=sample_valuation_for_pdf,
            risk_assessment=None
        )
        
        assert isinstance(pdf_buffer, BytesIO)
        assert pdf_buffer.tell() > 0  # Buffer has content
        
        # Check PDF magic bytes
        pdf_buffer.seek(0)
        header = pdf_buffer.read(4)
        assert header == b'%PDF'
    
    def test_generate_complete_report(
        self, generator, sample_property_for_pdf,
        sample_valuation_for_pdf, sample_risk_for_pdf
    ):
        """Test generating complete report with all sections."""
        pdf_buffer = generator.generate_valuation_report(
            property_data=sample_property_for_pdf,
            valuation_data=sample_valuation_for_pdf,
            risk_assessment=sample_risk_for_pdf
        )
        
        assert isinstance(pdf_buffer, BytesIO)
        assert pdf_buffer.tell() > 0
        
        # PDF should be larger with risk section
        pdf_size = len(pdf_buffer.getvalue())
        assert pdf_size > 10000  # At least 10KB
    
    def test_build_title_section(
        self, generator, sample_property_for_pdf, sample_valuation_for_pdf
    ):
        """Test title section generation."""
        elements = generator._build_title_section(
            sample_property_for_pdf,
            sample_valuation_for_pdf
        )
        
        assert len(elements) > 0
        # Should contain title, info, and value highlight
        assert len(elements) >= 5
    
    def test_build_property_section(self, generator, sample_property_for_pdf):
        """Test property details section."""
        elements = generator._build_property_section(sample_property_for_pdf)
        
        assert len(elements) > 0
        # Should contain section title and table
        assert len(elements) >= 2
    
    def test_build_valuation_section(self, generator, sample_valuation_for_pdf):
        """Test valuation section generation."""
        elements = generator._build_valuation_section(sample_valuation_for_pdf)
        
        assert len(elements) > 0
        # Should contain section title, table, and explanation
        assert len(elements) >= 3
    
    def test_build_comparables_section(self, generator, sample_valuation_for_pdf):
        """Test comparables section with data."""
        elements = generator._build_comparables_section(sample_valuation_for_pdf)
        
        assert len(elements) > 0
    
    def test_build_comparables_empty(self, generator):
        """Test comparables section when no comparables."""
        valuation_data = {
            'comparable_properties': []
        }
        elements = generator._build_comparables_section(valuation_data)
        
        assert len(elements) > 0
    
    def test_build_risk_section(self, generator, sample_risk_for_pdf):
        """Test risk assessment section."""
        elements = generator._build_risk_section(sample_risk_for_pdf)
        
        assert len(elements) > 0
        # Should contain title and table
        assert len(elements) >= 2
    
    def test_build_footer_section(self, generator, sample_valuation_for_pdf):
        """Test disclaimer/footer section."""
        elements = generator._build_footer_section(sample_valuation_for_pdf)
        
        assert len(elements) > 0
        # Should contain title and disclaimer text
        assert len(elements) >= 2
    
    def test_get_pdf_generator_singleton(self):
        """Test factory function returns PDFGenerator."""
        generator1 = get_pdf_generator()
        generator2 = get_pdf_generator()
        
        assert isinstance(generator1, PDFGenerator)
        assert isinstance(generator2, PDFGenerator)
        # Note: Not necessarily same instance (not enforced singleton)
    
    def test_pdf_file_size_reasonable(
        self, generator, sample_property_for_pdf,
        sample_valuation_for_pdf, sample_risk_for_pdf
    ):
        """Test PDF file size is reasonable."""
        pdf_buffer = generator.generate_valuation_report(
            property_data=sample_property_for_pdf,
            valuation_data=sample_valuation_for_pdf,
            risk_assessment=sample_risk_for_pdf
        )
        
        file_size = len(pdf_buffer.getvalue())
        
        # Should be between 10KB and 5MB
        assert 10_000 < file_size < 5_000_000
    
    def test_generate_with_missing_optional_fields(self, generator):
        """Test PDF generation with minimal data."""
        minimal_property = {
            'id': '123',
            'address': {
                'street': 'Via Test',
                'city': 'Milano',
                'province': 'MI',
                'postal_code': '20100',
                'country': 'Italia'
            },
            'property_type': 'apartment',
            'surface_sqm': 85
        }
        
        minimal_valuation = {
            'valuation_id': '456',
            'property_id': '123',
            'estimated_value': 300000,
            'min_value': 280000,
            'max_value': 320000,
            'price_per_sqm': 3529,
            'methodology': 'comparative',
            'confidence_level': 0.8,
            'valuation_date': '2024-01-15T10:00:00Z'
        }
        
        pdf_buffer = generator.generate_valuation_report(
            property_data=minimal_property,
            valuation_data=minimal_valuation
        )
        
        assert isinstance(pdf_buffer, BytesIO)
        assert len(pdf_buffer.getvalue()) > 0
