"""
Unit tests for DynamoDB repositories.
"""
import pytest
from datetime import datetime, timezone
from uuid import uuid4

from src.repositories.dynamodb_repository import (
    PropertyRepository, ValuationRepository, RiskAssessmentRepository
)
from src.models import Property, Valuation, RiskAssessment, RiskLevel


class TestPropertyRepository:
    """Tests for PropertyRepository."""
    
    @pytest.fixture
    def repository(self, dynamodb_table):
        """Create PropertyRepository with mocked table."""
        return PropertyRepository()
    
    def test_create_property(self, repository, sample_property_data):
        """Test creating a property."""
        from src.models import Property
        prop = Property(**sample_property_data)
        
        result = repository.create(prop)
        
        assert result["id"] == str(prop.id)
        assert result["address"]["city"] == "Milano"
        assert result["property_type"] == "apartment"
    
    def test_get_property_by_id(self, repository, sample_property_data):
        """Test retrieving property by ID."""
        from src.models import Property
        prop = Property(**sample_property_data)
        repository.create(prop)
        
        result = repository.get_by_id(str(prop.id))
        
        assert result is not None
        assert result["id"] == str(prop.id)
        assert result["address"]["city"] == "Milano"
    
    def test_get_nonexistent_property(self, repository):
        """Test retrieving non-existent property returns None."""
        result = repository.get_by_id(str(uuid4()))
        assert result is None
    
    def test_update_property(self, repository, sample_property_data):
        """Test updating property."""
        from src.models import Property
        prop = Property(**sample_property_data)
        repository.create(prop)
        
        updates = {
            "surface_sqm": 95,
            "rooms": 4,
            "condition": "excellent"
        }
        
        result = repository.update(str(prop.id), updates)
        
        assert result is not None
        assert result["surface_sqm"] == 95
        assert result["rooms"] == 4
        assert result["condition"] == "excellent"
    
    def test_delete_property_soft(self, repository, sample_property_data):
        """Test soft delete property."""
        from src.models import Property
        prop = Property(**sample_property_data)
        repository.create(prop)
        
        result = repository.delete(str(prop.id))
        
        assert result is True
        
        # Property should still exist but marked as deleted
        deleted_prop = repository.get_by_id(str(prop.id))
        assert deleted_prop is not None
        assert deleted_prop.get("deleted") is True
    
    def test_list_properties(self, repository, sample_property_data):
        """Test listing properties."""
        from src.models import Property
        
        # Create multiple properties
        for i in range(3):
            prop = Property(**sample_property_data)
            repository.create(prop)
        
        result = repository.list_properties(limit=10)
        
        assert "items" in result
        assert len(result["items"]) >= 3
    
    def test_query_by_city(self, repository, sample_property_data):
        """Test querying properties by city."""
        from src.models import Property
        
        # Create property in Milano
        prop1 = Property(**sample_property_data)
        repository.create(prop1)
        
        # Create property in Roma
        sample_property_data["address"]["city"] = "Roma"
        prop2 = Property(**sample_property_data)
        repository.create(prop2)
        
        result = repository.query_by_city("Milano")
        
        assert len(result) >= 1
        assert all(item["address"]["city"] == "Milano" for item in result)


class TestValuationRepository:
    """Tests for ValuationRepository."""
    
    @pytest.fixture
    def repository(self, dynamodb_table):
        """Create ValuationRepository with mocked table."""
        return ValuationRepository()
    
    def test_create_valuation(self, repository, sample_valuation_data):
        """Test creating a valuation."""
        from src.models import Valuation
        from decimal import Decimal
        
        valuation = Valuation(**sample_valuation_data)
        result = repository.create_valuation(valuation)
        
        assert result is not None
        assert result["property_id"] == sample_valuation_data["property_id"]
        assert Decimal(str(result["estimated_value"])) == Decimal("350000.00")
    
    def test_get_valuations_for_property(self, repository, sample_valuation_data):
        """Test retrieving valuations for a property."""
        from src.models import Valuation
        
        property_id = sample_valuation_data["property_id"]
        
        # Create multiple valuations
        for i in range(3):
            valuation = Valuation(**sample_valuation_data)
            repository.create_valuation(valuation)
        
        result = repository.get_valuations_for_property(property_id)
        
        assert len(result) >= 3
        assert all(item["property_id"] == property_id for item in result)


class TestRiskAssessmentRepository:
    """Tests for RiskAssessmentRepository."""
    
    @pytest.fixture
    def repository(self, dynamodb_table):
        """Create RiskAssessmentRepository with mocked table."""
        return RiskAssessmentRepository()
    
    def test_create_risk_assessment(self, repository):
        """Test creating a risk assessment."""
        property_id = str(uuid4())
        
        risk = RiskAssessment(
            property_id=property_id,
            seismic_risk=RiskLevel.MEDIUM,
            hydrogeological_risk=RiskLevel.LOW,
            environmental_risk=RiskLevel.LOW,
            overall_risk_score=0.3,
            assessment_date=datetime.now(timezone.utc)
        )
        
        result = repository.create_risk_assessment(risk)
        
        assert result is not None
        assert result["property_id"] == property_id
        assert result["seismic_risk"] == "medium"
    
    def test_get_latest_risk_assessment(self, repository):
        """Test retrieving latest risk assessment."""
        property_id = str(uuid4())
        
        # Create multiple assessments
        for i in range(3):
            risk = RiskAssessment(
                property_id=property_id,
                seismic_risk=RiskLevel.LOW,
                hydrogeological_risk=RiskLevel.LOW,
                environmental_risk=RiskLevel.LOW,
                overall_risk_score=0.2,
                assessment_date=datetime.now(timezone.utc)
            )
            repository.create_risk_assessment(risk)
        
        result = repository.get_latest_risk_assessment(property_id)
        
        assert result is not None
        assert result["property_id"] == property_id
