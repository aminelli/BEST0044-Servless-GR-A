"""
Servizio business logic per calcolo valutazioni immobiliari.

Implementa algoritmi di stima valore con approccio comparativo.
"""

from datetime import datetime, timedelta
from decimal import Decimal
from typing import List, Optional
from uuid import uuid4

from aws_lambda_powertools import Logger

from src.models import Property, Valuation, PropertyType
from src.repositories.dynamodb_repository import PropertyRepository, ValuationRepository

logger = Logger()


class ValuationService:
    """
    Servizio per logica valutazione immobili.
    
    Implementa diversi metodi di valutazione:
    - Comparative: basato su immobili comparabili
    - Income: basato su reddito potenziale (affitti)
    - Cost: basato su costo ricostruzione
    """
    
    def __init__(
        self,
        property_repo: PropertyRepository,
        valuation_repo: ValuationRepository
    ):
        """
        Inizializza servizio valutazione.
        
        Args:
            property_repo: Repository per accesso immobili
            valuation_repo: Repository per accesso valutazioni
        """
        self.property_repo = property_repo
        self.valuation_repo = valuation_repo
    
    def calculate_valuation(
        self,
        property_obj: Property,
        methodology: str = "comparative"
    ) -> Valuation:
        """
        Calcola valutazione immobile.
        
        Args:
            property_obj: Immobile da valutare
            methodology: Metodologia (comparative, income, cost)
        
        Returns:
            Oggetto Valuation con stima valore
        """
        logger.info(
            f"Calcolo valutazione per property {property_obj.property_id} "
            f"con metodologia {methodology}"
        )
        
        if methodology == "comparative":
            return self._calculate_comparative(property_obj)
        elif methodology == "income":
            return self._calculate_income(property_obj)
        elif methodology == "cost":
            return self._calculate_cost(property_obj)
        else:
            raise ValueError(f"Metodologia non supportata: {methodology}")
    
    def _calculate_comparative(self, property_obj: Property) -> Valuation:
        """
        Valutazione comparativa basata su immobili simili.
        
        Algoritmo:
        1. Trova immobili comparabili (stessa città, tipo simile)
        2. Calcola prezzo medio al mq
        3. Applica adjustment per caratteristiche specifiche
        4. Calcola valore finale
        
        Args:
            property_obj: Immobile da valutare
        
        Returns:
            Valuation calcolato
        """
        # 1. Recupera immobili comparabili
        comparable_properties = self._find_comparable_properties(property_obj)
        
        logger.info(f"Trovati {len(comparable_properties)} immobili comparabili")
        
        # 2. Calcola prezzo base al mq dalla zona/tipo
        base_price_per_sqm = self._calculate_base_price_per_sqm(
            city=property_obj.address.city,
            property_type=property_obj.property_type
        )
        
        logger.info(f"Prezzo base al mq: {base_price_per_sqm}€/mq")
        
        # 3. Applica adjustment per caratteristiche
        adjusted_price_per_sqm = self._apply_adjustments(
            base_price=base_price_per_sqm,
            property_obj=property_obj
        )
        
        logger.info(f"Prezzo adjusted al mq: {adjusted_price_per_sqm}€/mq")
        
        # 4. Calcola valore totale
        estimated_value = (
            Decimal(str(adjusted_price_per_sqm)) * 
            Decimal(str(property_obj.surface_sqm))
        ).quantize(Decimal('0.01'))
        
        # Range di confidenza (±10%)
        min_value = (estimated_value * Decimal('0.9')).quantize(Decimal('0.01'))
        max_value = (estimated_value * Decimal('1.1')).quantize(Decimal('0.01'))
        
        # Confidence level basato su numero comparables
        confidence = min(len(comparable_properties) / 10, 0.95)  # Max 0.95
        
        # Crea valutazione
        valuation = Valuation(
            valuation_id=str(uuid4()),
            property_id=property_obj.property_id,
            estimated_value=estimated_value,
            min_value=min_value,
            max_value=max_value,
            price_per_sqm=Decimal(str(adjusted_price_per_sqm)),
            methodology="comparative",
            comparable_properties=[p.property_id for p in comparable_properties[:5]],
            confidence_level=confidence,
            valuation_date=datetime.utcnow(),
            valid_until=datetime.utcnow() + timedelta(days=90)
        )
        
        logger.info(
            f"Valutazione calcolata: {estimated_value}€ "
            f"(range: {min_value}€ - {max_value}€), "
            f"confidence: {confidence:.2%}"
        )
        
        return valuation
    
    def _find_comparable_properties(self, property_obj: Property) -> List[Property]:
        """
        Trova immobili comparabili.
        
        Criteri:
        - Stessa città
        - Stesso tipo o simile
        - Superficie simile (±30%)
        - Anno costruzione simile (±15 anni)
        """
        # TODO: Implementare query efficienti con GSI
        # Per ora restituisce lista vuota (mock)
        return []
    
    def _calculate_base_price_per_sqm(
        self,
        city: str,
        property_type: PropertyType
    ) -> Decimal:
        """
        Calcola prezzo base al mq per zona e tipologia.
        
        In produzione, questi dati verrebbero da:
        - Database storico transazioni
        - API dati mercato immobiliare
        - Machine Learning model
        
        Args:
            city: Città
            property_type: Tipologia immobile
        
        Returns:
            Prezzo base in €/mq
        """
        # Mock data - in produzione query database o API
        # Prezzi medi al mq per città (valori indicativi 2026)
        city_prices = {
            "Milano": 4500,
            "Roma": 3500,
            "Firenze": 3800,
            "Torino": 2200,
            "Bologna": 2800,
            "Napoli": 2400,
        }
        
        # Adjustment per tipologia
        type_multipliers = {
            PropertyType.APARTMENT: 1.0,
            PropertyType.HOUSE: 1.1,
            PropertyType.VILLA: 1.5,
            PropertyType.OFFICE: 0.9,
            PropertyType.WAREHOUSE: 0.5,
            PropertyType.LAND: 0.3,
            PropertyType.COMMERCIAL: 1.2,
        }
        
        base_price = city_prices.get(city, 2000)  # Default se città non trovata
        multiplier = type_multipliers.get(property_type, 1.0)
        
        return Decimal(str(base_price * multiplier))
    
    def _apply_adjustments(
        self,
        base_price: Decimal,
        property_obj: Property
    ) -> Decimal:
        """
        Applica adjustment al prezzo base per caratteristiche specifiche.
        
        Fattori considerati:
        - Condizione immobile (+/- 20%)
        - Piano e presenza ascensore (+/- 10%)
        - Presenza posto auto (+5%)
        - Presenza giardino/terrazzo (+10%)
        - Età edificio (+/- 15%)
        - Classe energetica (+/- 8%)
        
        Args:
            base_price: Prezzo base al mq
            property_obj: Immobile da valutare
        
        Returns:
            Prezzo adjusted al mq
        """
        adjustment_factor = Decimal('1.0')
        
        # Condizione
        condition_adjustments = {
            "new": Decimal('1.20'),
            "excellent": Decimal('1.10'),
            "good": Decimal('1.0'),
            "fair": Decimal('0.90'),
            "poor": Decimal('0.80'),
            "to_renovate": Decimal('0.75')
        }
        adjustment_factor *= condition_adjustments.get(
            property_obj.condition,
            Decimal('1.0')
        )
        
        # Piano e ascensore
        if property_obj.floor is not None:
            if property_obj.floor > 4 and not property_obj.has_elevator:
                adjustment_factor *= Decimal('0.90')  # -10% per piano alto senza ascensore
            elif property_obj.floor >= 3 and property_obj.has_elevator:
                adjustment_factor *= Decimal('1.05')  # +5% per piano alto con ascensore
        
        # Posto auto
        if property_obj.has_parking:
            adjustment_factor *= Decimal('1.05')  # +5%
        
        # Giardino o terrazzo
        if property_obj.has_garden:
            adjustment_factor *= Decimal('1.10')  # +10%
        elif property_obj.has_terrace:
            adjustment_factor *= Decimal('1.05')  # +5%
        
        # Età edificio
        current_year = datetime.now().year
        age = current_year - property_obj.construction_year
        
        if age <= 5:
            adjustment_factor *= Decimal('1.10')  # +10% se nuovissimo
        elif age <= 15:
            adjustment_factor *= Decimal('1.05')  # +5% se recente
        elif age > 50:
            adjustment_factor *= Decimal('0.90')  # -10% se molto vecchio
        
        # Classe energetica
        if property_obj.energy_class:
            energy_adjustments = {
                "A+": Decimal('1.08'),
                "A": Decimal('1.05'),
                "B": Decimal('1.02'),
                "C": Decimal('1.0'),
                "D": Decimal('0.98'),
                "E": Decimal('0.95'),
                "F": Decimal('0.92'),
                "G": Decimal('0.90')
            }
            adjustment_factor *= energy_adjustments.get(
                property_obj.energy_class,
                Decimal('1.0')
            )
        
        adjusted_price = base_price * adjustment_factor
        
        logger.info(
            f"Adjustment factor: {adjustment_factor:.3f} "
            f"({base_price}€ → {adjusted_price}€/mq)"
        )
        
        return adjusted_price
    
    def _calculate_income(self, property_obj: Property) -> Valuation:
        """Valutazione reddituale (basata su affitto potenziale)"""
        # TODO: Implementare metodo reddituale
        raise NotImplementedError("Metodo reddituale non ancora implementato")
    
    def _calculate_cost(self, property_obj: Property) -> Valuation:
        """Valutazione a costo di ricostruzione"""
        # TODO: Implementare metodo del costo
        raise NotImplementedError("Metodo del costo non ancora implementato")
