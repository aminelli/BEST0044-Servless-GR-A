"""
Modelli di dominio per la piattaforma di valutazione immobiliare.

Questi modelli utilizzano Pydantic per validazione automatica dei dati
e type hints Python per type safety.
"""

from datetime import datetime
from decimal import Decimal
from enum import Enum
from typing import List, Optional
from uuid import UUID, uuid4

from pydantic import BaseModel, Field, field_validator, ConfigDict


class PropertyType(str, Enum):
    """Tipologia immobile"""
    APARTMENT = "apartment"
    HOUSE = "house"
    VILLA = "villa"
    OFFICE = "office"
    WAREHOUSE = "warehouse"
    LAND = "land"
    COMMERCIAL = "commercial"


class PropertyCondition(str, Enum):
    """Condizione immobile"""
    NEW = "new"
    EXCELLENT = "excellent"
    GOOD = "good"
    FAIR = "fair"
    POOR = "poor"
    TO_RENOVATE = "to_renovate"


class EnergyClass(str, Enum):
    """Classe energetica"""
    A_PLUS = "A+"
    A = "A"
    B = "B"
    C = "C"
    D = "D"
    E = "E"
    F = "F"
    G = "G"


class RiskLevel(str, Enum):
    """Livello di rischio"""
    VERY_LOW = "very_low"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    VERY_HIGH = "very_high"


class MortgageType(str, Enum):
    """Tipo di mutuo"""
    FIXED = "fixed"
    VARIABLE = "variable"
    MIXED = "mixed"


class GeoLocation(BaseModel):
    """Coordinate geografiche"""
    latitude: float = Field(..., ge=-90, le=90, description="Latitudine")
    longitude: float = Field(..., ge=-180, le=180, description="Longitudine")


class Address(BaseModel):
    """Indirizzo completo"""
    street: str = Field(..., min_length=5, max_length=200, description="Via e numero civico")
    city: str = Field(..., min_length=2, max_length=100, description="Città")
    province: str = Field(..., min_length=2, max_length=2, description="Provincia (sigla)")
    postal_code: str = Field(..., min_length=5, max_length=5, description="CAP")
    country: str = Field(default="IT", description="Codice paese (ISO 3166-1 alpha-2)")
    geo_location: Optional[GeoLocation] = Field(None, description="Coordinate GPS")

    def __str__(self) -> str:
        return f"{self.street}, {self.city}, {self.province}, {self.postal_code}"


class CadastralData(BaseModel):
    """Dati catastali"""
    sheet: str = Field(..., description="Foglio")
    parcel: str = Field(..., description="Particella")
    subordinate: Optional[str] = Field(None, description="Subalterno")
    category: Optional[str] = Field(None, description="Categoria catastale")
    cadastral_income: Optional[Decimal] = Field(None, ge=0, description="Rendita catastale (€)")


class Property(BaseModel):
    """
    Modello principale per rappresentare un immobile.
    
    Attributi:
        property_id: Identificativo univoco generato automaticamente
        address: Indirizzo completo dell'immobile
        property_type: Tipologia (appartamento, casa, villa, etc.)
        surface_sqm: Superficie commerciale in metri quadri
        construction_year: Anno di costruzione
        condition: Stato di conservazione
        energy_class: Classe energetica
        rooms: Numero di locali
        bathrooms: Numero di bagni
        floor: Piano (0=terra, -1=seminterrato, etc.)
        has_elevator: Presenza ascensore
        has_parking: Presenza posto auto
        has_garden: Presenza giardino
        has_terrace: Presenza terrazzo
        cadastral_data: Dati catastali
        created_at: Timestamp creazione
        updated_at: Timestamp ultimo aggiornamento
        owner_id: ID del proprietario (riferimento esterno)
    """
    
    model_config = ConfigDict(
        str_strip_whitespace=True,
        use_enum_values=True,
        validate_assignment=True
    )
    
    property_id: str = Field(
        default_factory=lambda: str(uuid4()),
        description="ID univoco immobile"
    )
    address: Address = Field(..., description="Indirizzo completo")
    property_type: PropertyType = Field(..., description="Tipologia immobile")
    surface_sqm: float = Field(..., gt=0, le=100000, description="Superficie commerciale (mq)")
    construction_year: int = Field(..., ge=1800, le=2026, description="Anno costruzione")
    condition: PropertyCondition = Field(..., description="Stato conservazione")
    energy_class: Optional[EnergyClass] = Field(None, description="Classe energetica")
    
    rooms: int = Field(..., ge=1, le=50, description="Numero locali")
    bathrooms: int = Field(..., ge=0, le=20, description="Numero bagni")
    floor: Optional[int] = Field(None, ge=-5, le=100, description="Piano")
    total_floors: Optional[int] = Field(None, ge=1, le=100, description="Piani totali edificio")
    
    has_elevator: bool = Field(default=False, description="Presenza ascensore")
    has_parking: bool = Field(default=False, description="Presenza posto auto")
    has_garden: bool = Field(default=False, description="Presenza giardino")
    has_terrace: bool = Field(default=False, description="Presenza terrazzo")
    has_balcony: bool = Field(default=False, description="Presenza balcone")
    
    cadastral_data: Optional[CadastralData] = Field(None, description="Dati catastali")
    
    description: Optional[str] = Field(
        None,
        max_length=2000,
        description="Descrizione libera"
    )
    
    owner_id: Optional[str] = Field(None, description="ID proprietario")
    
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    
    @field_validator('surface_sqm')
    @classmethod
    def validate_surface(cls, v: float) -> float:
        """Valida che la superficie sia ragionevole"""
        if v < 10:
            raise ValueError("La superficie deve essere almeno 10 mq")
        return v
    
    @field_validator('floor')
    @classmethod
    def validate_floor_with_elevator(cls, v: Optional[int], info) -> Optional[int]:
        """Verifica coerenza piano/ascensore"""
        if v is not None and v > 4 and not info.data.get('has_elevator'):
            # Warning: immobile sopra 4° piano senza ascensore (inusuale ma non errore)
            pass
        return v


class RiskAssessment(BaseModel):
    """
    Valutazione dei rischi associati a un immobile.
    
    Include rischi sismico, idrogeologico, ambientale e calcola uno score complessivo.
    """
    
    assessment_id: str = Field(default_factory=lambda: str(uuid4()))
    property_id: str = Field(..., description="ID immobile valutato")
    
    seismic_risk: RiskLevel = Field(..., description="Rischio sismico")
    seismic_zone: int = Field(..., ge=1, le=4, description="Zona sismica (1=massima, 4=minima)")
    
    hydrogeological_risk: RiskLevel = Field(..., description="Rischio idrogeologico")
    flood_risk: bool = Field(default=False, description="Rischio alluvioni")
    landslide_risk: bool = Field(default=False, description="Rischio frane")
    
    environmental_risk: RiskLevel = Field(..., description="Rischio ambientale")
    pollution_level: Optional[str] = Field(None, description="Livello inquinamento")
    noise_level: Optional[str] = Field(None, description="Livello rumore")
    
    overall_risk_score: float = Field(
        ...,
        ge=0.0,
        le=10.0,
        description="Score complessivo rischio (0=minimo, 10=massimo)"
    )
    
    assessment_date: datetime = Field(default_factory=datetime.utcnow)
    valid_until: Optional[datetime] = Field(None, description="Validità valutazione")
    
    notes: Optional[str] = Field(None, max_length=1000)


class Valuation(BaseModel):
    """
    Valutazione economica di un immobile.
    
    Contiene il valore stimato, metodologia utilizzata, e dati comparabili.
    """
    
    valuation_id: str = Field(default_factory=lambda: str(uuid4()))
    property_id: str = Field(..., description="ID immobile valutato")
    
    estimated_value: Decimal = Field(..., gt=0, description="Valore stimato (€)")
    min_value: Optional[Decimal] = Field(None, gt=0, description="Valore minimo range (€)")
    max_value: Optional[Decimal] = Field(None, gt=0, description="Valore massimo range (€)")
    
    price_per_sqm: Decimal = Field(..., gt=0, description="Prezzo al mq (€/mq)")
    
    methodology: str = Field(
        ...,
        description="Metodologia utilizzata (comparativa, reddituale, costo)"
    )
    
    comparable_properties: Optional[List[str]] = Field(
        default=[],
        description="Lista ID immobili comparabili usati"
    )
    
    risk_adjustment: Optional[Decimal] = Field(
        None,
        description="Aggiustamento per rischio (%)"
    )
    
    confidence_level: float = Field(
        ...,
        ge=0.0,
        le=1.0,
        description="Livello di confidenza della stima (0-1)"
    )
    
    valuation_date: datetime = Field(default_factory=datetime.utcnow)
    valid_until: datetime = Field(..., description="Validità della valutazione")
    
    appraiser_id: Optional[str] = Field(None, description="ID perito che ha effettuato la stima")
    notes: Optional[str] = Field(None, max_length=2000)


class MortgageSimulation(BaseModel):
    """
    Simulazione calcolo mutuo.
    
    Calcola rate, piano di ammortamento, TAEG e TAN.
    """
    
    simulation_id: str = Field(default_factory=lambda: str(uuid4()))
    property_id: Optional[str] = Field(None, description="ID immobile (opzionale)")
    
    loan_amount: Decimal = Field(..., gt=0, description="Importo mutuo richiesto (€)")
    property_value: Decimal = Field(..., gt=0, description="Valore immobile (€)")
    
    mortgage_type: MortgageType = Field(..., description="Tipo mutuo")
    duration_years: int = Field(..., ge=1, le=40, description="Durata in anni")
    
    interest_rate: Decimal = Field(
        ...,
        gt=0,
        le=20,
        description="Tasso interesse annuo (%)"
    )
    
    monthly_payment: Decimal = Field(..., gt=0, description="Rata mensile (€)")
    total_interest: Decimal = Field(..., ge=0, description="Interessi totali (€)")
    total_amount: Decimal = Field(..., gt=0, description="Importo totale da restituire (€)")
    
    taeg: Decimal = Field(..., gt=0, description="TAEG - Tasso Annuo Effettivo Globale (%)")
    tan: Decimal = Field(..., gt=0, description="TAN - Tasso Annuo Nominale (%)")
    
    ltv_ratio: Decimal = Field(
        ...,
        gt=0,
        le=100,
        description="Loan-to-Value ratio (%)"
    )
    
    applicant_income: Optional[Decimal] = Field(
        None,
        gt=0,
        description="Reddito richiedente (€/anno)"
    )
    
    dti_ratio: Optional[Decimal] = Field(
        None,
        description="Debt-to-Income ratio (%)"
    )
    
    is_sustainable: Optional[bool] = Field(
        None,
        description="Mutuo sostenibile (DTI < 35%)"
    )
    
    simulation_date: datetime = Field(default_factory=datetime.utcnow)


class Renovation(BaseModel):
    """
    Intervento di ristrutturazione su un immobile.
    """
    
    renovation_id: str = Field(default_factory=lambda: str(uuid4()))
    property_id: str = Field(..., description="ID immobile")
    
    renovation_type: str = Field(..., description="Tipo intervento")
    description: str = Field(..., min_length=10, max_length=2000)
    
    estimated_cost: Decimal = Field(..., gt=0, description="Costo stimato (€)")
    actual_cost: Optional[Decimal] = Field(None, gt=0, description="Costo effettivo (€)")
    
    start_date: datetime = Field(..., description="Data inizio lavori")
    end_date: Optional[datetime] = Field(None, description="Data fine lavori")
    
    value_increase: Optional[Decimal] = Field(
        None,
        description="Aumento valore immobile (€)"
    )
    
    roi_percentage: Optional[Decimal] = Field(
        None,
        description="ROI - Return on Investment (%)"
    )
    
    status: str = Field(default="planned", description="Stato (planned, ongoing, completed)")
    
    documents: Optional[List[str]] = Field(
        default=[],
        description="Lista URL documenti/foto"
    )
    
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class AreaStatistics(BaseModel):
    """
    Statistiche di mercato per un'area geografica.
    """
    
    area_id: str = Field(..., description="ID area (es. codice ISTAT comune)")
    area_name: str = Field(..., description="Nome area")
    city: str = Field(..., description="Città")
    province: str = Field(..., description="Provincia")
    
    average_price_per_sqm: Decimal = Field(..., gt=0, description="Prezzo medio al mq (€/mq)")
    median_price_per_sqm: Decimal = Field(..., gt=0, description="Prezzo mediano al mq (€/mq)")
    
    min_price_per_sqm: Decimal = Field(..., gt=0, description="Prezzo minimo al mq (€/mq)")
    max_price_per_sqm: Decimal = Field(..., gt=0, description="Prezzo massimo al mq (€/mq)")
    
    total_properties: int = Field(..., ge=0, description="Numero immobili nell'area")
    
    price_trend_6m: Optional[Decimal] = Field(
        None,
        description="Trend prezzi ultimi 6 mesi (%)"
    )
    price_trend_12m: Optional[Decimal] = Field(
        None,
        description="Trend prezzi ultimi 12 mesi (%)"
    )
    
    demand_level: Optional[str] = Field(None, description="Livello domanda (low/medium/high)")
    
    amenities_score: Optional[float] = Field(
        None,
        ge=0,
        le=10,
        description="Score servizi zona (0-10)"
    )
    
    data_updated_at: datetime = Field(default_factory=datetime.utcnow)


# Response models per API

class PropertyResponse(Property):
    """Response model con dati aggiuntivi"""
    pass


class PaginationMetadata(BaseModel):
    """Metadata per paginazione"""
    total: int = Field(..., ge=0)
    page: int = Field(..., ge=1)
    page_size: int = Field(..., ge=1, le=100)
    total_pages: int = Field(..., ge=0)


class PropertyListResponse(BaseModel):
    """Response per lista immobili con paginazione"""
    items: List[PropertyResponse]
    metadata: PaginationMetadata


class ErrorResponse(BaseModel):
    """Response per errori API"""
    error: str = Field(..., description="Codice errore")
    message: str = Field(..., description="Messaggio errore")
    details: Optional[dict] = Field(None, description="Dettagli aggiuntivi")
    timestamp: datetime = Field(default_factory=datetime.utcnow)
