"""
Repository pattern per accesso a DynamoDB.

Implementa il pattern Repository per separare la logica di accesso ai dati
dalla business logic. Usa single-table design per DynamoDB.
"""

from datetime import datetime
from decimal import Decimal
from typing import Dict, List, Optional
import json

import boto3
from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError
from aws_lambda_powertools import Logger

from src.models import Property, Valuation, RiskAssessment

logger = Logger()


class DynamoDBRepository:
    """
    Repository base per operazioni DynamoDB comuni.
    
    Implementa single-table design con pattern PK/SK:
    - PK = PROPERTY#{property_id}
    - SK = METADATA | VALUATION#{timestamp} | RISK#{timestamp}
    """
    
    def __init__(self, table_name: str, region: str = "eu-west-1"):
        """
        Inizializza repository DynamoDB.
        
        Args:
            table_name: Nome tabella DynamoDB
            region: AWS region (default: eu-west-1)
        """
        self.dynamodb = boto3.resource('dynamodb', region_name=region)
        self.table = self.dynamodb.Table(table_name)
        self.table_name = table_name
        
    def _serialize_decimal(self, obj: any) -> any:
        """Converte Decimal in float per JSON serialization"""
        if isinstance(obj, Decimal):
            return float(obj)
        raise TypeError(f"Object of type {type(obj)} is not JSON serializable")


class PropertyRepository(DynamoDBRepository):
    """
    Repository per gestione immobili in DynamoDB.
    
    Access patterns implementati:
    1. Get property by ID
    2. List all properties (with pagination)
    3. Query properties by city
    4. Query properties by type
    5. Full-text search (via GSI)
    """
    
    async def create(self, property_obj: Property) -> Property:
        """
        Crea un nuovo immobile.
        
        Args:
            property_obj: Oggetto Property da salvare
            
        Returns:
            Property salvato con timestamp aggiornati
            
        Raises:
            ValueError: Se l'immobile esiste già
        """
        try:
            # Prepara item per DynamoDB
            now = datetime.utcnow().isoformat()
            item = {
                'PK': f"PROPERTY#{property_obj.property_id}",
                'SK': 'METADATA',
                'EntityType': 'Property',
                'PropertyId': property_obj.property_id,
                'Address': property_obj.address.model_dump(),
                'PropertyType': property_obj.property_type,
                'SurfaceSqm': Decimal(str(property_obj.surface_sqm)),
                'ConstructionYear': property_obj.construction_year,
                'Condition': property_obj.condition,
                'Rooms': property_obj.rooms,
                'Bathrooms': property_obj.bathrooms,
                'Floor': property_obj.floor,
                'HasElevator': property_obj.has_elevator,
                'HasParking': property_obj.has_parking,
                'HasGarden': property_obj.has_garden,
                'HasTerrace': property_obj.has_terrace,
                'CreatedAt': now,
                'UpdatedAt': now,
                
                # GSI per query per città
                'GSI1PK': f"CITY#{property_obj.address.city}",
                'GSI1SK': f"TYPE#{property_obj.property_type}#{property_obj.property_id}",
                
                # GSI per query per tipo
                'GSI2PK': f"TYPE#{property_obj.property_type}",
                'GSI2SK': f"PRICE#{property_obj.surface_sqm}",
            }
            
            # Condition expression per evitare sovrascrittura
            self.table.put_item(
                Item=item,
                ConditionExpression='attribute_not_exists(PK)'
            )
            
            logger.info(f"Immobile creato: {property_obj.property_id}")
            return property_obj
            
        except ClientError as e:
            if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
                logger.error(f"Immobile già esistente: {property_obj.property_id}")
                raise ValueError(f"Property {property_obj.property_id} already exists")
            logger.exception("Errore creazione immobile")
            raise
    
    async def get_by_id(self, property_id: str) -> Optional[Property]:
        """
        Recupera un immobile per ID.
        
        Args:
            property_id: ID univoco immobile
            
        Returns:
            Property se trovato, None altrimenti
        """
        try:
            response = self.table.get_item(
                Key={
                    'PK': f"PROPERTY#{property_id}",
                    'SK': 'METADATA'
                }
            )
            
            if 'Item' not in response:
                logger.warning(f"Immobile non trovato: {property_id}")
                return None
            
            item = response['Item']
            
            # Ricostruisci oggetto Property da DynamoDB item
            property_dict = {
                'property_id': item['PropertyId'],
                'address': item['Address'],
                'property_type': item['PropertyType'],
                'surface_sqm': float(item['SurfaceSqm']),
                'construction_year': item['ConstructionYear'],
                'condition': item['Condition'],
                'rooms': item['Rooms'],
                'bathrooms': item['Bathrooms'],
                'floor': item.get('Floor'),
                'has_elevator': item.get('HasElevator', False),
                'has_parking': item.get('HasParking', False),
                'has_garden': item.get('HasGarden', False),
                'has_terrace': item.get('HasTerrace', False),
                'created_at': item['CreatedAt'],
                'updated_at': item['UpdatedAt'],
            }
            
            return Property(**property_dict)
            
        except ClientError:
            logger.exception(f"Errore recupero immobile: {property_id}")
            raise
    
    async def update(self, property_id: str, updates: Dict) -> Property:
        """
        Aggiorna un immobile esistente.
        
        Args:
            property_id: ID immobile da aggiornare
            updates: Dizionario con campi da aggiornare
            
        Returns:
            Property aggiornato
            
        Raises:
            ValueError: Se l'immobile non esiste
        """
        try:
            # Costruisci UpdateExpression
            update_expr = "SET UpdatedAt = :updated_at"
            expr_attr_values = {':updated_at': datetime.utcnow().isoformat()}
            
            # Aggiungi campi da aggiornare
            for key, value in updates.items():
                attr_name = f"#{key}"
                attr_value = f":{key}"
                update_expr += f", {attr_name} = {attr_value}"
                expr_attr_values[attr_value] = value
            
            response = self.table.update_item(
                Key={
                    'PK': f"PROPERTY#{property_id}",
                    'SK': 'METADATA'
                },
                UpdateExpression=update_expr,
                ExpressionAttributeNames={f"#{k}": k for k in updates.keys()},
                ExpressionAttributeValues=expr_attr_values,
                ConditionExpression='attribute_exists(PK)',
                ReturnValues='ALL_NEW'
            )
            
            logger.info(f"Immobile aggiornato: {property_id}")
            
            # Ricostruisci Property da response
            # (implementazione simile a get_by_id)
            return await self.get_by_id(property_id)
            
        except ClientError as e:
            if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
                logger.error(f"Immobile non trovato per update: {property_id}")
                raise ValueError(f"Property {property_id} not found")
            logger.exception(f"Errore update immobile: {property_id}")
            raise
    
    async def delete(self, property_id: str) -> bool:
        """
        Elimina un immobile (soft delete).
        
        Args:
            property_id: ID immobile da eliminare
            
        Returns:
            True se eliminato con successo
        """
        try:
            # Soft delete: aggiungi flag Deleted
            self.table.update_item(
                Key={
                    'PK': f"PROPERTY#{property_id}",
                    'SK': 'METADATA'
                },
                UpdateExpression='SET Deleted = :true, DeletedAt = :now',
                ExpressionAttributeValues={
                    ':true': True,
                    ':now': datetime.utcnow().isoformat()
                },
                ConditionExpression='attribute_exists(PK)'
            )
            
            logger.info(f"Immobile eliminato (soft): {property_id}")
            return True
            
        except ClientError as e:
            if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
                logger.warning(f"Immobile non trovato per delete: {property_id}")
                return False
            logger.exception(f"Errore delete immobile: {property_id}")
            raise
    
    async def list_properties(
        self,
        limit: int = 20,
        last_evaluated_key: Optional[Dict] = None,
        filters: Optional[Dict] = None
    ) -> tuple[List[Property], Optional[Dict]]:
        """
        Lista immobili con paginazione.
        
        Args:
            limit: Numero massimo risultati per pagina
            last_evaluated_key: Chiave per paginazione
            filters: Filtri opzionali (city, type, etc.)
            
        Returns:
            Tupla (lista properties, chiave paginazione successiva)
        """
        try:
            scan_kwargs = {
                'Limit': limit,
                'FilterExpression': Attr('EntityType').eq('Property') & Attr('Deleted').not_exists()
            }
            
            if last_evaluated_key:
                scan_kwargs['ExclusiveStartKey'] = last_evaluated_key
            
            # Aggiungi filtri se presenti
            if filters:
                if 'city' in filters:
                    scan_kwargs['FilterExpression'] &= Attr('Address.city').eq(filters['city'])
                if 'property_type' in filters:
                    scan_kwargs['FilterExpression'] &= Attr('PropertyType').eq(filters['property_type'])
            
            response = self.table.scan(**scan_kwargs)
            
            # Converti items in Property objects
            properties = []
            for item in response.get('Items', []):
                try:
                    property_dict = {
                        'property_id': item['PropertyId'],
                        'address': item['Address'],
                        'property_type': item['PropertyType'],
                        'surface_sqm': float(item['SurfaceSqm']),
                        'construction_year': item['ConstructionYear'],
                        'condition': item['Condition'],
                        'rooms': item['Rooms'],
                        'bathrooms': item['Bathrooms'],
                        'floor': item.get('Floor'),
                        'has_elevator': item.get('HasElevator', False),
                        'has_parking': item.get('HasParking', False),
                        'has_garden': item.get('HasGarden', False),
                        'has_terrace': item.get('HasTerrace', False),
                        'created_at': item['CreatedAt'],
                        'updated_at': item['UpdatedAt'],
                    }
                    properties.append(Property(**property_dict))
                except Exception as e:
                    logger.warning(f"Errore parsing property item: {e}")
                    continue
            
            next_key = response.get('LastEvaluatedKey')
            
            logger.info(f"Lista properties recuperata: {len(properties)} items")
            return properties, next_key
            
        except ClientError:
            logger.exception("Errore lista properties")
            raise
    
    async def query_by_city(
        self,
        city: str,
        limit: int = 20
    ) -> List[Property]:
        """
        Query immobili per città usando GSI.
        
        Args:
            city: Nome città
            limit: Numero massimo risultati
            
        Returns:
            Lista di Property
        """
        try:
            response = self.table.query(
                IndexName='GSI1',
                KeyConditionExpression=Key('GSI1PK').eq(f"CITY#{city}"),
                Limit=limit
            )
            
            # Converti in Property objects (logica simile a list_properties)
            properties = []
            for item in response.get('Items', []):
                # Parsing logic...
                pass
            
            logger.info(f"Query by city '{city}': {len(properties)} results")
            return properties
            
        except ClientError:
            logger.exception(f"Errore query by city: {city}")
            raise


class ValuationRepository(DynamoDBRepository):
    """
    Repository per gestione valutazioni immobili.
    
    Salva valutazioni come item separati nella stessa tabella con:
    - PK = PROPERTY#{property_id}
    - SK = VALUATION#{timestamp}
    """
    
    async def create_valuation(self, valuation: Valuation) -> Valuation:
        """
        Salva una nuova valutazione.
        
        Args:
            valuation: Oggetto Valuation
            
        Returns:
            Valuation salvato
        """
        try:
            timestamp = datetime.utcnow().isoformat()
            
            item = {
                'PK': f"PROPERTY#{valuation.property_id}",
                'SK': f"VALUATION#{timestamp}",
                'EntityType': 'Valuation',
                'ValuationId': valuation.valuation_id,
                'PropertyId': valuation.property_id,
                'EstimatedValue': Decimal(str(valuation.estimated_value)),
                'PricePerSqm': Decimal(str(valuation.price_per_sqm)),
                'Methodology': valuation.methodology,
                'ConfidenceLevel': Decimal(str(valuation.confidence_level)),
                'ValuationDate': timestamp,
                'CreatedAt': timestamp,
            }
            
            self.table.put_item(Item=item)
            
            logger.info(f"Valutazione creata: {valuation.valuation_id} per property {valuation.property_id}")
            return valuation
            
        except ClientError:
            logger.exception("Errore creazione valutazione")
            raise
    
    async def get_valuations_for_property(
        self,
        property_id: str,
        limit: int = 10
    ) -> List[Valuation]:
        """
        Recupera storico valutazioni per un immobile.
        
        Args:
            property_id: ID immobile
            limit: Numero massimo valutazioni da recuperare
            
        Returns:
            Lista valutazioni ordinate per data (più recenti prime)
        """
        try:
            response = self.table.query(
                KeyConditionExpression=Key('PK').eq(f"PROPERTY#{property_id}") & 
                                     Key('SK').begins_with('VALUATION#'),
                ScanIndexForward=False,  # Ordine decrescente (più recenti prima)
                Limit=limit
            )
            
            valuations = []
            # Parse items to Valuation objects
            # ...
            
            logger.info(f"Recuperate {len(valuations)} valutazioni per property {property_id}")
            return valuations
            
        except ClientError:
            logger.exception(f"Errore recupero valutazioni per property: {property_id}")
            raise


class RiskAssessmentRepository(DynamoDBRepository):
    """Repository per valutazioni rischio."""
    
    async def create_risk_assessment(self, risk: RiskAssessment) -> RiskAssessment:
        """Salva valutazione rischio"""
        try:
            timestamp = datetime.utcnow().isoformat()
            
            item = {
                'PK': f"PROPERTY#{risk.property_id}",
                'SK': f"RISK#{timestamp}",
                'EntityType': 'RiskAssessment',
                'AssessmentId': risk.assessment_id,
                'PropertyId': risk.property_id,
                'SeismicRisk': risk.seismic_risk,
                'SeismicZone': risk.seismic_zone,
                'HydrogeologicalRisk': risk.hydrogeological_risk,
                'EnvironmentalRisk': risk.environmental_risk,
                'OverallRiskScore': Decimal(str(risk.overall_risk_score)),
                'AssessmentDate': timestamp,
            }
            
            self.table.put_item(Item=item)
            
            logger.info(f"Risk assessment creato: {risk.assessment_id}")
            return risk
            
        except ClientError:
            logger.exception("Errore creazione risk assessment")
            raise
    
    async def get_latest_risk_assessment(self, property_id: str) -> Optional[RiskAssessment]:
        """Recupera l'ultima valutazione rischio per un immobile"""
        try:
            response = self.table.query(
                KeyConditionExpression=Key('PK').eq(f"PROPERTY#{property_id}") & 
                                     Key('SK').begins_with('RISK#'),
                ScanIndexForward=False,
                Limit=1
            )
            
            if not response.get('Items'):
                return None
            
            # Parse first item to RiskAssessment
            # ...
            
            return None  # Placeholder
            
        except ClientError:
            logger.exception(f"Errore recupero risk assessment: {property_id}")
            raise
