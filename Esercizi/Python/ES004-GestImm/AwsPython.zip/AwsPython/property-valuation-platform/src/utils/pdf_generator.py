"""
Utility per generazione PDF reports con ReportLab.

Genera report professionali per valutazioni immobiliari
con grafici, tabelle, logo, header/footer.
"""

import os
from datetime import datetime
from decimal import Decimal
from typing import Dict, Any, Optional, List
from io import BytesIO

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, Image, KeepTogether
)
from reportlab.lib.enums import TA_CENTER, TA_RIGHT, TA_LEFT
from reportlab.pdfgen import canvas

from aws_lambda_powertools import Logger

logger = Logger()


class PDFGenerator:
    """Generatore PDF per report valutazioni immobiliari."""
    
    def __init__(self):
        self.styles = getSampleStyleSheet()
        self._setup_custom_styles()
        
        # Dimensioni pagina A4
        self.page_width = A4[0]
        self.page_height = A4[1]
    
    def _setup_custom_styles(self):
        """Setup stili personalizzati."""
        # Titolo principale
        self.styles.add(ParagraphStyle(
            name='CustomTitle',
            parent=self.styles['Heading1'],
            fontSize=24,
            textColor=colors.HexColor('#1a1a1a'),
            spaceAfter=30,
            alignment=TA_CENTER,
            fontName='Helvetica-Bold'
        ))
        
        # Sottotitolo
        self.styles.add(ParagraphStyle(
            name='CustomSubtitle',
            parent=self.styles['Heading2'],
            fontSize=16,
            textColor=colors.HexColor('#4a4a4a'),
            spaceAfter=12,
            fontName='Helvetica-Bold'
        ))
        
        # Sezione
        self.styles.add(ParagraphStyle(
            name='SectionTitle',
            parent=self.styles['Heading3'],
            fontSize=14,
            textColor=colors.HexColor('#2c5aa0'),
            spaceAfter=12,
            spaceBefore=20,
            fontName='Helvetica-Bold'
        ))
        
        # Info box
        self.styles.add(ParagraphStyle(
            name='InfoBox',
            parent=self.styles['Normal'],
            fontSize=10,
            textColor=colors.HexColor('#666666'),
            leftIndent=10,
            rightIndent=10
        ))
        
        # Highlight
        self.styles.add(ParagraphStyle(
            name='Highlight',
            parent=self.styles['Normal'],
            fontSize=18,
            textColor=colors.HexColor('#2c5aa0'),
            alignment=TA_CENTER,
            fontName='Helvetica-Bold',
            spaceAfter=20
        ))
    
    def _add_header_footer(self, canvas_obj, doc):
        """Aggiungi header e footer a ogni pagina."""
        canvas_obj.saveState()
        
        # Header
        canvas_obj.setFillColor(colors.HexColor('#2c5aa0'))
        canvas_obj.rect(0, self.page_height - 2*cm, self.page_width, 2*cm, fill=True)
        
        canvas_obj.setFillColor(colors.white)
        canvas_obj.setFont('Helvetica-Bold', 16)
        canvas_obj.drawString(
            2*cm, 
            self.page_height - 1.5*cm,
            "Valuation Report"
        )
        
        # Footer
        canvas_obj.setFillColor(colors.HexColor('#cccccc'))
        canvas_obj.setFont('Helvetica', 8)
        canvas_obj.drawString(
            2*cm,
            1*cm,
            f"Generato il {datetime.now().strftime('%d/%m/%Y %H:%M')}"
        )
        
        # Numero pagina
        canvas_obj.drawRightString(
            self.page_width - 2*cm,
            1*cm,
            f"Pagina {doc.page}"
        )
        
        canvas_obj.restoreState()
    
    def generate_valuation_report(
        self,
        property_data: Dict[str, Any],
        valuation_data: Dict[str, Any],
        risk_assessment: Optional[Dict[str, Any]] = None
    ) -> BytesIO:
        """
        Genera report PDF completo per valutazione immobile.
        
        Args:
            property_data: Dati immobile
            valuation_data: Dati valutazione
            risk_assessment: Assessment rischi (opzionale)
        
        Returns:
            BytesIO: Buffer contenente PDF
        """
        logger.info(f"Generazione PDF report per property {property_data.get('id')}")
        
        buffer = BytesIO()
        
        # Crea documento
        doc = SimpleDocTemplate(
            buffer,
            pagesize=A4,
            rightMargin=2*cm,
            leftMargin=2*cm,
            topMargin=3*cm,
            bottomMargin=2*cm
        )
        
        # Contenuto
        story = []
        
        # 1. Titolo e info generali
        story.extend(self._build_title_section(property_data, valuation_data))
        
        # 2. Dettagli immobile
        story.extend(self._build_property_section(property_data))
        
        # 3. Valutazione
        story.extend(self._build_valuation_section(valuation_data))
        
        # 4. Comparabili (se disponibili)
        if valuation_data.get('comparable_properties'):
            story.extend(self._build_comparables_section(valuation_data))
        
        # 5. Risk Assessment (se disponibile)
        if risk_assessment:
            story.extend(self._build_risk_section(risk_assessment))
        
        # 6. Note e disclaimer
        story.extend(self._build_footer_section(valuation_data))
        
        # Build PDF
        doc.build(story, onFirstPage=self._add_header_footer, onLaterPages=self._add_header_footer)
        
        buffer.seek(0)
        logger.info("PDF report generato con successo")
        return buffer
    
    def _build_title_section(
        self,
        property_data: Dict[str, Any],
        valuation_data: Dict[str, Any]
    ) -> List:
        """Sezione titolo."""
        elements = []
        
        # Titolo
        title = Paragraph(
            "PERIZIA DI VALUTAZIONE IMMOBILIARE",
            self.styles['CustomTitle']
        )
        elements.append(title)
        elements.append(Spacer(1, 0.5*cm))
        
        # Info documento
        address = property_data.get('address', {})
        doc_info = f"""
        <b>Immobile:</b> {address.get('street', 'N/A')}, {address.get('city', 'N/A')}<br/>
        <b>Data Valutazione:</b> {valuation_data.get('valuation_date', 'N/A')[:10]}<br/>
        <b>Metodologia:</b> {valuation_data.get('methodology', 'N/A').title()}<br/>
        <b>Rif. Pratica:</b> {property_data.get('id', 'N/A')[:8]}
        """
        elements.append(Paragraph(doc_info, self.styles['InfoBox']))
        elements.append(Spacer(1, 1*cm))
        
        # Valore stimato (highlight)
        estimated_value = float(valuation_data.get('estimated_value', 0))
        value_text = f"€ {estimated_value:,.0f}"
        elements.append(Paragraph(
            f"<b>VALORE STIMATO: {value_text}</b>",
            self.styles['Highlight']
        ))
        elements.append(Spacer(1, 1*cm))
        
        return elements
    
    def _build_property_section(self, property_data: Dict[str, Any]) -> List:
        """Sezione dettagli immobile."""
        elements = []
        
        elements.append(Paragraph("DETTAGLI IMMOBILE", self.styles['SectionTitle']))
        
        # Tabella caratteristiche
        address = property_data.get('address', {})
        
        data = [
            ['Caratteristica', 'Valore'],
            ['Tipologia', property_data.get('property_type', 'N/A').title()],
            ['Superficie', f"{property_data.get('surface_sqm', 'N/A')} mq"],
            ['Locali', str(property_data.get('rooms', 'N/A'))],
            ['Bagni', str(property_data.get('bathrooms', 'N/A'))],
            ['Piano', str(property_data.get('floor', 'N/A'))],
            ['Anno Costruzione', str(property_data.get('construction_year', 'N/A'))],
            ['Condizione', property_data.get('condition', 'N/A').title()],
            ['Classe Energetica', property_data.get('energy_class', 'N/A')],
        ]
        
        # Features aggiuntive
        features = []
        if property_data.get('elevator'): features.append('Ascensore')
        if property_data.get('parking'): features.append('Posto auto')
        if property_data.get('garden'): features.append('Giardino')
        if property_data.get('terrace'): features.append('Terrazzo')
        
        if features:
            data.append(['Caratteristiche', ', '.join(features)])
        
        table = Table(data, colWidths=[8*cm, 8*cm])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#2c5aa0')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.white),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f5f5f5')]),
        ]))
        
        elements.append(table)
        elements.append(Spacer(1, 1*cm))
        
        return elements
    
    def _build_valuation_section(self, valuation_data: Dict[str, Any]) -> List:
        """Sezione valutazione."""
        elements = []
        
        elements.append(Paragraph("VALUTAZIONE", self.styles['SectionTitle']))
        
        estimated = float(valuation_data.get('estimated_value', 0))
        min_val = float(valuation_data.get('min_value', 0))
        max_val = float(valuation_data.get('max_value', 0))
        price_sqm = float(valuation_data.get('price_per_sqm', 0))
        confidence = float(valuation_data.get('confidence_level', 0)) * 100
        
        data = [
            ['Metrica', 'Valore'],
            ['Valore Stimato', f"€ {estimated:,.0f}"],
            ['Valore Minimo', f"€ {min_val:,.0f}"],
            ['Valore Massimo', f"€ {max_val:,.0f}"],
            ['Prezzo al mq', f"€ {price_sqm:,.0f}/mq"],
            ['Livello Confidenza', f"{confidence:.0f}%"],
            ['Metodologia', valuation_data.get('methodology', 'N/A').title()],
        ]
        
        table = Table(data, colWidths=[8*cm, 8*cm])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#2c5aa0')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.white),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f5f5f5')]),
        ]))
        
        elements.append(table)
        elements.append(Spacer(1, 0.5*cm))
        
        # Range grafico
        range_text = f"""
        <b>Range di valutazione:</b><br/>
        Il valore dell'immobile è compreso tra €{min_val:,.0f} e €{max_val:,.0f},
        con una stima più probabile di €{estimated:,.0f}.
        L'intervallo rappresenta una variazione di ±{((max_val-min_val)/2/estimated*100):.1f}%
        rispetto al valore stimato.
        """
        elements.append(Paragraph(range_text, self.styles['Normal']))
        elements.append(Spacer(1, 1*cm))
        
        return elements
    
    def _build_comparables_section(self, valuation_data: Dict[str, Any]) -> List:
        """Sezione immobili comparabili."""
        elements = []
        
        elements.append(Paragraph("IMMOBILI COMPARABILI", self.styles['SectionTitle']))
        
        comparables = valuation_data.get('comparable_properties', [])
        
        if comparables:
            data = [['Indirizzo', 'Superficie', 'Prezzo/mq', 'Valore Totale']]
            
            for comp in comparables[:5]:  # Max 5
                data.append([
                    comp.get('address', 'N/A'),
                    f"{comp.get('surface_sqm', 0)} mq",
                    f"€{comp.get('price_per_sqm', 0):,.0f}",
                    f"€{comp.get('total_value', 0):,.0f}"
                ])
            
            table = Table(data, colWidths=[6*cm, 3*cm, 3.5*cm, 3.5*cm])
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#2c5aa0')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 9),
                ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f5f5f5')]),
            ]))
            
            elements.append(table)
        else:
            elements.append(Paragraph(
                "Nessun immobile comparabile disponibile.",
                self.styles['Normal']
            ))
        
        elements.append(Spacer(1, 1*cm))
        return elements
    
    def _build_risk_section(self, risk_data: Dict[str, Any]) -> List:
        """Sezione valutazione rischi."""
        elements = []
        
        elements.append(Paragraph("VALUTAZIONE RISCHI", self.styles['SectionTitle']))
        
        risk_map = {
            'low': ('Basso', colors.green),
            'medium': ('Medio', colors.orange),
            'high': ('Alto', colors.red),
            'very_high': ('Molto Alto', colors.darkred)
        }
        
        seismic = risk_data.get('seismic_risk', 'N/A')
        hydro = risk_data.get('hydrogeological_risk', 'N/A')
        env = risk_data.get('environmental_risk', 'N/A')
        overall = risk_data.get('overall_risk_score', 0)
        
        data = [
            ['Tipo Rischio', 'Livello'],
            ['Rischio Sismico', risk_map.get(seismic, ('N/A', colors.grey))[0]],
            ['Rischio Idrogeologico', risk_map.get(hydro, ('N/A', colors.grey))[0]],
            ['Rischio Ambientale', risk_map.get(env, ('N/A', colors.grey))[0]],
            ['Score Complessivo', f"{overall:.2f}"],
        ]
        
        table = Table(data, colWidths=[10*cm, 6*cm])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#2c5aa0')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f5f5f5')]),
        ]))
        
        elements.append(table)
        elements.append(Spacer(1, 1*cm))
        
        return elements
    
    def _build_footer_section(self, valuation_data: Dict[str, Any]) -> List:
        """Sezione disclaimer."""
        elements = []
        
        elements.append(Paragraph("NOTE E DISCLAIMER", self.styles['SectionTitle']))
        
        disclaimer = """
        <b>Metodologia di valutazione:</b><br/>
        La presente perizia è stata effettuata utilizzando il metodo comparativo di mercato,
        analizzando immobili con caratteristiche similari nella medesima zona.<br/><br/>
        
        <b>Limitazioni:</b><br/>
        - La valutazione è basata sui dati forniti e sulle condizioni di mercato attuali<br/>
        - Variazioni significative del mercato possono influenzare il valore<br/>
        - Si consiglia ispezione fisica dell'immobile per conferma<br/>
        - La valutazione ha validità di 6 mesi dalla data di emissione<br/><br/>
        
        <b>Confidenzialità:</b><br/>
        Il presente documento è riservato e destinato esclusivamente al committente.
        Qualsiasi riproduzione o diffusione non autorizzata è vietata.
        """
        
        elements.append(Paragraph(disclaimer, self.styles['Normal']))
        
        return elements


def get_pdf_generator() -> PDFGenerator:
    """Factory per PDFGenerator (singleton)."""
    return PDFGenerator()
