# Cache Service Utility

Servizio di astrazione per gestione cache con Redis/ElastiCache.
"""

import json
import os
from typing import Any, Optional
from decimal import Decimal

import redis
from aws_lambda_powertools import Logger

logger = Logger()


class DecimalEncoder(json.JSONEncoder):
    """JSON encoder che gestisce Decimal"""
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super().default(obj)


class CacheService:
    """
    Servizio per caching con Redis.
    
    Pattern supportati:
    - Cache-aside (lazy loading)
    - Write-through
    - TTL differenziati per tipo dato
    """
    
    def __init__(self):
        """
        Inizializza connessione Redis.
        
        Environment Variables:
            REDIS_HOST: Endpoint ElastiCache
            REDIS_PORT: Porta Redis (default: 6379)
            REDIS_DB: Database number (default: 0)
            REDIS_PASSWORD: Password (opzionale)
        """
        redis_host = os.environ.get('REDIS_HOST')
        redis_port = int(os.environ.get('REDIS_PORT', '6379'))
        redis_db = int(os.environ.get('REDIS_DB', '0'))
        redis_password = os.environ.get('REDIS_PASSWORD')
        
        if not redis_host:
            logger.warning("REDIS_HOST non configurato - cache disabilitata")
            self.client = None
            return
        
        try:
            self.client = redis.Redis(
                host=redis_host,
                port=redis_port,
                db=redis_db,
                password=redis_password,
                decode_responses=True,
                socket_connect_timeout=2,
                socket_timeout=2
            )
            
            # Test connessione
            self.client.ping()
            logger.info(f"Redis connesso: {redis_host}:{redis_port}")
            
        except Exception as e:
            logger.error(f"Errore connessione Redis: {e}")
            self.client = None
    
    def get(self, key: str) -> Optional[str]:
        """
        Recupera valore dalla cache.
        
        Args:
            key: Cache key
        
        Returns:
            Valore (JSON string) se presente, None altrimenti
        """
        if not self.client:
            return None
        
        try:
            value = self.client.get(key)
            if value:
                logger.debug(f"Cache HIT: {key}")
            return value
        except Exception as e:
            logger.error(f"Errore recupero cache per {key}: {e}")
            return None
    
    def set(
        self,
        key: str,
        value: Any,
        ttl: int = 3600
    ) -> bool:
        """
        Salva valore in cache.
        
        Args:
            key: Cache key
            value: Valore da cachare (sarà convertito in JSON)
            ttl: Time-to-live in secondi (default: 1 ora)
        
        Returns:
            True se successo, False altrimenti
        """
        if not self.client:
            return False
        
        try:
            # Converti a JSON se necessario
            if isinstance(value, str):
                json_value = value
            else:
                json_value = json.dumps(value, cls=DecimalEncoder)
            
            result = self.client.setex(
                name=key,
                time=ttl,
                value=json_value
            )
            
            logger.debug(f"Cache SET: {key} (TTL: {ttl}s)")
            return bool(result)
            
        except Exception as e:
            logger.error(f"Errore salvataggio cache per {key}: {e}")
            return False
    
    def delete(self, key: str) -> bool:
        """
        Elimina chiave dalla cache.
        
        Args:
            key: Cache key da eliminare
        
        Returns:
            True se eliminata, False altrimenti
        """
        if not self.client:
            return False
        
        try:
            result = self.client.delete(key)
            logger.debug(f"Cache DELETE: {key}")
            return result > 0
        except Exception as e:
            logger.error(f"Errore eliminazione cache per {key}: {e}")
            return False
    
    def invalidate_pattern(self, pattern: str) -> int:
        """
        Invalida tutte le chiavi che matchano un pattern.
        
        Args:
            pattern: Pattern Redis (es: "property:*")
        
        Returns:
            Numero di chiavi eliminate
        """
        if not self.client:
            return 0
        
        try:
            keys = self.client.keys(pattern)
            if keys:
                deleted = self.client.delete(*keys)
                logger.info(f"Cache INVALIDATE: {pattern} ({deleted} chiavi)")
                return deleted
            return 0
        except Exception as e:
            logger.error(f"Errore invalidazione pattern {pattern}: {e}")
            return 0
    
    def get_ttl(self, key: str) -> Optional[int]:
        """
        Recupera TTL rimanente per una chiave.
        
        Args:
            key: Cache key
        
        Returns:
            TTL in secondi, None se chiave non esiste
        """
        if not self.client:
            return None
        
        try:
            ttl = self.client.ttl(key)
            if ttl == -2:  # Chiave non esiste
                return None
            if ttl == -1:  # Chiave senza TTL
                return -1
            return ttl
        except Exception as e:
            logger.error(f"Errore recupero TTL per {key}: {e}")
            return None
    
    def increment(self, key: str, amount: int = 1) -> Optional[int]:
        """
        Incrementa contatore atomicamente.
        
        Utile per rate limiting, conteggi, etc.
        
        Args:
            key: Cache key
            amount: Quantità da incrementare
        
        Returns:
            Nuovo valore dopo incremento
        """
        if not self.client:
            return None
        
        try:
            return self.client.incrby(key, amount)
        except Exception as e:
            logger.error(f"Errore incremento per {key}: {e}")
            return None
    
    def close(self):
        """Chiude connessione Redis"""
        if self.client:
            self.client.close()
            logger.debug("Connessione Redis chiusa")


# Singleton instance
_cache_instance = None


def get_cache() -> CacheService:
    """
    Ottiene istanza singleton del cache service.
    
    Returns:
        CacheService instance
    """
    global _cache_instance
    if _cache_instance is None:
        _cache_instance = CacheService()
    return _cache_instance
