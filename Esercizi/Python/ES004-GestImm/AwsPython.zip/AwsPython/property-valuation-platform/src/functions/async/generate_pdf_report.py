"""
Lambda function per generazione PDF report.

Triggered by: SQS queue (pdf-generation-queue) o EventBridge
Genera PDF report professionale per valutazione immobile
e salva su S3.
"""

import json
import os
from datetime import datetime
from typing import Dict, Any
from uuid import uuid4

import boto3
from aws_lambda_powertools import Logger, Tracer, Metrics
from aws_lambda_powertools.metrics import MetricUnit

from src.repositories.dynamodb_repository import PropertyRepository, ValuationRepository, RiskAssessmentRepository
from src.utils.pdf_generator import get_pdf_generator

logger = Logger()
tracer = Tracer()
metrics = Metrics()

# Configurazione
TABLE_NAME = os.environ.get('TABLE_NAME')
BUCKET_NAME = os.environ.get('DOCUMENTS_BUCKET')
REGION = os.environ.get('AWS_REGION', 'eu-west-1')

property_repo = PropertyRepository(table_name=TABLE_NAME)
valuation_repo = ValuationRepository(table_name=TABLE_NAME)
risk_repo = RiskAssessmentRepository(table_name=TABLE_NAME)
pdf_generator = get_pdf_generator()
s3_client = boto3.client('s3')


@tracer.capture_method
def generate_pdf_report(
    property_id: str,
    valuation_id: str,
    include_risk: bool = True
) -> Dict[str, Any]:
    """
    Genera PDF report per valutazione immobile.
    
    Args:
        property_id: ID immobile
        valuation_id: ID valutazione
        include_risk: Include risk assessment nel report
    
    Returns:
        Dict con info sul PDF generato
        
    Raises:
        ValueError: Se dati mancanti
        Exception: Errori generazione o upload
    """
    logger.info(
        f"Generazione PDF report",
        extra={
            "property_id": property_id,
            "valuation_id": valuation_id
        }
    )
    
    start_time = datetime.utcnow()
    
    # 1. Recupera dati immobile
    property_data = property_repo.get_by_id(property_id)
    if not property_data:
        raise ValueError(f"Immobile {property_id} non trovato")
    
    # 2. Recupera valutazione
    valuations = valuation_repo.get_valuations_for_property(property_id)
    valuation_data = None
    
    for v in valuations:
        if str(v.get('valuation_id')) == valuation_id:
            valuation_data = v
            break
    
    if not valuation_data:
        raise ValueError(f"Valutazione {valuation_id} non trovata")
    
    # 3. Recupera risk assessment (opzionale)
    risk_data = None
    if include_risk:
        risk_data = risk_repo.get_latest_risk_assessment(property_id)
        logger.info(f"Risk assessment {'trovato' if risk_data else 'non disponibile'}")
    
    # 4. Genera PDF
    logger.info("Generazione PDF in corso...")
    pdf_buffer = pdf_generator.generate_valuation_report(
        property_data=property_data,
        valuation_data=valuation_data,
        risk_assessment=risk_data
    )
    
    # 5. Upload su S3
    file_key = f"reports/{property_id}/{valuation_id}.pdf"
    
    logger.info(f"Upload PDF su S3: {BUCKET_NAME}/{file_key}")
    
    s3_client.put_object(
        Bucket=BUCKET_NAME,
        Key=file_key,
        Body=pdf_buffer.getvalue(),
        ContentType='application/pdf',
        Metadata={
            'property_id': property_id,
            'valuation_id': valuation_id,
            'generated_at': datetime.utcnow().isoformat(),
            'include_risk': str(include_risk)
        },
        ServerSideEncryption='AES256',
        StorageClass='INTELLIGENT_TIERING'
    )
    
    # Genera presigned URL (valido 7 giorni)
    presigned_url = s3_client.generate_presigned_url(
        'get_object',
        Params={
            'Bucket': BUCKET_NAME,
            'Key': file_key
        },
        ExpiresIn=7 * 24 * 3600  # 7 giorni
    )
    
    generation_time = (datetime.utcnow() - start_time).total_seconds()
    
    logger.info(f"PDF generato con successo in {generation_time:.2f}s")
    
    # Metriche
    metrics.add_metric(name="PDFGenerated", unit=MetricUnit.Count, value=1)
    metrics.add_metric(name="PDFGenerationTime", unit=MetricUnit.Seconds, value=generation_time)
    
    return {
        'property_id': property_id,
        'valuation_id': valuation_id,
        's3_bucket': BUCKET_NAME,
        's3_key': file_key,
        'download_url': presigned_url,
        'generated_at': datetime.utcnow().isoformat(),
        'generation_time_seconds': generation_time,
        'file_size_bytes': len(pdf_buffer.getvalue())
    }


@logger.inject_lambda_context
@tracer.capture_lambda_handler
@metrics.log_metrics(capture_cold_start_metric=True)
def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Handler Lambda per generazione PDF.
    
    Gestisce eventi da:
    1. SQS Queue (messaggi asincroni)
    2. EventBridge (eventi ValuationCompleted)
    3. API Gateway (richieste dirette)
    """
    logger.info("PDF generation Lambda triggered", extra={"event": event})
    
    try:
        # Gestione eventi SQS
        if 'Records' in event:
            results = []
            
            for record in event['Records']:
                if 'body' in record:
                    # SQS message
                    message = json.loads(record['body'])
                    
                    # Può contenere EventBridge event nested
                    if 'detail' in message:
                        detail = message['detail']
                    else:
                        detail = message
                    
                    property_id = detail.get('property_id')
                    valuation_id = detail.get('valuation_id')
                    include_risk = detail.get('include_risk', True)
                    
                    result = generate_pdf_report(
                        property_id=property_id,
                        valuation_id=valuation_id,
                        include_risk=include_risk
                    )
                    
                    results.append(result)
                    logger.info(f"PDF generato per SQS message: {result['s3_key']}")
            
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'message': f'{len(results)} PDF generati con successo',
                    'results': results
                }, default=str)
            }
        
        # Gestione eventi EventBridge diretti
        elif 'detail-type' in event:
            detail = event['detail']
            
            property_id = detail.get('property_id')
            valuation_id = detail.get('valuation_id')
            include_risk = detail.get('include_risk', True)
            
            result = generate_pdf_report(
                property_id=property_id,
                valuation_id=valuation_id,
                include_risk=include_risk
            )
            
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'message': 'PDF generato con successo',
                    'data': result
                }, default=str)
            }
        
        # Gestione richiesta diretta (API Gateway o test)
        else:
            body = event.get('body')
            if isinstance(body, str):
                body = json.loads(body)
            elif body is None:
                body = event
            
            property_id = body.get('property_id')
            valuation_id = body.get('valuation_id')
            include_risk = body.get('include_risk', True)
            
            if not property_id or not valuation_id:
                return {
                    'statusCode': 400,
                    'body': json.dumps({
                        'error': 'BAD_REQUEST',
                        'message': 'property_id e valuation_id sono obbligatori'
                    })
                }
            
            result = generate_pdf_report(
                property_id=property_id,
                valuation_id=valuation_id,
                include_risk=include_risk
            )
            
            return {
                'statusCode': 200,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({
                    'message': 'PDF generato con successo',
                    'data': result
                }, default=str)
            }
    
    except ValueError as e:
        logger.error(f"Validation error: {str(e)}")
        metrics.add_metric(name="PDFGenerationError", unit=MetricUnit.Count, value=1)
        
        return {
            'statusCode': 404,
            'body': json.dumps({
                'error': 'NOT_FOUND',
                'message': str(e)
            })
        }
    
    except Exception as e:
        logger.exception("Errore generazione PDF")
        metrics.add_metric(name="PDFGenerationError", unit=MetricUnit.Count, value=1)
        
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': 'PDF_GENERATION_ERROR',
                'message': 'Errore durante la generazione del PDF',
                'details': str(e) if os.environ.get('ENVIRONMENT') == 'dev' else None
            })
        }
