"""
Lambda function per creare un nuovo immobile.

Endpoint: POST /properties
Gestisce la creazione di un nuovo immobile con validazione completa,
salvataggio su DynamoDB e pubblicazione evento PropertyCreated.
"""

import json
import os
from datetime import datetime
from typing import Dict, Any

import boto3
from aws_lambda_powertools import Logger, Tracer, Metrics
from aws_lambda_powertools.event_handler import APIGatewayRestResolver
from aws_lambda_powertools.logging import correlation_paths
from aws_lambda_powertools.metrics import MetricUnit
from pydantic import ValidationError

from src.models import Property, ErrorResponse
from src.repositories.dynamodb_repository import PropertyRepository

# Inizializzazione powertools
logger = Logger()
tracer = Tracer()
metrics = Metrics()
app = APIGatewayRestResolver()

# Configurazione
TABLE_NAME = os.environ.get('TABLE_NAME')
EVENT_BUS_NAME = os.environ.get('EVENT_BUS_NAME', 'default')

# Clients AWS
eventbridge = boto3.client('eventbridge')
property_repo = PropertyRepository(table_name=TABLE_NAME)


@app.post("/properties")
@tracer.capture_method
def create_property() -> Dict[str, Any]:
    """
    Crea un nuovo immobile.
    
    Request Body:
        {
            "address": {
                "street": "Via Roma 123",
                "city": "Milano",
                "province": "MI",
                "postal_code": "20100"
            },
            "property_type": "apartment",
            "surface_sqm": 85.5,
            "construction_year": 2010,
            "condition": "good",
            "rooms": 3,
            "bathrooms": 2,
            ...
        }
    
    Returns:
        201: Property creato con successo
        400: Errore validazione
        500: Errore server
    """
    try:
        # Parse request body
        body = app.current_event.json_body
        logger.info("Ricevuta richiesta creazione immobile", extra={"body": body})
        
        # Valida con Pydantic
        try:
            property_obj = Property(**body)
            logger.info(f"Validazione completata per immobile: {property_obj.property_id}")
        except ValidationError as e:
            logger.warning("Errore validazione input", extra={"errors": e.errors()})
            metrics.add_metric(name="ValidationError", unit=MetricUnit.Count, value=1)
            
            return {
                "statusCode": 400,
                "body": json.dumps({
                    "error": "VALIDATION_ERROR",
                    "message": "Dati immobile non validi",
                    "details": e.errors()
                })
            }
        
        # Salva su DynamoDB
        saved_property = property_repo.create(property_obj)
        logger.info(f"Immobile salvato: {saved_property.property_id}")
        
        # Pubblica evento PropertyCreated su EventBridge
        event_detail = {
            "property_id": saved_property.property_id,
            "property_type": saved_property.property_type,
            "city": saved_property.address.city,
            "created_at": saved_property.created_at.isoformat()
        }
        
        response = eventbridge.put_events(
            Entries=[
                {
                    'Source': 'property-valuation',
                    'DetailType': 'PropertyCreated',
                    'Detail': json.dumps(event_detail),
                    'EventBusName': EVENT_BUS_NAME
                }
            ]
        )
        
        logger.info(f"Evento PropertyCreated pubblicato", extra={"event_id": response['Entries'][0].get('EventId')})
        
        # Metriche
        metrics.add_metric(name="PropertyCreated", unit=MetricUnit.Count, value=1)
        metrics.add_dimension(name="PropertyType", value=saved_property.property_type)
        metrics.add_dimension(name="City", value=saved_property.address.city)
        
        # Response
        return {
            "statusCode": 201,
            "body": json.dumps({
                "property_id": saved_property.property_id,
                "message": "Immobile creato con successo",
                "data": saved_property.model_dump(mode='json')
            }, default=str)
        }
        
    except ValueError as e:
        # Immobile già esistente o altro errore validazione
        logger.error(f"Errore business logic: {str(e)}")
        metrics.add_metric(name="BusinessError", unit=MetricUnit.Count, value=1)
        
        return {
            "statusCode": 409,  # Conflict
            "body": json.dumps({
                "error": "CONFLICT",
                "message": str(e)
            })
        }
        
    except Exception as e:
        # Errore imprevisto
        logger.exception("Errore imprevisto durante creazione immobile")
        metrics.add_metric(name="UnexpectedError", unit=MetricUnit.Count, value=1)
        
        return {
            "statusCode": 500,
            "body": json.dumps({
                "error": "INTERNAL_ERROR",
                "message": "Errore interno del server",
                "details": str(e) if os.environ.get('ENVIRONMENT') == 'dev' else None
            })
        }


@logger.inject_lambda_context(correlation_id_path=correlation_paths.API_GATEWAY_REST)
@tracer.capture_lambda_handler
@metrics.log_metrics(capture_cold_start_metric=True)
def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Handler principale Lambda.
    
    Gestisce eventi API Gateway con logging, tracing e metriche automatiche.
    """
    return app.resolve(event, context)
