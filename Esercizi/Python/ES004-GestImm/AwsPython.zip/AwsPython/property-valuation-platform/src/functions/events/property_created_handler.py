"""
Event handler per evento PropertyCreated.

Gestisce le azioni post-creazione immobile:
1. Aggiornamento indici di ricerca
2. Invio notifica utente
3. Trigger valutazione automatica (opzionale)
"""

import json
import os
from typing import Dict, Any

import boto3
from aws_lambda_powertools import Logger, Tracer, Metrics
from aws_lambda_powertools.metrics import MetricUnit

logger = Logger()
tracer = Tracer()
metrics = Metrics()

# AWS clients
sqs = boto3.client('sqs')
dynamodb = boto3.resource('dynamodb')

NOTIFICATION_QUEUE_URL = os.environ.get('NOTIFICATION_QUEUE_URL')
TABLE_NAME = os.environ.get('TABLE_NAME')


@tracer.capture_lambda_handler
@logger.inject_lambda_context
@metrics.log_metrics
def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Handler evento PropertyCreated da EventBridge.
    
    Event structure:
        {
            "source": "property-valuation",
            "detail-type": "PropertyCreated",
            "detail": {
                "property_id": "uuid",
                "property_type": "apartment",
                "city": "Milano",
                "created_at": "2026-04-28T..."
            }
        }
    """
    try:
        detail = event.get('detail', {})
        property_id = detail.get('property_id')
        property_type = detail.get('property_type')
        city = detail.get('city')
        
        logger.info(
            f"Gestione evento PropertyCreated per immobile {property_id}",
            extra={"property_type": property_type, "city": city}
        )
        
        # 1. Aggiorna indici ricerca/cache
        logger.info("Aggiornamento indici ricerca...")
        # TODO: Implementare aggiornamento search index (OpenSearch/ElasticSearch)
        
        # 2. Invia notifica all'utente
        if NOTIFICATION_QUEUE_URL:
            notification_message = {
                "type": "property_created",
                "property_id": property_id,
                "message": f"Il tuo immobile è stato registrato con successo!",
                "template": "property_created_email",
                "data": {
                    "property_id": property_id,
                    "property_type": property_type,
                    "city": city
                }
            }
            
            sqs.send_message(
                QueueUrl=NOTIFICATION_QUEUE_URL,
                MessageBody=json.dumps(notification_message)
            )
            
            logger.info(f"Notifica inviata a coda per property {property_id}")
        
        # 3. Trigger valutazione automatica iniziale (opzionale)
        # Può essere schedulata dopo X ore/giorni
        
        # Metriche
        metrics.add_metric(name="PropertyCreatedEvent", unit=MetricUnit.Count, value=1)
        metrics.add_dimension(name="PropertyType", value=property_type)
        metrics.add_dimension(name="City", value=city)
        
        logger.info(f"Evento PropertyCreated gestito con successo per {property_id}")
        
        return {
            "statusCode": 200,
            "body": json.dumps({"message": "Event processed successfully"})
        }
        
    except Exception as e:
        logger.exception("Errore gestione evento PropertyCreated")
        metrics.add_metric(name="PropertyCreatedEventError", unit=MetricUnit.Count, value=1)
        raise  # Re-raise per DLQ
