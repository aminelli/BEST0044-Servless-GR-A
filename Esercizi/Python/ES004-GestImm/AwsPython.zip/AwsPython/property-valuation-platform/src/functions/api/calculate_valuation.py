"""
Lambda function per calcolo valutazione immobile.

Endpoint: POST /properties/{id}/valuations
Calcola il valore stimato di un immobile usando algoritmo comparativo
e pubblica evento ValuationCompleted.
"""

import json
import os
from datetime import datetime, timedelta
from decimal import Decimal
from typing import Dict, Any, List
from uuid import uuid4

import boto3
from aws_lambda_powertools import Logger, Tracer, Metrics
from aws_lambda_powertools.event_handler import APIGatewayRestResolver
from aws_lambda_powertools.metrics import MetricUnit

from src.models import Valuation, Property
from src.repositories.dynamodb_repository import PropertyRepository, ValuationRepository
from src.services.valuation_service import ValuationService

logger = Logger()
tracer = Tracer()
metrics = Metrics()
app = APIGatewayRestResolver()

# Configurazione
TABLE_NAME = os.environ.get('TABLE_NAME')
EVENT_BUS_NAME = os.environ.get('EVENT_BUS_NAME')

property_repo = PropertyRepository(table_name=TABLE_NAME)
valuation_repo = ValuationRepository(table_name=TABLE_NAME)
valuation_service = ValuationService(property_repo, valuation_repo)
eventbridge = boto3.client('eventbridge')


@app.post("/properties/<property_id>/valuations")
@tracer.capture_method
def calculate_valuation(property_id: str) -> Dict[str, Any]:
    """
    Calcola valutazione immobile.
    
    Algoritmo:
    1. Recupera immobile da DynamoDB
    2. Trova immobili comparabili nella stessa zona
    3. Calcola prezzo medio al mq
    4. Applica adjustment per caratteristiche specifiche
    5. Salva valutazione
    6. Pubblica evento ValuationCompleted
    
    Args:
        property_id: ID immobile da valutare
    
    Request Body (opzionale):
        {
            "methodology": "comparative",  // comparative, income, cost
            "force_refresh": false  // Force ricalcolo anche se valutazione recente esiste
        }
    
    Returns:
        201: Valutazione creata
        404: Immobile non trovato
        500: Errore calcolo
    """
    try:
        # Parse request body
        body = app.current_event.json_body or {}
        methodology = body.get('methodology', 'comparative')
        force_refresh = body.get('force_refresh', False)
        
        logger.info(
            f"Richiesta valutazione immobile: {property_id}",
            extra={"methodology": methodology}
        )
        
        # Verifica esistenza immobile
        property_obj = property_repo.get_by_id(property_id)
        
        if not property_obj:
            logger.warning(f"Immobile non trovato per valutazione: {property_id}")
            return {
                "statusCode": 404,
                "body": json.dumps({
                    "error": "NOT_FOUND",
                    "message": f"Immobile {property_id} non trovato"
                })
            }
        
        # Verifica se esiste valutazione recente (< 30 giorni)
        if not force_refresh:
            recent_valuations = valuation_repo.get_valuations_for_property(
                property_id,
                limit=1
            )
            if recent_valuations:
                latest = recent_valuations[0]
                age_days = (datetime.utcnow() - latest.valuation_date).days
                if age_days < 30:
                    logger.info(f"Valutazione recente trovata ({age_days} giorni)")
                    return {
                        "statusCode": 200,
                        "body": json.dumps({
                            "message": "Valutazione recente già disponibile",
                            "data": latest.model_dump(mode='json'),
                            "age_days": age_days
                        }, default=str)
                    }
        
        # Calcola nuova valutazione
        start_time = datetime.utcnow()
        
        valuation = valuation_service.calculate_valuation(
            property_obj,
            methodology=methodology
        )
        
        calculation_time = (datetime.utcnow() - start_time).total_seconds()
        
        logger.info(
            f"Valutazione calcolata: {valuation.estimated_value}€ "
            f"({valuation.price_per_sqm}€/mq) in {calculation_time:.2f}s"
        )
        
        # Salva valutazione in DynamoDB
        saved_valuation = valuation_repo.create_valuation(valuation)
        
        # Pubblica evento ValuationCompleted
        event_detail = {
            "valuation_id": str(valuation.valuation_id),
            "property_id": property_id,
            "estimated_value": float(valuation.estimated_value),
            "price_per_sqm": float(valuation.price_per_sqm),
            "methodology": methodology,
            "valuation_date": valuation.valuation_date.isoformat()
        }
        
        eventbridge.put_events(
            Entries=[
                {
                    'Source': 'property-valuation',
                    'DetailType': 'ValuationCompleted',
                    'Detail': json.dumps(event_detail, default=str),
                    'EventBusName': EVENT_BUS_NAME
                }
            ]
        )
        
        logger.info(f"Evento ValuationCompleted pubblicato per {property_id}")
        
        # Metriche
        metrics.add_metric(name="ValuationCalculated", unit=MetricUnit.Count, value=1)
        metrics.add_metric(name="ValuationTime", unit=MetricUnit.Seconds, value=calculation_time)
        metrics.add_dimension(name="Methodology", value=methodology)
        
        return {
            "statusCode": 201,
            "body": json.dumps({
                "message": "Valutazione completata con successo",
                "data": saved_valuation.model_dump(mode='json'),
                "calculation_time_seconds": calculation_time
            }, default=str)
        }
        
    except Exception as e:
        logger.exception(f"Errore calcolo valutazione per {property_id}")
        metrics.add_metric(name="ValuationError", unit=MetricUnit.Count, value=1)
        
        return {
            "statusCode": 500,
            "body": json.dumps({
                "error": "CALCULATION_ERROR",
                "message": "Errore calcolo valutazione",
                "details": str(e) if os.environ.get('ENVIRONMENT') == 'dev' else None
            })
        }


@logger.inject_lambda_context
@tracer.capture_lambda_handler
@metrics.log_metrics(capture_cold_start_metric=True)
def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """Handler principale Lambda"""
    return app.resolve(event, context)
