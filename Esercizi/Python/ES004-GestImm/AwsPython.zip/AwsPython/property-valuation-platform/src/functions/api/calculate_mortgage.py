"""
Lambda function per calcolo simulazione mutuo.

Endpoint: POST /mortgages/calculate
Calcola rate, piano di ammortamento, TAEG e TAN per un mutuo.
"""

import json
import os
from decimal import Decimal, ROUND_HALF_UP
from typing import Dict, Any
from uuid import uuid4
from datetime import datetime

from aws_lambda_powertools import Logger, Tracer, Metrics
from aws_lambda_powertools.event_handler import APIGatewayRestResolver
from aws_lambda_powertools.metrics import MetricUnit
from pydantic import ValidationError

from src.models import MortgageSimulation, MortgageType

logger = Logger()
tracer = Tracer()
metrics = Metrics()
app = APIGatewayRestResolver()


@app.post("/mortgages/calculate")
@tracer.capture_method
def calculate_mortgage() -> Dict[str, Any]:
    """
    Calcola simulazione mutuo.
    
    Formula rata mensile (francese - ammortamento alla francese):
    M = P * [i(1 + i)^n] / [(1 + i)^n - 1]
    
    Dove:
    - M = rata mensile
    - P = capitale (loan_amount)
    - i = tasso interesse mensile (interest_rate / 12 / 100)
    - n = numero rate (duration_years * 12)
    
    Request Body:
        {
            "loan_amount": 200000,  // Importo mutuo (€)
            "property_value": 250000,  // Valore immobile (€)
            "mortgage_type": "fixed",  // fixed, variable, mixed
            "duration_years": 25,
            "interest_rate": 3.5,  // Tasso annuo (%)
            "applicant_income": 45000  // Reddito annuo richiedente (€) - opzionale
        }
    
    Returns:
        200: Simulazione calcolata
        400: Parametri invalidi
    """
    try:
        body = app.current_event.json_body
        logger.info("Richiesta calcolo mutuo", extra={"body": body})
        
        # Estrai parametri
        loan_amount = Decimal(str(body.get('loan_amount')))
        property_value = Decimal(str(body.get('property_value')))
        mortgage_type = body.get('mortgage_type', 'fixed')
        duration_years = int(body.get('duration_years'))
        interest_rate = Decimal(str(body.get('interest_rate')))
        applicant_income = body.get('applicant_income')
        
        # Validazione base
        if loan_amount <= 0 or property_value <= 0:
            return {
                "statusCode": 400,
                "body": json.dumps({
                    "error": "INVALID_PARAMETERS",
                    "message": "Importo mutuo e valore immobile devono essere positivi"
                })
            }
        
        if duration_years < 1 or duration_years > 40:
            return {
                "statusCode": 400,
                "body": json.dumps({
                    "error": "INVALID_PARAMETERS",
                    "message": "Durata mutuo deve essere tra 1 e 40 anni"
                })
            }
        
        # Calcolo LTV (Loan-to-Value)
        ltv_ratio = (loan_amount / property_value * 100).quantize(Decimal('0.01'))
        
        if ltv_ratio > 80:
            logger.warning(f"LTV elevato: {ltv_ratio}%")
        
        # Calcolo rata mensile
        monthly_rate = interest_rate / 100 / 12
        num_payments = duration_years * 12
        
        # Formula ammortamento francese
        if monthly_rate == 0:
            # Caso particolare: tasso 0%
            monthly_payment = (loan_amount / num_payments).quantize(Decimal('0.01'), ROUND_HALF_UP)
        else:
            # M = P * [i(1 + i)^n] / [(1 + i)^n - 1]
            power_term = (1 + monthly_rate) ** num_payments
            monthly_payment = (
                loan_amount * (monthly_rate * power_term) / (power_term - 1)
            ).quantize(Decimal('0.01'), ROUND_HALF_UP)
        
        # Calcolo totale da restituire e interessi
        total_amount = monthly_payment * num_payments
        total_interest = total_amount - loan_amount
        
        # TAEG e TAN (semplificato - in produzione andrebbero considerate spese accessorie)
        tan = interest_rate
        taeg = interest_rate  # Semplificazione: TAEG = TAN se non ci sono spese
        
        # Calcolo DTI (Debt-to-Income) se fornito reddito
        dti_ratio = None
        is_sustainable = None
        
        if applicant_income:
            applicant_income_decimal = Decimal(str(applicant_income))
            monthly_income = applicant_income_decimal / 12
            dti_ratio = (monthly_payment / monthly_income * 100).quantize(Decimal('0.01'))
            is_sustainable = dti_ratio < 35  # Soglia sostenibilità: DTI < 35%
            
            logger.info(f"DTI calcolato: {dti_ratio}% - Sostenibile: {is_sustainable}")
        
        # Crea oggetto MortgageSimulation
        simulation = MortgageSimulation(
            simulation_id=str(uuid4()),
            loan_amount=loan_amount,
            property_value=property_value,
            mortgage_type=mortgage_type,
            duration_years=duration_years,
            interest_rate=interest_rate,
            monthly_payment=monthly_payment,
            total_interest=total_interest,
            total_amount=total_amount,
            taeg=taeg,
            tan=tan,
            ltv_ratio=ltv_ratio,
            applicant_income=Decimal(str(applicant_income)) if applicant_income else None,
            dti_ratio=dti_ratio,
            is_sustainable=is_sustainable
        )
        
        logger.info(
            f"Simulazione mutuo calcolata: rata={monthly_payment}€/mese, "
            f"totale={total_amount}€, interessi={total_interest}€"
        )
        
        # Metriche
        metrics.add_metric(name="MortgageCalculated", unit=MetricUnit.Count, value=1)
        metrics.add_dimension(name="MortgageType", value=mortgage_type)
        metrics.add_dimension(name="DurationYears", value=str(duration_years))
        
        if is_sustainable is not None:
            sustainability_metric = 1 if is_sustainable else 0
            metrics.add_metric(
                name="SustainableMortgage",
                unit=MetricUnit.Count,
                value=sustainability_metric
            )
        
        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Simulazione mutuo calcolata con successo",
                "data": simulation.model_dump(mode='json'),
                "summary": {
                    "monthly_payment": f"{monthly_payment}€",
                    "total_to_repay": f"{total_amount}€",
                    "total_interest": f"{total_interest}€",
                    "ltv_ratio": f"{ltv_ratio}%",
                    "dti_ratio": f"{dti_ratio}%" if dti_ratio else None,
                    "is_sustainable": is_sustainable
                }
            }, default=str)
        }
        
    except (ValueError, KeyError) as e:
        logger.warning(f"Parametri invalidi: {e}")
        return {
            "statusCode": 400,
            "body": json.dumps({
                "error": "INVALID_PARAMETERS",
                "message": f"Parametri non validi: {str(e)}"
            })
        }
        
    except Exception as e:
        logger.exception("Errore calcolo mutuo")
        metrics.add_metric(name="MortgageCalculationError", unit=MetricUnit.Count, value=1)
        
        return {
            "statusCode": 500,
            "body": json.dumps({
                "error": "CALCULATION_ERROR",
                "message": "Errore durante il calcolo del mutuo"
            })
        }


@logger.inject_lambda_context
@tracer.capture_lambda_handler
@metrics.log_metrics(capture_cold_start_metric=True)
def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """Handler principale Lambda"""
    return app.resolve(event, context)
