"""
Lambda function per recuperare dettagli di un immobile.

Endpoint: GET /properties/{id}
Recupera i dettagli completi di un immobile da DynamoDB con caching.
"""

import json
import os
from typing import Dict, Any, Optional

import boto3
from aws_lambda_powertools import Logger, Tracer, Metrics
from aws_lambda_powertools.event_handler import APIGatewayRestResolver
from aws_lambda_powertools.metrics import MetricUnit

from src.repositories.dynamodb_repository import PropertyRepository
from src.utils.cache import CacheService

logger = Logger()
tracer = Tracer()
metrics = Metrics()
app = APIGatewayRestResolver()

# Configurazione
TABLE_NAME = os.environ.get('TABLE_NAME')
CACHE_TTL = int(os.environ.get('CACHE_TTL', '3600'))  # 1 ora default

property_repo = PropertyRepository(table_name=TABLE_NAME)
cache = CacheService()


@app.get("/properties/<property_id>")
@tracer.capture_method
def get_property(property_id: str) -> Dict[str, Any]:
    """
    Recupera dettagli immobile per ID.
    
    Args:
        property_id: ID univoco immobile
    
    Returns:
        200: Property trovato
        404: Property non trovato
        500: Errore server
    """
    try:
        logger.info(f"Recupero immobile: {property_id}")
        
        # Controlla cache Redis prima
        cache_key = f"property:{property_id}"
        cached_data = cache.get(cache_key)
        
        if cached_data:
            logger.info(f"Cache HIT per property: {property_id}")
            metrics.add_metric(name="CacheHit", unit=MetricUnit.Count, value=1)
            
            return {
                "statusCode": 200,
                "headers": {
                    "X-Cache": "HIT"
                },
                "body": json.dumps({
                    "data": json.loads(cached_data)
                })
            }
        
        # Cache MISS - recupera da DynamoDB
        logger.info(f"Cache MISS per property: {property_id}")
        metrics.add_metric(name="CacheMiss", unit=MetricUnit.Count, value=1)
        
        property_obj = property_repo.get_by_id(property_id)
        
        if not property_obj:
            logger.warning(f"Immobile non trovato: {property_id}")
            metrics.add_metric(name="PropertyNotFound", unit=MetricUnit.Count, value=1)
            
            return {
                "statusCode": 404,
                "body": json.dumps({
                    "error": "NOT_FOUND",
                    "message": f"Immobile {property_id} non trovato"
                })
            }
        
        # Salva in cache per richieste successive
        property_json = property_obj.model_dump_json()
        cache.set(cache_key, property_json, ttl=CACHE_TTL)
        
        logger.info(f"Immobile recuperato e cachato: {property_id}")
        metrics.add_metric(name="PropertyRetrieved", unit=MetricUnit.Count, value=1)
        
        return {
            "statusCode": 200,
            "headers": {
                "X-Cache": "MISS"
            },
            "body": json.dumps({
                "data": property_obj.model_dump(mode='json')
            }, default=str)
        }
        
    except Exception as e:
        logger.exception(f"Errore recupero immobile: {property_id}")
        metrics.add_metric(name="GetPropertyError", unit=MetricUnit.Count, value=1)
        
        return {
            "statusCode": 500,
            "body": json.dumps({
                "error": "INTERNAL_ERROR",
                "message": "Errore recupero immobile"
            })
        }


@logger.inject_lambda_context
@tracer.capture_lambda_handler
@metrics.log_metrics(capture_cold_start_metric=True)
def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """Handler principale Lambda"""
    return app.resolve(event, context)
